/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/GENERIC3/generic3.cpp 12072 2015-06-24 15:34:45Z crichardson $ */
#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>
#include <gdi.he>
#include "generic3.he"

// Generic 3 is built on the foundations of the generic2 sample.
// This sample adds a function to the generic object
//
// The function is activated via OMNIS notation. e.g.
//
// Do $cwind.$objs.myobj.$flash( 20 )			where myobj is the name assigned to the generic 3 object
//
// After you have built this sample add a generic3 object to a window, name the object myobj
//
// Then add a button to the window add a method for the button 
// 	On evClick
//		Do $cwind.$objs.myobj.$flash(20)   
// 
// our sample function will cause our object to flash n times where n is the parameter passed
// we also now have two new properties. The flash color when our function is triggered and the 
// flash delay time

// This is how we define the properties for our components.

// propery numbers
const qlong cMyColorProp 				= 1,		// rmmCW9
						cMyColorProp2	  		= 2,
						cMyDelayProp	  		= 3,
						// ------------------------
						cDoFlashFunction    = 1;

// This table will go back to OMNIS  

// some of the property parts below are better expained in other external 
// components such as the calendar example.
ECOproperty MyProperties[] =
{ 
//    propid					resourceid,   datatype,			propflags						propFlags2, 		enumStart, 		enumEnd
			cMyColorProp, 	4000, 				fftInteger, 	EXTD_FLAG_PWINDCOL, 0, 							0, 						0,
			cMyColorProp2, 	4001, 				fftInteger, 	EXTD_FLAG_PWINDCOL, 0, 							0, 						0,
			cMyDelayProp, 	4002, 				fftInteger, 	0, 									0, 							0, 						0
};


// This is how we define function parameters
ECOparam MyParms[1] =
{
//	  name resid    	datatype      flags   flags2
			7000, 					fftInteger, 	0, 			0
};

// This is how we define methods
ECOmethodEvent MyFunctions[1] = 
{
//    methodid					resourceid,   return datatype,	paramcnt		parameters			flags,	flags2
			cDoFlashFunction, 6000, 				0, 								1, 					&MyParms[0], 		0, 			0
};




// Your generic object constructor
tqfGenericObject::tqfGenericObject( HWND pFieldHWnd )
{
	mHWnd = pFieldHWnd;
	mMyColor = GDI_COLOR_WINDOW;			// set default values
	mFlashColor = GDI_COLOR_QDKRED;		// set default values
	mFlashDelay = 50;								  // set default values
}

// Generic destruction
tqfGenericObject::~tqfGenericObject()
{
	// Insert any memory deletion code or general cleanup code
}

// We will call this if our $flash() function is called
void tqfGenericObject::flash( qlong pNumberOfFlashs )
{
	// get a drawing device as this is not a paint message
	HDC hdc = WNDstartDraw( mHWnd );                      
	// get a solid brush
	HBRUSH brush = GDIgetStockBrush	( BLACK_BRUSH );
	// get the client rect for our component
	qrect cRect; 
	WNDgetClientRect( mHWnd, &cRect );
	// ready loop
	for ( qlong loop = 1; loop<=pNumberOfFlashs; loop++ )
	{
		// wait
		WNDdelay( mFlashDelay );
		// set the text color ( fill color for a solid brush ) based on our objects color
	 	GDIsetTextColor( hdc, mFlashColor );
		// fill with flash color
		GDIfillRect( hdc, &cRect, brush );
#ifdef ismacosx
		GDIflushDC(hdc); // CR0251
#endif
		// wait
		WNDdelay( mFlashDelay );
		// set and fill with normal color
		GDIsetTextColor( hdc, mMyColor );
		GDIfillRect( hdc, &cRect, brush );
#ifdef ismacosx
		GDIflushDC(hdc); // CR0251
#endif
	}            
	// finished drawing
	WNDendDraw( mHWnd, hdc );
}

void tqfGenericObject::functionSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( ECOgetId(eci) )
	{
		// our flash function 
		case cDoFlashFunction:
		{     
			// get the function parameter
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( !param ) break; // Method called with too few parameters
			// create fldval 
			EXTfldval fval( (qfldval)param->mData );
			flash( fval.getLong() );
			break;
		}                     
		// see calendar example for multiple functions, mulitple parameters, and return values
	}
}

// You need to paint your control
qbool tqfGenericObject::paint()
{
	WNDpaintStruct paintStruct;
	WNDbeginPaint( mHWnd, &paintStruct );
	// get the client rect for our component
	qrect cRect; 
	WNDgetClientRect( mHWnd, &cRect );
	// get a solid brush from the stock - stock brushes to not need to be deleted
	HBRUSH brush = GDIgetStockBrush	( BLACK_BRUSH );
	// set the text color ( fill color for a solid brush ) based on our objects color
 	GDIsetTextColor( paintStruct.hdc, mMyColor );
 	// and fill our object
	GDIfillRect( paintStruct.hdc, &cRect, brush );
	// finished

	// If in design mode, then call drawNumber & drawMultiKnobs to draw design
	// numbers and multiknobs, if required.
	if ( ECOisDesign(mHWnd) )
	{
		ECOdrawNumber(mHWnd,paintStruct.hdc);
		ECOdrawMultiKnobs(mHWnd,paintStruct.hdc);
	}

	WNDendPaint( mHWnd, &paintStruct );	
	return qtrue;
}

// This function handles our property setting,getting and canassign query.
qlong tqfGenericObject::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( pMessage )
	{ 
		case ECM_PROPERTYCANASSIGN: 
		{
			// we now have more than one property, but all of the are assignable, so still return 1L;
			return 1L;		
		}
		case ECM_SETPROPERTY: 
		{
			// get the externals parameter
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( param )
			{                             
				// get the fldval from the parameter.
				EXTfldval fval( (qfldval)param->mData );
				// fldvals are containers that store data. All values in and out of OMNIS are passes in fldvals.
				// switch on property id
				switch( ECOgetId(eci) )
				{  
					// we are setting our color property
					case cMyColorProp:
					{
						// as our property is a color property - as set in our property table
						// we can assign the long value stored in the fldval to our color data member.
						mMyColor = (qcol)fval.getLong();						                                
						// qcol is an OMNIS RGB value.
						WNDinvalidateRect( mHWnd, NULL );
						// mark our window as needing a repaint, due to the color changing
						break;
					}                 
					// setting the flash color
					case cMyColorProp2:
					{
						// set the value
						mFlashColor = (qcol)fval.getLong();						                                
						break;
					}          
					// setting the delay property
					case cMyDelayProp:           
					{
						// set the value
						mFlashDelay = fval.getLong();						                                
						break;
					}
				}   
				return 1L;
			}
			break;
		}
		case ECM_GETPROPERTY: 
		{
			// get the externals parameter
			EXTfldval fval;
			// switch on property id
			switch( ECOgetId(eci) )
			{         
				// OMNIS wants to know our color property value
				case cMyColorProp:
				{
					// send back the current value of our color in the fldval container
					fval.setLong( (qlong)mMyColor );                                              
					break;
				}
				// OMNIS wants to know our flash color property value
				case cMyColorProp2:
				{
					// set the value
					fval.setLong( (qlong)mFlashColor );						                                
					break;
				}          
				// OMNIS wants to know our flash delay property value
				case cMyDelayProp:           
				{
					// set the value
					fval.setLong( mFlashDelay );						                                
					break;
				}
			}
			// to send it back, we add a parameter which OMNIS will check on return.
			ECOaddParam(eci,&fval);
			return 1L;
		}             
	}
	return 0L;		// no property found or message was wrong
}


// Component library entry point (name as declared in resource 31000 )
extern "C" LRESULT OMNISWNDPROC GenericWndProc(HWND hwnd, UINT Msg,WPARAM wParam,LPARAM lParam,EXTCompInfo* eci)
{
	 // Initialize callback tables - THIS MUST BE DONE
   ECOsetupCallbacks(hwnd, eci);		
	 switch (Msg)
	 {
			// WM_PAINT - standard paint message
			case WM_PAINT:
			{
				// First find the object in the libraries chain of objects
				tqfGenericObject* object = (tqfGenericObject*)ECOfindObject( eci, hwnd );
				// and if its good, call the paint function
				if ( NULL!=object && object->paint() )
					return qtrue;
				break;
			}  
			
			// ECM_OBJCONSTRUCT - this is a message to create a new object
			case ECM_OBJCONSTRUCT:				
			{
				// Allocate a new object
				tqfGenericObject* object = new tqfGenericObject( hwnd );
				// and insert into a chain of objects. The OMNIS library will maintain this chain
				ECOinsertObject( eci, hwnd, (void*)object );
				return qtrue;
			}    
			
			// ECM_OBJDESTRUCT - this is a message to inform you to delete the object
			case ECM_OBJDESTRUCT:					
			{
				// First find the object in the libraries chain of objects, 
				// this call if ok also removes the object from the chain.
				tqfGenericObject* object = (tqfGenericObject*)ECOremoveObject( eci, hwnd );
				if ( NULL!=object )
				{
					// Now you can delete the object you previous allocated
					// Note: The hwnd passed on ECM_OBJCONSTRUCT should not be deleted, as
					// it was created and will be destroyed by OMNIS
					delete object;
				}
				return qtrue;
			}
	 		
	 		// ECM_CONNECT - this message is sent once per OMNIS session and should not be confused 
	 		// with ECM_OBJCONSTRUCT which is sent once per object. ECM_CONNECT can be used if load other libraries
	 		// once or other general global actions that need to be done only once.
	 		//
	 		// For most components this can be removed - see other BLYTH component examples
	 		case ECM_CONNECT:
      {
        return EXT_FLAG_LOADED; // Return external flags
      } 
      
	 		// ECM_DISCONNECT - this message is sent only once when the OMNIS session is ending and should not be confused
	 		// with ECM_OBJDESTRUCT which is sent once per object. ECM_DISCONNECT can be used to free other libraries
	 		// loaded on ECM_CONNECT or other general global actions that need to be done only once.
	 		// 
	 		// For most components this can be removed - see other BLYTH component examples
      case ECM_DISCONNECT:
      { 
        return qtrue;
      }

     	// ECM_GETCOMPLIBINFO - this is sent by OMNIS to find out the name of the library, and
      // the number of components this library supports
       case ECM_GETCOMPLIBINFO:
      {
      	return ECOreturnCompInfo( gInstLib, eci, LIB_RES_NAME, OBJECT_COUNT );
      }

      // ECM_GETCOMPICON - this is sent by OMNIS to get an icon for the OMNIS component store and
      // external component browser. You need to always supply an icon in your resource file.
			case ECM_GETCOMPICON:
			{
				// OMNIS will call you once per component for an icon.
				// GENERIC_ICON is defined in the header and included in the resource file
				if ( eci->mCompId==OBJECT_ID1 ) return ECOreturnIcon( gInstLib, eci, GENERIC_ICON );
				return qfalse;
			}

			// ECM_GETCOMPID - this message is sent by OMNIS to get information about each component in this library
			// wParam is a number from 1 to the number of components return on the ECM_GETCOMPLIBINFO message.
			//
			// For each call you should return the internal object ID and the type of object it is.
			// The object id will be used for other calls such as ECM_GETCOMPICON 
			// 
			// The object type is for example : cObjType_Basic 		- a basic window object or 
			//																	cRepObjType_Basic	- a basic report object.
			// 																	There are others 	- see BLYTH examples and headers
			case ECM_GETCOMPID:
			{
				if ( wParam==1 )
					return ECOreturnCompID( gInstLib, eci, OBJECT_ID1, cObjType_Basic );
				return 0L;
			}

      // ECM_CUSTOMTABNAME - as we now support properties, we have a tab in the propery inspector.
      // If we do not handle this message i.e. remove the ECM_CUSTOMTABNAME
      // case, the tab name in the property inspector defaults to 'Custom'. The code shown here will
      // return a name for the tab
      //
      // Here we are tell OMNIS to use our resource 3000
			case ECM_CUSTOMTABNAME:
			{
				ECOsetCustomTabName( gInstLib, eci, 3000 );
				return 1L;
			}

			// ECM_GETPROPNAME - this messasge is send by OMNIS to get your properties.
			// ECOreturnProperties takes the table of properties at the top of this file and returns
			// them to OMNIS. The last parameter is the number of properties in your table
			case ECM_GETPROPNAME:
			{
				return ECOreturnProperties( gInstLib, eci, &MyProperties[0], 3 );
			}   
			
			// The following messages will be sent now we support properties. OMNIS has three modes where
			// properties are concerned. The modes are canAssign, set and get value. These map onto OMNIS notation,
			// and are sent if our object is being displayed in the property inspector.
			case ECM_PROPERTYCANASSIGN:  	
			case ECM_SETPROPERTY: 				
			case ECM_GETPROPERTY:					
			{
  			// First find the object in the libraries chain of objects
				tqfGenericObject* object = (tqfGenericObject*)ECOfindObject( eci, hwnd );
				if ( object )
					// if we found the object, call a function to handle the message
					return object->attributeSupport( Msg, wParam, lParam, eci );
				return 0L;
			}
                                                                            
			// ECM_GETMETHODNAME - to support methods we have to register method information in the 
			// same way we register properties
			case ECM_GETMETHODNAME:
			{
				return ECOreturnMethods( gInstLib, eci, &MyFunctions[0], 1 );
			}

			// ECM_METHODCALL - now we support methods, OMNIS will call us with this message
			// to execute one when some notation executes our objects methods
			case ECM_METHODCALL:
			{
				// First find the object in the libraries chain of objects
				tqfGenericObject* object = (tqfGenericObject*)ECOfindObject( eci, hwnd );
				if ( object )
					// call our support function to decide what function we need to execute
					object->functionSupport( Msg, wParam, lParam, eci );
				return 1L;
			}

	 }

	 // As a final result this must ALWAYS be called. It handles all other messages that this component
	 // decides to ignore.
	 return WNDdefWindowProc(hwnd,Msg,wParam,lParam,eci);
}

	
