/* $Header:  $ */
/*
	OMNIS Studio - Generic DAM worker object
	Copyright (C) TigerLogic Corporataion 2016

FILENAME:			dgenworker.cpp
DESCRIPTION:	Implements derived generic Worker object
DETAILS:	
*/
/* Changes
Date				Edit		Fault				Description
07-Feb-20		gra1212			ST/*P/099			Added damWorkerInitStmt()
May-16			gra									Derived generic worker delegate
*/

#include "dgenworker.hi"

//	##################################################################
//	PURPOSE:	Overidden interface object constructor
//	RETURN:		None
//	DETAIL:		Creates a derived worker delegate object
genericWorker::genericWorker(qobjinst ptr, EXTCompInfo* pEci)  : StatementWorker(ptr, pEci)
{
	mDelegate = new genericWorkerDelegate(ptr, pEci);
}

//	##################################################################
//	PURPOSE:	Overidden worker delegate constructor
//	RETURN:		None
//	DETAIL:		
genericWorkerDelegate::genericWorkerDelegate(qobjinst objptr, EXTCompInfo* pEci) : StatementWorkerDelegate(objptr, pEci)
{
}

//	##################################################################
//	PURPOSE:	Overidden worker delegate copy constructor
//	RETURN:		New delegate instance
//	DETAIL:   gra1060 added
genericWorkerDelegate* genericWorkerDelegate::dup(qobjinst objinst, EXTCompInfo* pEci) 
{
	genericWorkerDelegate* theCopy = new genericWorkerDelegate(objinst, pEci); //create new object
	theCopy->setWaitForComplete(mWaitForComplete);
	theCopy->setCancelIfRunning(mCancelIfRunning);
	return theCopy;      //return to caller
}

//	##################################################################
//	PURPOSE:	Overidden worker delegate destructor
//	RETURN:		None
//	DETAIL:		Dispose of delegate's session and statement objects
genericWorkerDelegate::~genericWorkerDelegate()
{
	tqfGenericDAMObj *session = (tqfGenericDAMObj*)mSessionObj;
	tqfGenericStatementObj* stmt = (tqfGenericStatementObj*)mStatementObj;
	if (stmt)	delete stmt;			
	if (mSessionObjMine==qtrue)	delete session; 
}

//	##################################################################
//	PURPOSE:	Initialise derived worker object
//	RETURN:		None
//	DETAIL:		Extracts any additional parmeters, create sesssion & statement objects
void genericWorkerDelegate::damWorkerInit()
{
	if (!mSessionObj) 
	{
		mSessionObj = (tqfDAMbaseObj*) new tqfGenericDAMObj(mEci);
		mSessionObjMine = qtrue;
	}
	
	((tqfGenericDAMObj*)mSessionObj)->dSetBindMarker();
}

//	##################################################################
//	PURPOSE:	Initialise derived worker statement object
//	RETURN:		None
//	DETAIL:		gra1212 added
void genericWorkerDelegate::damWorkerInitStmt()
{
	if (!mStatementObj) mStatementObj = new tqfGenericStatementObj(); 
}

//	##################################################################
//	PURPOSE:	Worker delegate logon
//	RETURN:		qtrue on success
//	DETAIL:		Perform dditional configuration and logon derived sesion object 
qbool genericWorkerDelegate::damWorkerLogon()
{
	tqfGenericDAMObj *session = (tqfGenericDAMObj*)mSessionObj;
	return session->dLogon(mHostname, mUsername, mPassword);
}

//##################################################################
//	PURPOSE:	Add a row to the supplied error list
//	RETURN:		None
//	DETAIL:		Get native error code & native error text from the delegate's statement/session
void genericWorkerDelegate::addError(EXTqlist *pErrList, eWorkerError pErrCode, qlong pQueryNum, qlong pBindRow)
{
	EXTfldval errCode, errText, nativeErrCode, nativeErrText; 
	mErrorInfo.setErrorCode(pErrCode); //set errorcode so that errText can be extracted
	mErrorInfo.getErrorText(errText);
	errCode.setConstant(preDAMErrorsF,preWorkerErrorsL,pErrCode);

	tqfGenericStatementObj *statement = (tqfGenericStatementObj*)mStatementObj; 
	tqfGenericDAMObj *session = (tqfGenericDAMObj*)mSessionObj;

	qlong nec=0; str255 errStr;
	if (statement) 
		statement->dGetNativeError(nec, nativeErrText);

	if (nec==0 && session)
		session->dGetNativeError(nec, nativeErrText);

	nativeErrCode.setLong( nec );

	qlong errRow = pErrList->insertRow(); //Add error info row
	pErrList->putColVal(errRow,1,errCode); //generic error code
	pErrList->putColVal(errRow,2,errText); //generic error text
	pErrList->putColVal(errRow,3,nativeErrCode); //native error code
	pErrList->putColVal(errRow,4,nativeErrText); //native error text

	EXTfldval intVal;
	intVal.setLong(pQueryNum); pErrList->putColVal(errRow,5,intVal);
	intVal.setLong(pBindRow); pErrList->putColVal(errRow,6,intVal);
}

	
// End of file


