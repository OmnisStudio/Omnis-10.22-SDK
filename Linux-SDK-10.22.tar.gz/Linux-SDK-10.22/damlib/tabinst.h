/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/O7EXE/INDY/tabinst.h 25391 2020-02-06 13:44:16Z bmitchell $ */

//table instance class definition
//Copyright (C) Blyth Holdings Inc 1996

/* Changes
Date			Edit				Bug					Description
06-Feb-20	rmm10403		ST/NT/759		$cinst.$container did not work for a table instance using a worker object.
30-May-19	rmm10113		ST/*A/134		SQL lists and rows can now be used with DAM worker objects.
10-May-19	rmm10082		ST/NT/750		Added $container to object and table instances.
26-Mar-18	rmm9613			ST/*A/124		$definelistorrow can now update $cinst for a table instance.
18-Jul-14	rmm_rws2								RESTful web services phase 2.
17-Apr-14	rmm8305									$sessionobjref and $statementobjref
06-Feb-13	rmm7834			OE-1312+3		More Omnis X metadata.
24-Aug-12	rmm7616									Added SQL statement notation to JavaScript client methods e.g. $clib.$schemas.SCHEMA.$select
17-Aug-11	gra0806			ST/*O/131		Implemented quoted identifiers
21-Mar-06	rmm5686			ST/DB/676+7	Certain operations when debugging deleted table instances.
27-Jan-06 MHMACHTB                Removed tabinst.h from complib headers.
14-Sep-05	rmm_ws1									Web services - allow a schema/query/table class name to be used as the subtype of a list/row variable which is
																	a class, instance, local, task or parameter variable, or a column in a list or row defined from a sql class. 
06-Jan-05	gra0235			ST/*A/043		Enable V3 DAMs access to schema info
06-Jul-04	rmm5014									Crash using debugger with smart list and table instance.
19-May-03	ijt243			ST/*O/044		Added $nativeerrorcode and $nativeerrortext properties to smartlist $history lines.
11-Oct-02	rmm4279			ST/NT/387		$cwind now works for lists defined from a table, and declared in a window.
27-Feb-02	gra0070			ST/*A/017		$sqlerror not called when prepare fails
11-May-00	rmm3753									Pass object instance to nulltext message.
31-Mar-00	rmm3691									Added ability to assign $statementobject.
10-Mar-00	rmm3677									$fromclause table instance property.
02-Mar-00	DRS5200									v3 sql session objects
23-Mar-99	rmm3377			ST/ET/107		Memory leak caused by temporary row variables.
23-Dec-97	rmm2899			ST/SC/034FC	Allow the use of calculated columns in query classes.
23-Dec-97	rmm2898			ST/SC/035FC	$selectdistinct() for table instances.
23-Dec-97	rmm2897			ST/SC/036		$excludefrominsert and $excludefromupdate properties for table instance columns.
06-Nov-97	rmm2753									Set $useprimarykeys automatically; removed it from the table instance; set primary key flag if possible in Make schema... command
10-Oct-97	rmm2696									Improved $add for a list column, when used with a list defined from a SQL class.
06-Oct-97	rmm2684									Query class implementation - phase 2.
23-Sep-97	rmm2673									$useprimarykeys for tables.
22-Sep-97	rmm2672									$createnames for schemas/tables.
05-Sep-97	rmm2652									New table smartlist methods: $doupdate, $doinsert, $dodelete.
21-Mar-97	rmm2392			PR/VR/087		Omit table class temporary instance variables from variables list.
22-Nov-96	rmm2012			PR/HI/349FC	$select now takes optional text argument.
12-Aug-96 DRS4089									Tableinst interface moved from appinst.h
01-Jul-96	rmm1502									Removed $rowsinset (impossible to implement)
28-Jun-96	rmm1489									Todisk for table instances.
28-Jun-96	rmm1488									Make sure instances are closed before disconnecting from the data manager at shutdown.
28-Jun-96	rmm1485									More changes to table instance notation.
27-Jun-96	rmm1483									More table instance notation.
26-Jun-96	rmm1482									More table instance notation.
24-Jun-96	rmm1481									Table instance notation.
23-Jun-96	rmm1480									Mods to $defineclass for table instances.
21-Jun-96	rmm1478									Table instances.
*/

#ifndef _tabinst_
#define _tabinst_

#ifndef isXCOMPLIB //gra0235 (External components ignore all this...)

#ifndef _appinst_
	#include "appinst.h"
#endif

class smlsttype;	// rmm1482
class SQLGroup;		// rmm1481
class schemafmt;	// rmm2673
class QRYschemaList;	// rmm2684
class objectinst;	//DRS5200

// Start rmm10113: 
// Class to save a request for a worker, when the worker is busy
struct tableWorkerQueueEntry
{
	enum eOperationType
	{
		eDelete,
		eInsert,
		eSelectFetch,
		eUpdate,
		eSmartListDelete,
		eSmartListInsert,
		eSmartListUpdate,
		eSmartListWork
	};

	tableWorkerQueueEntry(lsttype* pParamRow, eOperationType pOperationType, qbool pAppend)
	{
		mParamRow = pParamRow;
		mOperationType = pOperationType;
		mAppend = pAppend;
	}
	~tableWorkerQueueEntry()
	{
		if (mParamRow)
			delete mParamRow;
	}

	lsttype*					mParamRow;			// Parameter row to pass to worker $init (owned by this object)
	eOperationType		mOperationType;	// The type of SQL operation being performed
	qbool							mAppend;				// Append flag for $selectfetch()
};

// DAM worker object
class DAMworkerObj;

// DAM worker parameters
class DAMworkerParameters;
// End rmm10113

// rmm2392: moved these resource numbers to here
// Temporary variable resource numbers
const rstrno	cTABtempVarRow1 = 14250,
							cTABtempVarRow2 = 14251;

// rmm1478: Replaced fileinst with tableinst
class tableinst: public appinst { //DRS4008

private:	// rmm1481: private members only used at runtime
	SQLGroup		*mPreviousGroup;
	str15				mPreviousChannel;
	qlong				mRowsAffected;
	qlong				mRowsFetched;
	qbool				mAllRowsFetched;
	qbool				mInDoOperation;		// rmm2652: prevents rescursive calls to $doupdates/$dodeletes/$doinserts
	qbool				mUseWorker;				// rmm10113: If true, use a worker object
	qbool				mSync;						// rmm10113: If mUseWorker is true, use the worker synchronously if mSync is true
	fldval			mTokenizedSql;		// rmm2652: tokenized SQL for current do operation //DRS5200
	quint				mPrimaryKeyCount; // rmm2753
	fldval			*mConstructParm;	// rmm_ws1: used when construction of a variable or parameter is delayed
	EXTCompItem*	mCompItem;			// rmm10113: component containing session object and worker
	DAMworkerObj*	mWorkerObj;			// rmm10113: Worker object when we are using a worker
protected:
	lsttype		*plst;
	qlong			mColumnCount;				// rmm2696: the number of list columns used in SQL queries etc.
	fmtref		mColsFref;					// rmm2684: fmtref for schema or query defining the columns, if the class is defined directly from a schema or query
	str255		mSqlClassName;			// rmm2684
	QRYschemaList *mServerTables;	// rmm2684
	str15			mSessionName;				// OLD DAM session name - left in case any new code is using it to store information in a serialised table instance
	// Start rmm8305
	fldval		mSessionObjFval;
	fldval		mStatementObjFval;
	// End rmm8305
	fldval		mExtraQueryText;		// rmm2684
	fldval		mFromClause;				// rmm3677
	qbool			mUsePrimaryKeys;		// rmm2673: If true, only primary keys are used in the where clause of the generated SQL
	qbool			mInSmartOperation;	// rmm5014: If true, a smart operation is being executed for the table instance
	qbool			mCreatedFromSubtype;// rmm5686: If true, the instance was created using the subtype of its list or row variable
	// Start rmm10082
	appinst*	mContainerInst;			//Container instance for object
	qlong			mContainerInstUnq;	//Unique id value of container instance (used to validate instance before using it)
	// End rmm10082

	virtual		~tableinst();
	// Start rmm8305
	objectinst *getSessionObj() { return mSessionObjFval.getobjectinst(); }
	objectinst *getStatementObj() { return mStatementObjFval.getobjectinst(); }
	// End rmm8305
	void 			deleteSessionObj(); // DRS5200
	void			addSchemaColumns(fmtref &pFref, tqitemref *item, valpasstype *vpt, qbool *pUsingRowForSchemaCols);		// rmm2684: add the columns from the supplied schema // rmm7834
	void			addQueryColumns(fmtref &pFref);																																				// rmm2684: add the columns from the supplied query
	void			addCalculatedCol(strxxx &pName, strxxx &pCalc, qlong pServerTableIndex);															// rmm2899: add a calculated column to the table

	// rmm8306: Use fldval & rather than objectinst * for pStatementObj
	// Start rmm1481: methods to execute notation methods.
	void issueSelect(tqitemref *pItem, valpasstype &pVpt, fldval &pFval, qbool pDistinct, qbool pGenSQL = qfalse); // rmm2012 // rmm2898 // rmm7616
	void issueFetch(tqitemref *pItem, valpasstype &pVpt, fldval &pFval);
	// Start rmm10113
	void issueSelectFetch(tqitemref* pItem, valpasstype& pVpt, fldval& pFval);	
	qbool issueInsertWithWorker();
	qbool issueUpdateWithWorker(qbool pDisableWhere);
	qbool issueDeleteWithWorker(qbool pDisableWhere);
	qbool executeWithWorker(fldval& pQuery, DAMworkerParameters &pParameters);
	DAMworkerParameters *getWorkerParametersForSmartListOperation(tableWorkerQueueEntry::eOperationType pOperationType);
	void doInsertsWithWorker(DAMworkerParameters* pWorkerParameters, str15& pTempName, fldval& pFval);
	void doUpdatesWithWorker(DAMworkerParameters* pWorkerParameters, str15& pTempName, qbool pDisableWhere, fldval& pFval);
	void doDeletesWithWorker(DAMworkerParameters* pWorkerParameters, str15& pTempName, qbool pDisableWhere, fldval& pFval);
	// End rmm10113
	qbool issueInsert(fldval &pTokenizedSqlStatement, fldval &pStatementObjFval, strxxx *pRowName = 0);  //DRS5200
	qbool issueUpdate(fldval &pTokenizedSqlStatement, fldval &pStatementObjFval, strxxx *pRowName = 0); //DRS5200
	qbool issueDelete(fldval &pTokenizedSqlStatement, fldval &pStatementObjFval, strxxx *pRowName = 0); //DRS5200
	void doInserts(tqitemref *pItem, fldval &pFval, DAMworkerParameters *pWorkerParameters = 0);	// rmm2652 // rmm10113
	void doDeletes(tqitemref *pItem, valpasstype &pVpt, fldval &pFval, DAMworkerParameters* pWorkerParameters = 0);	// rmm2652	// rmm2684 // rmm10113
	void doUpdates(tqitemref *pItem, valpasstype &pVpt, fldval &pFval, DAMworkerParameters* pWorkerParameters = 0);	// rmm2652	// rmm2684 // rmm10113
	void doWork(tqitemref *pItem, valpasstype &pVpt, fldval &pFval);		// rmm2652	// rmm2684
	void undoInserts(fldval &pFval);
	void undoDeletes(fldval &pFval);
	void undoUpdates(fldval &pFval);
	void undoWork(fldval &pFval);
	void doCreatenames(fldval &pFval);								// rmm2672
	void doSelectnames(fldval &pFval, qbool pQuote = qfalse); //gra0806
	void doUpdatenames(fldval &pFval, strxxx *pWhereRowName = 0, strxxx *pRowName = 0, qbool pDisableWhere = qfalse, qbool pQuote = qfalse);	// rmm1483 // rmm2684 //gra0806
	void doInsertnames(fldval &pFval, strxxx *pRowName = 0, qbool pQuote = qfalse);														// rmm1483 //gra0806
	void doWherenames(fldval &pFval, str15 &pWhereOperator, strxxx *pRowName = 0, qbool pQuote = qfalse);			// rmm1483 // rmm1485 //gra0806
	void doColsinset(fldval &pFval);
	void doInsert(tqitemref *pItem, valpasstype &pVpt, fldval &pFval);	// rmm2652 
	void doUpdate(tqitemref *pItem, valpasstype &pVpt, fldval &pFval);	// rmm2652
	void doDelete(tqitemref *pItem, valpasstype &pVpt, fldval &pFval);	// rmm2652

	void buildSelectStatement(fldval& pStatement, tqitemref* pItem, valpasstype& pVpt, qbool pDistinct, qbool pGenSQL, qshort pFirstTextParam = 1);	// rmm10113
	qbool	buildInsertStatement(fldval &pTokenizedSqlStatement, fldval &pStatementObjFval, qbool pNoPrepare, strxxx *pRowName = 0, qbool pGenSQL = qfalse);	// Build and tokenize an insert statement //DRS5200 // rmm7616
	qbool	buildDeleteStatement(fldval &pTokenizedSqlStatement, fldval &pStatementObjFval, qbool pNoPrepare, strxxx *pRowName = 0, qbool pDisableWhere = qfalse, qbool pGenSQL = qfalse);	// Build and tokenize a delete statement // rmm2684 //DRS5200  // rmm7616
	qbool	buildUpdateStatement(fldval &pTokenizedSqlStatement, fldval &pStatementObjFval, qbool pNoPrepare, strxxx *pRowName = 0, qbool pDisableWhere = qfalse, qbool pGenSQL = qfalse);	// Build and tokenize an update statement // rmm2684 //DRS5200  // rmm7616

	qbool getQuotedIdent();	// rmm10113: Made this a method to get the quoted ident flag for the session
	qbool createWorker(objectinst* pSessionObj);	// rmm10113

	void	addWhereClause(fldval &pFval, str15 &pWhereOperator, strxxx *pRowName = 0, qbool pQuote = 0);		// Concat a where clause to the end of the supplied fldval // rmm1485 //gra0806
	void	addBindVariableReference(fldval &pFval, str255 &pName, strxxx *pRowName = 0);	// Add a bind variable reference to the output of a ...names method
	qbool	setSqlChannel();																				// Set up the SQL channel to use for a table method
	qbool executeSql(fldval &pStatement, fldval &pStatementObjFval, qshort pErrorId);				// Execute the supplied tokenized SQL statement //DRS5200
	qbool tokenizeSqlStatement(fldval &pStatement, fldval &pTokenizedStatement, fldval &pStatementObjFval, qbool pNoPrepare, qbool *pDidPrepare = NULL);			// Tokenize the SQL statement in the supplied fldval, and return the result in the supplied fldval. //DRS5200 //gra0070
	void	sqlError(objectinst *pStatementObj, qshort pErrorId, fldval *pErrorTextPtr = 0, qlong pErrorCode = 0);	// rmm1485: Call the $sqlerror method of the table instance //DRS5200
	void	sqlError(qshort pErrorId, rstrno pErrorTextResource);	// rmm10113
	// End rmm1481
	qbool getTempVariable(rstrno pNameResource, str15 &pName, qshort &pXn);												// rmm1482: used to get a temporary variable
	void	copyFromSmartToRow(smlsttype *pSmartList, qlong pSmartLineNumber, lsttype *pRow, qbool pIsOld);	// rmm1482: copy from smart list to row
	void	getSqlErrorInfo(objectinst *pStatementObj, qlong &pErrorCode, fldval &pErrorText, qlong &pNativeErrorCode, fldval &pNativeErrorText); //DRS5200		//<ijt243>															// rmm1482: get sys(131) and sys(132) error information
	void	doSmartOperation(fldval &pStatementObjFval, tqitemref *pItem, fldval &pResultFval, qshort pSmartStatus, attnumber pRevertOperation); // rmm1482: execute one of the do... smart list methods // rmm2652 //DRS5200
	void	smartSaveRevert(smlsttype *pSmartList, attnumber pRevertOperation);											// Save or revert smart list changes
	void	doUndo(fldval &pFval, attnumber pRevertOperation);	// Executes one of the undo methods
	void	reportGeneralError(rstrno pErrorCode);							// Reports an error by calling sqlerror
	qbool copyArgument(qshort pArgNum, tqitemref *pItem, valpasstype &pVpt, rstrno pVarId, fldfnxn &pFnxn);	// rmm2652 // rmm3377
	void	addExtraQueryText(fldval &pFval);										// rmm2684: append extra query text to pFval, replacing schema names with table names
	void	replaceSchemaNamesWithTableNames(fldval &fval);			// rmm2899: replace schema names in the form schema. or lib.schema. with table.
	void	newStatementObj(fldval &pStatementObjFval, qbool pNewObjectRef);	// DRS5200: create a statement object for mSession // rmm8305
	superinst *getMainInst();																	// rmm3753: get the main instance for messages sent to a non-visual DAM
	void			doSetContainer(const locptype& pLocp);	// rmm10403
public:
	tableinst(lsttype* plst1, fmtref& fref1, fmtref &pColsFref, tqitemref *item = 0, valpasstype *vpt = 0, strxxx* name1=0, crbtype* ivars=0, fldval *info = 0, qbool pCreatedFromSubtype = qfalse, qbool *pUsingRowForSchemaCols = 0); // rmm1480 // rmm1489 // rmm2684 // rmm5686 // rmm7834
	tableinst(lsttype* plst1, appinst* finst1);
	virtual		crbtype* getcolumncrb(qbool willalter);
	virtual		qbool	 attrib(tqitemref* item, attnumber anum1, attnumber anum2, attnumber anum3, valpasstype& vpt, fldval& fval);
	virtual	tqfWndopen* getCwind(); // rmm4279
	virtual		void 	getInstanceInfo(fldval &pInstanceInfo);		// rmm1489: returns instance specific information for storing on disk
	virtual		void	setContainer(fldfnxn& pFnxn);							// rmm10082: Allows the instance to record its container
	virtual		void	setContainer(tqitemref* pItem);						// rmm10403: Allows the instance to record its container
	void			getColsFref(fmtref &pFref) { pFref = mColsFref; }	// rmm2684
	virtual		qbool	construct(const locptype& parmlocp, qbyte* parmadd, qlong parmlen, fldval& retval, qbool dofields=qfalse); // rmm_ws1
	qbool			columnAttrib(tqitemref *item, qshort pColNo, attnumber anum1, attnumber anum2, attnumber anum3, valpasstype& vpt, fldval& fval);	// rmm2897
	tqitemref* makeattitem(const locptype& locp, attnumber anum1, tqitemref* parent1); //DRS5200
	static void setFrefs(fmtref &pFref, fmtref &pColsFref);		// rmm2684: set the frefs needed to create a table instance
	qbool			inSmartOperation() { return mInSmartOperation; }	// rmm5014
	void			setconstructparm(fldval& fval);										// rmm_ws1
	static void	addCol(lsttype *pLst, schemafmt &pWfldSchema, strxxx &pName, tableinst *pInst = 0, strxxx *pServerColumnName = 0, qlong pServerTableIndex = 0);		// rmm2672: add a column to the table // rmm2684 // rmm_ws1: made static and public
	qbool			createdFromSubtype() { return mCreatedFromSubtype; }	// rmm5686
	void			getSqlClassName(str255 &pSqlClassName) { pSqlClassName = mSqlClassName; }	// rmm_rws2
	// Start rmm9613
	void			prepareForNewDefinition()
	{
		mColumnCount = 0;
		mColsFref = qnil;
		mSqlClassName = qnil;
		mPrimaryKeyCount = 0;
	}
	void setColumnCount(qshort pColumnCount)
	{
		mColumnCount = pColumnCount;
	}
	void setPrimaryKeyCount(quint pPrimaryKeyCount)
	{
		mPrimaryKeyCount = pPrimaryKeyCount;
	}
	void setServerTableName(strxxx &pServerTableName);
	// End rmm9613

	friend class DAMworkerParameters;	// rmm10113
	friend class DAMworkerObj;	// rmm10113
};
 
#endif //ndef isXCOMPLIB

// Information stored in the rdef table flags //gra0235 (constants moved here)
// MHMACHTB: cTABflagTableMask et all moved to extdam.he

#endif
