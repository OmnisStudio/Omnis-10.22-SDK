/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/UNIX/OMNISXI/commdlg.h 16861 2017-03-09 09:43:51Z bmitchell $ */

// commdlg.h
//
//Copyright	(C)	Blyth Holdings Inc 1999

/**************** Changes ******************
Date			Edit			Bug						Description
16-Oct-06	rmmcups									Linux: Use CUPS for printing.
17-Sep-99	AEUNIX									Initial implementation
*/

#ifndef _INC_COMMDLG
#define _INC_COMMDLG
#ifdef __cplusplus
extern "C" {
#endif

#include "dlgs.h"

typedef UINT_PTR (APIENTRY *LPOFNHOOKPROC) (HWND, UINT, WPARAM, LPARAM);

typedef struct tagOPENFILENAME
{
   DWORD        lStructSize;
   HWND         hwndOwner;
   HINSTANCE    hInstance;
   LPCSTR       lpstrFilter;
   LPSTR        lpstrCustomFilter;
   DWORD        nMaxCustFilter;
   DWORD        nFilterIndex;
   LPSTR        lpstrFile;
   DWORD        nMaxFile;
   LPSTR        lpstrFileTitle;
   DWORD        nMaxFileTitle;
   LPCSTR       lpstrInitialDir;
   LPCSTR       lpstrTitle;
   DWORD        Flags;
   WORD         nFileOffset;
   WORD         nFileExtension;
   LPCSTR       lpstrDefExt;
   LPARAM       lCustData;
   LPOFNHOOKPROC lpfnHook;
   LPCSTR       lpTemplateName;
} OPENFILENAME, *LPOPENFILENAME;

typedef struct _OFNOTIFY
{
        NMHDR           hdr;
        LPOPENFILENAME lpOFN;
        LPSTR           pszFile;        // May be NULL
} OFNOTIFY, FAR *LPOFNOTIFY;

BOOL  APIENTRY     GetOpenFileName(LPOPENFILENAME);
BOOL  APIENTRY     GetSaveFileName(LPOPENFILENAME);
BOOL	APIENTRY		 GetDirectoryName(LPOPENFILENAME);	// rmmcups
BOOL	OpenFileDlg(HINSTANCE pInstance,HWND pOwner,char* pTitle,char* pFilter,char* pFileName,char* pInitDir,BYTE pDlgType);
void	GetInitialDirectoryAndFilename(LPOPENFILENAME pOpenFileName, char **pInitialFileName, char **pInitialDirectory, char **pInitialMem);	// rmmcups: utility method for internal use
BOOL	ProcessFileDialogResponse(LPOPENFILENAME pOpenFileName, char *pPathname, BOOL pFreePathname, char **pLastFolder);	// rmmcups: utility method for internal use

#define OFN_READONLY                 0x00000001
#define OFN_OVERWRITEPROMPT          0x00000002
#define OFN_HIDEREADONLY             0x00000004
#define OFN_NOCHANGEDIR              0x00000008
#define OFN_SHOWHELP                 0x00000010
#define OFN_ENABLEHOOK               0x00000020
#define OFN_ENABLETEMPLATE           0x00000040
#define OFN_ENABLETEMPLATEHANDLE     0x00000080
#define OFN_NOVALIDATE               0x00000100
#define OFN_ALLOWMULTISELECT         0x00000200
#define OFN_EXTENSIONDIFFERENT       0x00000400
#define OFN_PATHMUSTEXIST            0x00000800
#define OFN_FILEMUSTEXIST            0x00001000
#define OFN_CREATEPROMPT             0x00002000
#define OFN_SHAREAWARE               0x00004000
#define OFN_NOREADONLYRETURN         0x00008000
#define OFN_NOTESTFILECREATE         0x00010000
#define OFN_NONETWORKBUTTON          0x00020000
#define OFN_NOLONGNAMES              0x00040000
#define OFN_EXPLORER                 0x00080000     // new look commdlg MHUX001
#define OFN_CHECKCANDELETE					 0x00100000			// rmmcups: special Omnis-specific check if can delete
#define OFN_CUSTDATANEEDSFILTERINDEX 0x00200000			// rmmcups: special Omnis-specific value - custom data is to receive filter index	

#define CDN_FIRST               0x300
#define CDN_INITDONE            (CDN_FIRST - 0x0000)
#define CDN_SELCHANGE           (CDN_FIRST - 0x0001)
#define CDN_FOLDERCHANGE        (CDN_FIRST - 0x0002)
#define CDN_SHAREVIOLATION      (CDN_FIRST - 0x0003)
#define CDN_HELP                (CDN_FIRST - 0x0004)
#define CDN_FILEOK              (CDN_FIRST - 0x0005)
#define CDN_TYPECHANGE          (CDN_FIRST - 0x0006)

#define SNDMSG SendMessage
#define CDM_FIRST       (WM_USER + 100)
#define CDM_SETCONTROLTEXT      (CDM_FIRST + 0x0004)
#define CommDlg_OpenSave_SetControlText(_hdlg, _id, _text) \
        (void)SNDMSG(_hdlg, CDM_SETCONTROLTEXT, (WPARAM)_id, (LPARAM)(LPSTR)_text)
#define CDM_GETSPEC             (CDM_FIRST + 0x0000)
#define CommDlg_OpenSave_GetSpec(_hdlg, _psz, _cbmax) \
        (int)SNDMSG(_hdlg, CDM_GETSPEC, (WPARAM)_cbmax, (LPARAM)(LPSTR)_psz)

#ifdef __cplusplus
}
#endif

#endif

/* EOF */
