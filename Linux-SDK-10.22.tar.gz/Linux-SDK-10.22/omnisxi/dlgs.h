/* $Header:   K:\vcs\v4new\unix\omnisxi\dlgs.h_v   1.2   19 Oct 2000 10:59:56   AEVANS  $ */

// dlgs.h
//
//Copyright	(C)	Blyth Holdings Inc 1999

/**************** Changes ******************
Date			Edit			Bug						Description
17-Sep-99	AEUNIX									Initial implementation
*/

#define lst1   0x0460    // filelist
#define lst2   0x0461    // dirlist
#define cmb1   0x0470    // Type list
#define edt1   0x0480    // edit field
#define stc3   0x0442    // File name label
#define psh1   0x0400
#define pmenut1 0x0462   // Popmenu label
#define pmenu1 0x0463   // Popmenu 
