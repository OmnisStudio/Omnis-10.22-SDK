#! /bin/sh

export LD_LIBRARY_PATH=`pwd`/omnisxi:$LD_LIBRARY_PATH
export V4DIR=`pwd`/omnisxi
export OMNISRC=`pwd`/omnisrc
export PATH=$PATH:$OMNISRC
sed -i 's|Template=.*|Template='`pwd`'/omnisrc/omnisrc.tpl|' `pwd`/omnisrc/omnisrc.ini
sed -i 's|IncludeDirs=.*|IncludeDirs='`pwd`'/omnisxi|' `pwd`/omnisrc/omnisrc.ini

rm -f -r releaseuni-headless
mkdir releaseuni-headless
mkdir releaseuni-headless/xcomp

echo
echo ==== BuildAll ====
echo LD_LIBRARY_PATH is $LD_LIBRARY_PATH
echo V4DIR is $V4DIR
echo OMNISRC is $OMNISRC
echo Headless XCOMP components will be in `pwd`/releaseuni-headless/xcomp

echo
echo ==== Headless CALENDAR ====
cd calendar
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless DAMGENRC ====
cd damgenrc
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless DOCVIEW ====
cd docview
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless FILEOPS ====
cd fileops
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless FONTOPS ====
cd fontops
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless GENERIC ====
cd generic
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless GENERIC2 ====
cd generic2
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless GENERIC3 ====
cd generic3
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless GENERIC4 ====
cd generic4
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless HTML ====
cd html
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless ICNARRAY ====
cd icnarray
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless MARQUEE ====
cd marquee
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless OCLOCK ====
cd oclock
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless OMNISICN ====
cd omnisicn
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless PICLIST ====
cd piclist
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless PROGRESS ====
cd progress
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless SLIDER ====
cd slider
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless TILE ====
cd tile
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless WASH ====
cd wash
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless WORKER ====
cd worker
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless ZOOM ====
cd zoom
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/xcomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ============
echo = Finished =
echo ============
