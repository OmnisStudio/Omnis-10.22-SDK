/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/WASH/wash.cpp 20427 2018-07-19 08:03:36Z bmitchell $ */

/*************** changes *******************
Date			Edit				Bug					Description
17-Jul-09	rmm6670									Use gradient brush to draw wash.
25-Apr-08	rmm_mobile							Mobile device support
21-Mar-07	rmm6020									Fixed MacOSX memory leak in wash component.
11-Jul-03 MHn0254			ST/GS/094		Fixed wash control for OSX.
23-Apr-01 AE5203									Added ECOinvalBackObj
14 MAR 01 mpmCarbon37							background objects must not redraw, always invalidate, so sibling background objects are redrawn
26-Jun-00 MHCARBON								OSX Changes.
04-Oct-99	rmm3478									Added function to return version via version resource.
14-Apr-99 MHn0074									Wash web conponent version 1.0.
*/

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>
#include <gdi.he>
#include "wash.he"

#include <time.h>
#include <math.h>
#include <string.h>          
#include <stdlib.h>

#define COMPONENT_COUNT 	1				/* Number of controls within library */

#ifdef isWEB
#define LIB_RES_NAME  		1001		/* Resource id of library name */
#define WASH_ID						2001		/* Resource id of control within library */
#else
#define LIB_RES_NAME  		1000		/* Resource id of library name */
#define WASH_ID						2000		/* Resource id of control within library */
#endif

#define WASH_ICON 				1				/* Resource bitmap id */

const qshort
				cStartColor 			= 1,		// wash starting color
				cEndColor 				= 2,		// wash ending color
				cDirection 				= 3,		// wash direction
// ------------------------------------------------------------------------------------------
				cWashDown					= 0,
				cWashUp						= 1,
				cWashRight				= 3;


ECOproperty WASHproperties[3] =
{ 
	cStartColor,			4000, 	fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,
	cEndColor,				4001, 	fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,
	cDirection,				4002,		fftInteger, EXTD_FLAG_EXTCONSTANT, 0, 7000, 7003
};

          
// ---------------------------------------------------------------------------------------------------------
tqfWash::tqfWash( HWND pFieldHWnd )
{
	mHWnd = pFieldHWnd;
  mStartColor = GDI_COLOR_QBLUE;
  mEndColor = GDI_COLOR_QBLACK;
	mIsRealHWND = qtrue;
	mDirection = cWashDown;
  
  mStartColorAlpha = mEndColorAlpha = 255;
}

tqfWash::~tqfWash()
{
}

qlong tqfWash::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( pMessage )
	{ 
		case ECM_PROPERTYCANASSIGN: 
		{
			return 1L;
		}
		case ECM_SETPROPERTY: 
		{       
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( param )
			{
				EXTfldval fval( (qfldval)param->mData );
				switch( ECOgetId(eci) )
				{
          // for true color alpha support we now use a long64 instead of a long to store the color and alpha - help functions separate the two parts
          case cStartColor:  { qlong alpha = 255; GDIgetFldvalColorAndAlpha(fval,mStartColor,alpha); mStartColorAlpha = alpha; break; } // mStartColor = (qcol)fval.getLong();
          case cEndColor:		 { qlong alpha = 255; GDIgetFldvalColorAndAlpha(fval,mEndColor,alpha); mEndColorAlpha = alpha; break; } // mStartColor = (qcol)fval.getLong();
					case cDirection:	mDirection = fval.getLong(); break;
				}      
				if ( mIsRealHWND ) WNDinvalidateRect( mHWnd, NULL ); // mpmCarbon37 WNDredrawWindow( mHWnd, NULL, NULL, WND_RW_PAINT );
				else ECOinvalBackObj(); // ae5203
				return 1L;
			}
			break;
		}
		case ECM_GETPROPERTY: 
		{
			EXTfldval fval;
			switch( ECOgetId(eci) )
			{
        // for true color alpha support we now use a long64 instead of a long to store the color and alpha - help functions separate the two parts
        // if we return only a long using the commented setlong code, the property inspector will not support/show alpha on its color popup.
        case cStartColor: 			GDIsetFldvalColorAndAlpha(fval,mStartColor, mStartColorAlpha ); break; //fval.setLong( (qlong)mStartColor );
				case cEndColor: 				GDIsetFldvalColorAndAlpha(fval,mEndColor, mEndColorAlpha ); break; // fval.setLong( (qlong)mEndColor );
				case cDirection:				fval.setLong( (qlong)mDirection ); break;
			}         
			ECOaddParam(eci,&fval);
			return 1L;
		}
	}
	return 0;
}

// rmm6670
qbool tqfWash::paint(HDC hdc, qrect* pArea)
{
	qpat pat = patGrad1;	// Left to right
	if (cWashRight == mDirection) pat = patGrad2;
	else if (cWashDown == mDirection) pat = patGrad3;
	else if (cWashUp == mDirection) pat = patGrad4;
	HBRUSH gradBrush = GDIcreateBrush(pat);

  // for true color alpha support we now need to use GDIshapeContext during drawing - the input to this is an HDC and drawrect.
  // we must then use the GDIshapeContext hdc and drawrect for drawing.
  GDIshapeContext sc(hdc, *pArea);
	#ifndef isunix
  	qbyte oldTextAlpha = GDIsetTextColorAlpha(sc.drawHdc(), (qbyte)mStartColorAlpha);
	  qbyte oldBackAlpha = GDIsetBkColorAlpha(sc.drawHdc(), (qbyte)mEndColorAlpha);
	#endif
  
  qcol oldTextColor = GDIgetTextColor(sc.drawHdc());
	qcol oldBkColor = GDIgetBkColor(sc.drawHdc());
		
	GDIsetTextColor(sc.drawHdc(), GDIgetRealColor(mStartColor));
	GDIsetBkColor(sc.drawHdc(), GDIgetRealColor(mEndColor));
  
  // here in true alpha mode we are using the GDIshapeContext hdc and drawrect
	GDIfillRect(sc.drawHdc(), sc.drawRect(), gradBrush);

	GDIsetTextColor(sc.drawHdc(), oldTextColor);
	GDIsetBkColor(sc.drawHdc(), oldBkColor);
  
	#ifndef isunix
  	GDIsetTextColorAlpha(sc.drawHdc(), oldTextAlpha);
  	GDIsetBkColorAlpha(sc.drawHdc(), oldBackAlpha);
	#endif

	GDIdeleteObject(gradBrush);

  // at the end of this function, when GDIshapeContext naturally destructs it will append to the original HDC the alpha drawn content.

	return qtrue;
}

extern "C" LRESULT OMNISWNDPROC GenericWndProc( HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
   ECOsetupCallbacks( hwnd, eci );
	 switch (Msg)
	 {
			case ECM_GETVERSION:	// rmm3478
			{
				return ECOreturnVersion(gInstLib);
			}                                                                 
			
			case WM_ERASEBKGND:
			{
				return 1L;
			}

			case ECM_PRINT:
			{
				tqfWash* object = (tqfWash*)ECOfindObject( eci, hwnd, wParam );
				WNDpaintStruct* paintStruct = (WNDpaintStruct*)lParam;
				if ( object ) object->paint( paintStruct->hdc, &paintStruct->rcPaint );
				return qtrue;
				break;
			}
			
			case ECM_BOBJ_EXERASE: return 1L;

			case ECM_OBJCONSTRUCT:				
			{
				tqfWash* object = new tqfWash( hwnd );
				object->mIsRealHWND = !(wParam & ECM_WFLAG_NOHWND);
				ECOinsertObject( eci, hwnd, (void*)object, wParam  );
				return qtrue;
			}
			case ECM_OBJDESTRUCT:					
			{
				tqfWash* object = (tqfWash*)ECOremoveObject( eci, hwnd, wParam  );
				if ( NULL!=object ) delete object;
				return qtrue;
			}
			case ECM_PROPERTYCANASSIGN:  	
			case ECM_SETPROPERTY: 				
			case ECM_GETPROPERTY:					
			{
				tqfWash* object = (tqfWash*)ECOfindObject( eci, hwnd, wParam  );
				if ( object ) return object->attributeSupport( Msg, wParam, lParam, eci );
				return 0L;
			}
      case ECM_GETCOMPLIBINFO:
      {
      	return ECOreturnCompInfo( gInstLib, eci, LIB_RES_NAME, COMPONENT_COUNT );
      }
			case ECM_GETCOMPICON:
			{ 	
				if ( eci->mCompId==WASH_ID ) return ECOreturnIcon( gInstLib, eci, WASH_ICON );
				return qfalse;
			}
			case ECM_GETCOMPID:
			{
				if ( wParam==1 ) return ECOreturnCompID( gInstLib, eci, WASH_ID, cObjType_Basic );
				return 0L;
			}
			case ECM_GETPROPNAME:
			{
				return ECOreturnProperties( gInstLib, eci, &WASHproperties[0], 3 );
			}                                                                                 
			case ECM_GETCONSTNAME:
			{
				return ECOreturnConstants( gInstLib, eci, 7000, 7003 );
			}
			case ECM_CONNECT:
			{
				#ifdef isRCCDESIGN
					return EXT_FLAG_LOADED|EXT_FLAG_ALWAYS_USABLE|EXT_FLAG_REMAINLOADED|EXT_FLAG_BCOMPONENTS; // Return external flags	// rmm_thindl
				#else
					return EXT_FLAG_LOADED | EXT_FLAG_BCOMPONENTS;
				#endif
			}
			case ECM_ISUNICODE:	// rmmuni
			{
				return qtrue;
			}
			// MHn0074 begins.
#ifdef isWEB
			case ECM_GETCOMPSTOREGROUP:
			{
				ECOreturnCStoreGrpName( gInstLib, eci, 2010 );
				return 1L;
			}	
#endif
			// MHn0074 ends.			
	 }
	 return WNDdefWindowProc(hwnd,Msg,wParam,lParam,eci);
}

// End of file
