/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/DOCVIEW/wprtfutl.cpp 25523 2020-02-19 14:01:43Z jgissing $ */
/**************** Changes ******************
Date			Edit				Bug					Description
19-Aug-13	rmm64bitux							Linux 64 bit port.
18-Apr-05	rmm5334			UN/IE/092		...continued: $importencoding and $exportencoding.
14-Apr-05	rmm5333			UN/IE/092		Unicode version import-export now supports different Ansi code pages.
17-Jan-05	rmm5254			UN/EC/883		Improved Unicode character support when viewing RTF in the Unicode version.
08 NOV 99 mlr0006									Initial version for Rtf support
********************************************/

/* these are supporting classes to read an rtf document .
called from the main WPRtfClass .
*/
// rmm64bitux: Replaced long with qlong
 // Start jmg_includecasing
#ifndef _extcomp_
#include "extcomp.he"
#endif

#ifndef	_WPHTML_HE_
#include "wphtml.he"
#endif

#ifndef	_WPPARA_HE_
#include "wppara.he"
#endif

#ifndef	_WPTEXT_HE_
#include "wptext.he"
#endif

#ifndef	_WPIMAGE_HE_
#include "wpimage.he"
#endif

#ifndef	_WPTABLE_HE_
#include "wptable.he"
#endif

#ifndef	_WPXCOMP_HE_
#include "wpxcomp.he"
#endif

#ifndef	_WPRTF_HE_
#include "wprtf.he"
#endif
// End jmg_includecasing

// rmm5334:
#ifndef _dmconst_
	#include "dmconst.he"
#endif

#include "wprtfutl.he"

// This contains general generic helper classes for the rtf parser.
// WPRtfClass In general these are read from the header of an rtf file
// and then  stored in a singly linked list & retieved using a
// find method. A pointer to each of these classes is held in the 
//  WPRtfClass .

eWPAlign convRtfAlignToeWPAlign(qlong align);	// rmm64bitux

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
wpRtfColorTab::wpRtfColorTab()
{
	next = NULL ;
	mNumber = 0 ;
	mRed = 0 ;
	mGreen = 0 ;
	mBlue =0 ;
}

wpRtfColorTab::~wpRtfColorTab()
{
	if ( this->next != NULL )
		delete this->next;
}

void wpRtfColorTab::setColor(qlong red,qlong green,qlong blue)
{
	mRed = red ;
	mGreen = green;
	mBlue = blue;
}
wpRtfColorTab *wpRtfColorTab::addColor(qlong red,qlong green,qlong blue)
{
	wpRtfColorTab* tempNext = this ;
	while ( tempNext->next != NULL)
	{
		tempNext = tempNext->next ;
	}
	tempNext->next = new wpRtfColorTab() ;
	tempNext->next->mNumber = tempNext->mNumber + 1 ;
	tempNext->next->mRed = red ;
	tempNext->next->mGreen = green ;
	tempNext->next->mBlue = blue ;
	return tempNext->next;
}
wpRtfColorTab * wpRtfColorTab::findColor(qlong NoToFind)
{
	wpRtfColorTab *tempColor = this ;
	while ( ( tempColor != NULL ) && ( tempColor->mNumber != NoToFind ))
	{
		tempColor = tempColor->next ;
	}
	return tempColor ;
}

wpRtfFontTab::wpRtfFontTab()
{
	next = NULL ;
	mFontNumber = 0 ;
	mAnsiCodePageTable = 0;	// rmm5254: code page table corresponding to font charset
}

wpRtfFontTab::~wpRtfFontTab()
{

	if ( this->next != NULL )
		delete this->next;
}

void wpRtfFontTab::setFont(qshort rtfFontNumber, qshort gdiFntNo, qshort pCharset) // rmm5254
{
	mFontNumber = rtfFontNumber ;
	mGdiFnt = gdiFntNo ;
	// rmm5254: the following table taken from the Microsoft support site shows how charsets correspond to code pages.
	// rmm5254: we use this table to map the charset to a mapping table for the code page (where possible)
	// DEFAULT_CHARSET           1 (x01)
	// SYMBOL_CHARSET            2 (x02)
	// OEM_CHARSET             255 (xFF)
	// ANSI_CHARSET              0 (x00)            1252
	// RUSSIAN_CHARSET         204 (xCC)            1251
	// EE_CHARSET              238 (xEE)            1250
	// GREEK_CHARSET           161 (xA1)            1253
	// TURKISH_CHARSET         162 (xA2)            1254
	// BALTIC_CHARSET          186 (xBA)            1257
	// HEBREW_CHARSET          177 (xB1)            1255
	// ARABIC _CHARSET         178 (xB2)            1256
	// SHIFTJIS_CHARSET        128 (x80)             932
	// HANGEUL_CHARSET         129 (x81)             949
	// GB2313_CHARSET          134 (x86)             936
	// CHINESEBIG5_CHARSET     136 (x88)             950
		
	// In addition, we map 77 (MAC_CHARSET) to gANSI10000
	// rmm5333: use CHRconvFromAnsiCodePage::getCodePage
	// rmm5334:
	mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiLatin1);	// Use Latin-1 as default
	switch (pCharset)
	{
		case 0:		// ANSI
		case 1:		// Default
			// Use the default for these
			break;
		case 2:		// Symbol
			// Note - use the default for Windows symbol charset
			#ifdef ismac
				mAnsiCodePageTable = 	gANSISymbol;
			#endif
			break;
		case 77:	// Mac
			mAnsiCodePageTable = gANSI10000;
			break;
		case 161:	// Greek
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiGreek);
			break;
		case 162:	// Turkish
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiTurkish);
			break;
		case 163:	// Vietnamese
			// Not in the table above, but this looks correct to me.
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiVietnamese);
			break;
		case 177:	// Hebrew
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiHebrew);
			break;
		case 178:	// Arabic
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiArabic);
			break;
		case 186:	// Baltic
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiBaltic);
			break;
		case 204:	// Russian
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiCyrillic);
			break;
		case 222:	// Thai
			// Not in the table above, but this looks correct to me.
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiThai);
			break;
		case 238:	// Eastern European
			mAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiCentralEuropean);
			break;
		case 128:	// Shift Jis
		case 129:	// Hangul
		case 130:	// Johab
		case 134:	// GB2312
		case 136:	// Big5
		case 179:	// Arabic Traditional
		case 180:	// Arabic user
		case 181:	// Hebrew user
		case 254:	// PC 437
		case 255:	// OEM
			// These are not really supported - use the default table
			break;
	}	
}

wpRtfFontTab *wpRtfFontTab::addFont(qshort rtfFontNumber, qshort gdiFntNo, qshort pCharset) // rmm5254
{
	wpRtfFontTab* tempNext = this;
	while ( tempNext->next != NULL)
	{
		tempNext = tempNext->next;
	}
	tempNext->next = new wpRtfFontTab();
	tempNext->next->setFont(rtfFontNumber, gdiFntNo, pCharset);	// rmm5254
	return tempNext->next;
}

short wpRtfFontTab::findFont(qshort NoToFind, qushort **pAnsiCodePageTable)
{
	wpRtfFontTab *tempFont = this ;
	while ( ( tempFont != NULL ) && ( tempFont->mFontNumber != NoToFind ))
	{
		tempFont = tempFont->next ;
	}
	// what if not found ? return first one 
	// Start rmm5254
	if (tempFont)
	{
		*pAnsiCodePageTable = tempFont->mAnsiCodePageTable;	// Latin-1 is default
		return tempFont->mGdiFnt;
	}
	else 
	{
		*pAnsiCodePageTable = CHRconvFromAnsiCodePage::getCodePage(preUniTypeAnsiLatin1);	// Latin-1 is default // rmm5333 // rmm5334
		return mGdiFnt;
	}
	// End rmm5254
}

wpRtfListTab::wpRtfListTab()
{
	next = NULL ;
	mBullet =  eWPbulletNone;
	mListId = 0 ;
	mStartLev = 0 ;
	mListNo = 0;
}

wpRtfListTab::~wpRtfListTab()
{

	if ( this->next != NULL )
		delete this->next;
}
eWPAlign convRtfAlignToeWPAlign(qlong allign)	// rmm64bitux
{
	switch ( allign)
	{
		case (0) : // left
			return eWPHAleft ;
			break;
		case (1) : // left
			return eWPHAcenter ;
			break;
		case (2) : // right
			return eWPHAright ;
			break;
	}
	return eWPHAleft ;
}
void wpRtfListTab::setList (qlong listId,eWPbullet bullType,
qlong rtfAlign,qshort indent,qshort startLev)
{
		mBullet = bullType ;
		mListId = listId ;
		mStartLev = startLev ;
		mIndent = indent;
		mAllign = convRtfAlignToeWPAlign(rtfAlign);
}

void wpRtfListTab::setListNo (qlong listNo)
{
	mListNo = listNo ;
}
wpRtfListTab *wpRtfListTab::addList(qlong listId, eWPbullet bullType,
qlong rtfAlign,qshort indent,qshort startLev)
{
	wpRtfListTab* tempNext = this ;
	while ( tempNext->next != NULL)
	{
		tempNext = tempNext->next ;
	}
	tempNext->next = new wpRtfListTab() ;
	tempNext->next->mBullet = bullType ;
	tempNext->next->mListId = listId ;
	tempNext->next->mStartLev = startLev ;
	tempNext->next->mAllign = convRtfAlignToeWPAlign(rtfAlign);
	tempNext->next->mIndent = indent;
	return tempNext->next;
}
wpRtfListTab *wpRtfListTab::findList(qlong NoToFind)
{
	wpRtfListTab *tempList = this ;
	while ( ( tempList != NULL ) && ( tempList->mListNo != NoToFind ))
	{
		tempList = tempList->next ;
	}
	// what if not found ? return first one 
	return tempList;

}
wpRtfListTab *wpRtfListTab::findListId(qlong listId)
{
	wpRtfListTab *tempList = this ;
	while ( ( tempList != NULL ) && ( tempList->mListId != listId ))
	{
		tempList = tempList->next ;
	}
	return tempList;

}
eWPbullet wpRtfListTab::transRtfLevToBull(qlong rtfNumber)
{
	switch ( rtfNumber )
	{
		case 0 : // Arabic 1,2,3 
			return(eWPbulletNumeral);
			break;
		case 1 : //Upercase Roman i,ii
			return(eWPbulletUppCaseRoman);
			break;
		case 2 : //Lowercase Roman i,ii
			return(eWPbulletLowCaseRoman);
			break;
		case 3 : // Upper case Roman letter A,B
			return(eWPbulletUppCase);
			break;
		case 4 : //Lowercase letter a,b,c
			return(eWPbulletLowCase);
			break;
		case 5 : // Ordinal num 1st,2nd,3rd
		case 6 : //Cardinal text no one,Two Three
		case 7 : // Ordinal text first second,third
		case 22 : // Arabic with leading zero 01,02 
			return(eWPbulletNumeral);
			break;
		case 23 : // no number 
			return(eWPbulletDisc);
			break;
		default :
		return(eWPbulletNumeral);
		break;
	} // end of switch
	// should never get here
	return(eWPbulletNumeral);
} // end of transRtfLevToBull


wpRtfParaStyleTab::wpRtfParaStyleTab()
{
	next = NULL ;
	mParaStyleNo = 0 ;
	mSetFlag = 0;
}

wpRtfParaStyleTab::~wpRtfParaStyleTab()
{

	if ( this->next != NULL )
		delete this->next;
}

void wpRtfParaStyleTab::setParaStyle(qlong styleNo,
WPParagraphInfoStruct * inputPara,qlong setFlag)
{
	mParaStyleNo = styleNo ;
	mParInfo = *inputPara ;
	mSetFlag = setFlag ;
}

wpRtfParaStyleTab *wpRtfParaStyleTab::addParaStyle(qlong styleNo,
WPParagraphInfoStruct * inputPara,qlong setFlag)
{
	wpRtfParaStyleTab* tempNext = this ;
	while ( tempNext->next != NULL)
	{
		tempNext = tempNext->next ;
	}
	tempNext->next = new wpRtfParaStyleTab() ;
	tempNext->next->mParaStyleNo = styleNo ;
	tempNext->next-> mParInfo = *inputPara ;
	tempNext->next-> mSetFlag = setFlag ;
	return tempNext->next;
}
wpRtfParaStyleTab* wpRtfParaStyleTab::findParaStyle(qlong styleNo)
{
	wpRtfParaStyleTab *tempStyle = this ;
	while ( ( tempStyle != NULL ) && ( tempStyle->mParaStyleNo != styleNo ))
	{
		tempStyle = tempStyle->next ;
	}
	return tempStyle;
}

wpRtfTextStyleTab::wpRtfTextStyleTab()
{
	next = NULL ;
	mTextStyleNo = 0 ;
}

wpRtfTextStyleTab::~wpRtfTextStyleTab()
{

	if ( this->next != NULL )
		delete this->next;
}
void wpRtfTextStyleTab::setTextStyle(qlong styleNo,
	WPTextInfoStruct * inputText)
{
	mTextStyleNo = styleNo ;
	mTextInfo = *inputText ;
}
wpRtfTextStyleTab *wpRtfTextStyleTab::addTextStyle(qlong styleNo,
WPTextInfoStruct * inputText)
{
	wpRtfTextStyleTab* tempNext = this ;
	while ( tempNext->next != NULL)
	{
		tempNext = tempNext->next ;
	}
	tempNext->next = new wpRtfTextStyleTab() ;
	tempNext->next->mTextStyleNo = styleNo ;
	tempNext->next-> mTextInfo = *inputText ;
	return tempNext->next;
}
WPTextInfoStruct* wpRtfTextStyleTab::findTextStyle(qlong styleNo)
{
	wpRtfTextStyleTab *tempText = this ;
	while ( ( tempText != NULL ) && ( tempText->mTextStyleNo != styleNo ))
	{
		tempText = tempText->next ;
	}
	if ( tempText != NULL )
		return &(tempText->mTextInfo);
	else
		return NULL;
}
cellInfoStack::cellInfoStack()
{
	next = NULL ;
}

cellInfoStack::~cellInfoStack()
{

	if ( this->next != NULL )
		delete this->next;
}
void cellInfoStack::clear(void)
{
	if ( next != NULL)
		delete next;
	next = NULL;
}
cellInfoStack* cellInfoStack::nextCellInfo(void)
{
	return next;
}
void cellInfoStack::add(WPTableCellInfoStruct inputInfo)
{
	cellInfoStack* tempNext = this ;
	while ( tempNext->next != NULL)
	{
		tempNext = tempNext->next ;
	}
	tempNext->next = new cellInfoStack() ;
	tempNext->next->mCellInfo = inputInfo ;
}

wpRtfImgFilesCreated::wpRtfImgFilesCreated()
{
	next = NULL ;
}
wpRtfImgFilesCreated::wpRtfImgFilesCreated(str255 filename)
{
	next = NULL ;
	mFilename =  filename;
}
wpRtfImgFilesCreated::~wpRtfImgFilesCreated()
{

	if ( this->next != NULL )
		delete this->next;
	if ( mFilename.length() > 0 )
	{
		EXTfile pictFile ;
		pictFile.deleet(mFilename);
		mFilename=QTEXT("");
	}
}
void wpRtfImgFilesCreated::addFile(str255 filename)
{
	wpRtfImgFilesCreated* tempNext = this ;
	while ( tempNext->next != NULL)
	{
		tempNext = tempNext->next ;
	}
	tempNext->next = new wpRtfImgFilesCreated() ;
	tempNext->next->mFilename =  filename;
}
