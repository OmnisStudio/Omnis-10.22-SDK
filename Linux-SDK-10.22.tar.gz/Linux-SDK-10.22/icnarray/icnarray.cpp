/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/ICNARRAY/icnarray.cpp 18481 2017-11-24 08:19:42Z bmitchell $ */

/*********************************** Changes ***********************************
Date			Edit				Bug					Description
23 NOV 01	mpm5031									New platform independent hiliting
*********************************************************************************/

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>
#include <gdi.he>
#include "icnarray.he"

const qshort
				cStyleColNum 				= 1,
				cColorColNum				=	2;

ECOproperty ICNARRAYproperties[2] =
{ 
	cStyleColNum,			4000, 	fftInteger, EXTD_FLAG_PROPDATA, 0, 0, 0,
	cColorColNum,			4001, 	fftInteger, EXTD_FLAG_PROPDATA, 0, 0, 0
};


tqfIconArrayObject::tqfIconArrayObject( HWND pFieldHWnd )
{
	mHWnd = pFieldHWnd;
	mStyleColumn = 3;
	mColorColumn = 4;
	mIsSetup = qfalse;
}

tqfIconArrayObject::~tqfIconArrayObject()
{
}

qlong tqfIconArrayObject::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( pMessage )
	{ 
		case ECM_GETVERSION:
		{
			return ECOreturnVersion( 1, 1 ); // mpm5031
		}
		case ECM_PROPERTYCANASSIGN: 
		{
			return 1L;
		}
		case ECM_SETPROPERTY: 
		{       
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( param )
			{
				EXTfldval fval( (qfldval)param->mData );
				switch( ECOgetId(eci) )
				{
					case cStyleColNum: 			mStyleColumn = (qshort)fval.getLong(); break; 			
					case cColorColNum: 			mColorColumn = (qshort)fval.getLong(); break;
				}       
				return 1L;
			}
			break;
		}
		case ECM_GETPROPERTY: 
		{
			EXTfldval fval;
			switch( ECOgetId(eci) )
			{
				case cStyleColNum: 			fval.setLong( (qlong)mStyleColumn ); break; 			
				case cColorColNum: 			fval.setLong( (qlong)mColorColumn ); break; 			
			}         
			ECOaddParam(eci,&fval);
			return 1L;
		}
	}
	return 0;
}

// Draw the icon of the  entry
qbool tqfIconArrayObject::drawIconEntry( EXTIconArrayInfo* pEntryInfo, EXTCompInfo* pEci )
{
	qbool doDraw=!ECOisDesign(mHWnd);	
	if ( doDraw )
	{
		EXTfldval fval;
		ePicSize picSize;
		EXTqlist* extqlist=(EXTqlist*)pEntryInfo->mListPtr;

		extqlist->getColValRef(pEntryInfo->mLine, 1, fval, qfalse );
		EXTBMPref bmp( fval.getLong() );
		
		picSize = ePic16;
		if ( !pEntryInfo->mSmallIcons )
		{	
			if ( bmp.hasSize(ePic48) )
			{
				picSize = ePic48;
			}
			else if ( bmp.hasSize(ePic32) )
			{
				picSize = ePic32;
			}				
		}
		qcol hiliteCol = colNone;
		if (pEntryInfo->mSelected )
		{
			if ( !pEntryInfo->mDragging ) hiliteCol = GDI_COLOR_HIGHLIGHT;
		}
		bmp.draw( pEntryInfo->mHdc, &pEntryInfo->mDrawRect, picSize, picNormal, qfalse, hiliteCol, qfalse, jstCenter, jstCenter );

		// return qtrue as we have dealt with with it
		return qtrue;
	}
	// Do the default Icon Drawing
	return qfalse;
}

// Draw the text of the  entry
qbool tqfIconArrayObject::drawTextEntry( EXTIconArrayInfo* pEntryInfo, EXTCompInfo* pEci )
{
	qbool doDraw=!ECOisDesign(mHWnd);	
	if (pEntryInfo && doDraw )	// Ensure parameter & line information are present
	{
		str255 text;
		EXTfldval fval;
		EXTqlist* extqlist=(EXTqlist*)pEntryInfo->mListPtr;

		extqlist->getColValRef(pEntryInfo->mLine, 2, fval, qfalse );
		fval.getChar(text);

		// Deal with the style of the Text Entry
		HFONT oldFont = NULL;
		extqlist->getColValRef(pEntryInfo->mLine, mStyleColumn, fval, qfalse );
		qsty style = (qsty)fval.getLong();
		if ( style != styNone )
		{
			HFONT styledFont = GDIcreateFont ( &mTextSpec.mFnt, style );
			oldFont = GDIselectObject ( pEntryInfo->mHdc, styledFont );
		}

		// Deal with the color of the Text Entry
		extqlist->getColValRef(pEntryInfo->mLine, mColorColumn, fval, qfalse );
		qcol textColor = fval.getLong();
		if ( textColor == 0 ) textColor= mTextSpec.mTextColor;
		
		qshort length = text.length();
		GDItextBox(pEntryInfo->mHdc, &pEntryInfo->mDrawRect, text.cString(), &length, text.maxLength(), pEntryInfo->mSmallIcons ? jstLeft : jstCenter, qfalse);
		
		// Update length of text, using value returned by GDItextBox.
		text[0] = (qchar) length;	

		
		// Highlight the rectangle if the line is selected
		if ( pEntryInfo->mSelected && !pEntryInfo->mDragging) // mpm5031
			GDIhiliteTextStart( pEntryInfo->mHdc, &pEntryInfo->mDrawRect, textColor ); // mpm5031
		else
			GDIsetTextColor( pEntryInfo->mHdc, textColor ); // mpm5031a

		// Now draw the text of the icon array.
		GDIdrawText(pEntryInfo->mHdc, pEntryInfo->mDrawRect.left, pEntryInfo->mDrawRect.top, &text[1], text.length(), jstLeft);

		// restore & deleted the created font.
		if ( oldFont )
		{
			GDIdeleteObject ( GDIselectObject(pEntryInfo->mHdc, oldFont) );
		}
		
		if ( pEntryInfo->mSelected && !pEntryInfo->mDragging) // mpm5031
			GDIhiliteTextEnd( pEntryInfo->mHdc, &pEntryInfo->mDrawRect, textColor ); // mpm5031

		// Draw the focus rectangle
		if ( pEntryInfo->mDrawFocus )
		{                     
			// Set the colours so that the focus rectangle draws correctly
			GDIsetTextColor( pEntryInfo->mHdc, pEntryInfo->mSelected ? GDI_COLOR_HIGHLIGHTTEXT : textColor );
			GDIsetBkColor( pEntryInfo->mHdc, pEntryInfo->mSelected ? GDI_COLOR_HIGHLIGHT : mBackColor );
			GDIdrawFocusRect( pEntryInfo->mHdc, &pEntryInfo->mDrawRect );
		}
		// return qtrue as we have dealt with with it
		return qtrue;
	}
	// return qfalse as we haven't dealt with with it
	return qfalse;
}

void tqfIconArrayObject::getFillInfo()
{
	EXTfldval fval;
	ECOgetProperty( mHWnd, anumForecolor, fval );	
	mForeColor = fval.getLong();

	ECOgetProperty( mHWnd, anumBackcolor, fval );	
	mBackColor = fval.getLong();

	ECOgetProperty( mHWnd, anumBackpattern, fval );	
	mFillPat = (qpat) fval.getLong();
}

void tqfIconArrayObject::getTextSpec()
{
	EXTfldval fval,fval2;

	ECOgetProperty( mHWnd, anumFont, fval );	
	ECOgetProperty( mHWnd, anumFontsize, fval2 );	
	ECOgetFont	( mHWnd , &mTextSpec.mFnt, (qshort) fval.getLong(), (qshort) fval2.getLong() );

	ECOgetProperty( mHWnd, anumFontstyle, fval );	
	mTextSpec.mSty = (qsty)fval.getLong();

	ECOgetProperty( mHWnd, anumAlign, fval );	
	mTextSpec.mJst = (qjst)fval.getLong();

	ECOgetProperty( mHWnd, anumTextColor, fval );	
	mTextSpec.mTextColor = (qcol)fval.getLong();
}
	
/* Component library entry point (name as declared in resource) */
extern "C" LRESULT OMNISWNDPROC IconArrayWndProc(HWND hwnd, UINT Msg,WPARAM wParam,LPARAM lParam,EXTCompInfo* eci)
{
   ECOsetupCallbacks(hwnd,eci);		/* Initialize callback tables */
	 switch (Msg)
	 {
			case ECM_TEXTDRAWENTRY:   /* Draw Text Entry */
			{
				tqfIconArrayObject* object = (tqfIconArrayObject*)ECOfindObject( eci, hwnd );
				if ( NULL!=object )
					return object->drawTextEntry( (EXTIconArrayInfo*)lParam, eci );
				break;
			}
			case ECM_ICONDRAWENTRY:   /* Draw Icon Entry */
			{
				tqfIconArrayObject* object = (tqfIconArrayObject*)ECOfindObject( eci, hwnd );
				if ( NULL!=object )
					return object->drawIconEntry( (EXTIconArrayInfo*)lParam, eci );
				break;
			}
			case ECM_OBJCONSTRUCT:				/* Construct an object */
			{
				tqfIconArrayObject* object = new tqfIconArrayObject( hwnd );
				ECOinsertObject( eci, hwnd, (void*)object );
				return qtrue;
			}
			case ECM_OBJDESTRUCT:					/* Destruct the object */
			{
				tqfIconArrayObject* object = (tqfIconArrayObject*)ECOremoveObject( eci, hwnd );
				if ( NULL!=object )
					delete object;
				return qtrue;
			}
      case ECM_OBJINITIALIZE:
      {
 				tqfIconArrayObject* object = (tqfIconArrayObject*)ECOfindObject( eci, hwnd );
				if ( object && wParam )
				{
					object->mIsSetup = qtrue;
					object->getTextSpec();
					object->getFillInfo();
				}
				return qtrue;
			}
      case WM_FLD_FILLCHANGED:	// anumForecolor,anumBackcolor,anumBackpattern have changed 
      {
 				tqfIconArrayObject* object = (tqfIconArrayObject*)ECOfindObject( eci, hwnd );
				if ( object && object->mIsSetup  )
				{
					object->getFillInfo();
				}
				break;
      }
      case WM_FLD_FONTCHANGED:	// anumFont,anumFontsize,anumFontstyle,anumAlign,anumTextColor	have changed
      {
 				tqfIconArrayObject* object = (tqfIconArrayObject*)ECOfindObject( eci, hwnd );
				if ( object && object->mIsSetup  )
				{
					object->getTextSpec();
				}
				break;
  		}
      case ECM_GETCOMPLIBINFO: /* Return component library name & component count */
      {
      	return ECOreturnCompInfo( gInstLib, eci, LIB_RES_NAME, OBJECT_COUNT );
      }
			case ECM_GETCOMPICON: 	/* Return component icon (as a hbitmap) */
			{
				if ( eci->mCompId==OBJECT_ID1 ) return ECOreturnIcon( gInstLib, eci, ICONARRAY_ICON );
				return qfalse;
			}
			case ECM_GETCOMPID:			/* Get the external object name & id (from a sequential wParam) */
			{	
				if ( wParam==1 )
					return ECOreturnCompID( gInstLib, eci, OBJECT_ID1, cObjType_IconArray );
				return 0L;
			}
			case ECM_GETPROPNAME:
			{
				return ECOreturnProperties( gInstLib, eci, &ICNARRAYproperties[0], 2 );
			}                                                                                 
			case ECM_PROPERTYCANASSIGN:  	/* Object: Is the property assignable (ie readonly?) */
			case ECM_SETPROPERTY: 				/* Object: Assignment to a property */
			case ECM_GETPROPERTY:					/* Object: Retrieve value from property */
			{
				tqfIconArrayObject* object = (tqfIconArrayObject*)ECOfindObject( eci, hwnd );
				if ( object )
					return object->attributeSupport( Msg, wParam, lParam, eci );
				return 0L;
			}
	 }
	 return WNDdefWindowProc(hwnd,Msg,wParam,lParam,eci);
}

/* EOF */
