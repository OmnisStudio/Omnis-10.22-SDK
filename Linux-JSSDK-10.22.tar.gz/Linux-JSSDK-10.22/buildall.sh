#! /bin/sh

export LD_LIBRARY_PATH=`pwd`/jscomp/omnisxi:$LD_LIBRARY_PATH
export V4DIR=`pwd`/jscomp/omnisxi
export OMNISRC=`pwd`/jscomp/omnisrc
export PATH=$PATH:$OMNISRC
sed -i 's|Template=.*|Template='`pwd`'/jscomp/omnisrc/omnisrc.tpl|' `pwd`/jscomp/omnisrc/omnisrc.ini
sed -i 's|IncludeDirs=.*|IncludeDirs='`pwd`'/jscomp/omnisxi|' `pwd`/jscomp/omnisrc/omnisrc.ini

cd jscomp

rm -f -r releaseuni-headless
mkdir releaseuni-headless
mkdir releaseuni-headless/jscomp

echo
echo ==== BuildAll ====
echo V4DIR is $V4DIR
echo OMNISRC is $OMNISRC
echo Headless JSCOMP components will be in `pwd`/releaseuni-headless/jscomp

echo
echo ==== Headless JSGENERIC =====
cd jsgeneric
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/jscomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless JSGENERIC2 =====
cd jsgeneric2
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/jscomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ==== Headless JSGENERIC3 =====
cd jsgeneric3
rm -f -r releaseuni
make Release omheadless=1
cp releaseuni/*.so ../releaseuni-headless/jscomp
mv releaseuni releaseuni-headless
cd ..

echo
echo ============
echo = Finished =
echo ============
