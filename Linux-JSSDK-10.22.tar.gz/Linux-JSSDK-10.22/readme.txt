The Omnis JavaScript SDK is only for use with Omnis Studio versions 10.2 and later.

CONTENTS:

	- html: This folder contains an edited jsctempl.htm, which has been altered to load the three generic example controls. This is provided for convenience.
	
	- html:design: This folder contains an edited jsctempl.htm, which has been altered to load the three generic example controls. This is provided for convenience.
	
	- jscomp: This folder contains the C++ projects and files necessary to build the three generic example components. COMPLIB and JSCOMPLIB contain the libraries on which all components depend.

	- jscomp:omnisrc: This folder contains the omnis resource compiler (omnisrc).
	
	- scripts: This folder contains the JavaScript files for the three generic example controls. You will also probably use ctl_generic as a template for your own controls.

	- buildall.sh: Use this to build all components within jscomp.
	
Documentation can be found at:
https://www.omnis.net/developers/resources/onlinedocs/index.jsp?detail=JavaScriptSDK/01overview.html
