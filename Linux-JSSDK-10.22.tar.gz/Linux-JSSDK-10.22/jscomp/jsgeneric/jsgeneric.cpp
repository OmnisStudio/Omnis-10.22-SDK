/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/JSCLIENT/jscomp/jsgeneric/jsgeneric.cpp 27768 2020-09-22 08:21:23Z jgissing $ */

// jsgeneric.cpp
// Generic framework definitions

/*************** changes *******************
Date			Edit				Bug					Description
09-Jan-14	cr_jsc									JavaScript client generic component example.
*/

#include "jsgeneric.h"

ECOmethodEvent jsGenericEvents[] =
{
	0
};

#define jsGenericEvent_Count (sizeof(jsGenericEvents) / sizeof(ECOmethodEvent))

ECOproperty jsGenericProperties[] =
{
	0
};

#define jsGenericProperty_Count (sizeof(jsGenericProperties) / sizeof(ECOproperty))

jsGenericComponent::jsGenericComponent(HWND pFieldHWnd, WCCcontrol *pControl) : javaScriptComponent(pFieldHWnd, pControl)
{
	mNoDesignName = qtrue;
}

jsGenericComponent::~jsGenericComponent()
{
}


void jsGenericComponent::paintDesign(HDC pHdc)
{
}


qbool jsGenericComponent::jsGetInnerHTML(HWND pHwnd, WCCcontrol *pControl, webClientComponent *pObject, EXTfldval &pInner, qdim pWidth, qdim pHeight)
{
	qbool deleteObject = qfalse;
	jsGenericComponent *object = (jsGenericComponent *) pObject;
	
	if (!object)
	{
		// Temporary object to hold property values - we need to use the property values in the supplied object when
		// generating HTML for an open design window - the temporary object caters for the case when there is no open design window, e.g. the property is changed notationally
		
		deleteObject = qtrue;
		object = new jsGenericComponent(0, pControl);
	}
	
	str255 innerTemplate = str255(QTEXT("<div $$></div>"));
	pInner.setChar(innerTemplate);
	
	//insert the id of the client
	jsInsertId(pHwnd, pInner, qfalse);
	// insert the control's style, tab order, etc.
	jsInsertStyle(pHwnd, pControl, pInner, pWidth, pHeight, object);
	
	
	if (deleteObject)
		delete object;
	
	return qtrue;
}

static JSChtmlOptionsGeneric sHTMLoptions;

static WCCcontrol sJSControl =
{
	0,																// Resource base - unused for JavaScript components
	LIB_RES_NAME,											// Resource id of library name
	OBJECT_ID1,												// Resource id of control within library
	OBJECT_ICON,											// Resource bitmap id
	jsGenericEvent_Count,							// Count of events
	jsGenericEvents,										// Events
	jsGenericProperty_Count,						// Count of properties
	jsGenericProperties,								// Properties
	0, 0,															// First and last constant
	EXTIPJS_FLAG_BACKCOLOR_AND_BACKALPHA,	// iPhone/JavaScript mCompFlags
	WCC_FLAG_CANFOCUS,								// mWccFlags
	COMP_STORE_GROUP,									// Resource id of component store group
	0,																// Count of methods
	0,																// Methods
	0,																// Function to make class notation object
	0,																// Resource id of of custom tab name
	0,																// Fixed landscape width for control (zero if any width allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	0,																// Fixed landscape height for control (zero if any height allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	0,																// Fixed portrait width for control (zero if any width allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	0,																// Fixed portrait height for control (zero if any height allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	&sHTMLoptions,										// options for HTML generation
	jsGenericComponent::jsGetInnerHTML,// static to generate inner HTML
	0,																// No control-specific styles function
	"ctrl_generic"									// Control name
};

extern "C" LRESULT OMNISWNDPROC jsGenericComponentWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci)
{
	ECOsetupCallbacks(hwnd, eci);
	switch (message)
	{
		case ECM_OBJCONSTRUCT:				
		{		
			jsGenericComponent *object = new jsGenericComponent(hwnd, &sJSControl);
			lParam = (LPARAM) object;
			break;
		}
	}
	return JSCdefWindowProc(hwnd, message, wParam, lParam, eci, &sJSControl);
}
// End of file
