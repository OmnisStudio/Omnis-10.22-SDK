/*  $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/UNIX/OMNISXI/tchar.h 6130 2013-08-22 09:58:16Z bmitchell $ */

//Copyright (C) Raining Data UK 2002
/* Changes
Date			Edit				Bug					Description
19-Aug-13	rmm64bitux							Linux 64 bit port.
31-Jul-02	MHUNILX									Unicode Linux changes
*/

#ifndef _TCHAR_H_
#define _TCHAR_H_

typedef unsigned int	wint_t;
typedef char TCHAR; // MHUNILX
// MHUNILX begins
#define CharUpperBuff AnsiUpperBuff
#define CharUpper AnsiUpper
#define CharLowerBuff AnsiLowerBuff
#define _stscanf sscanf
#define _tasctime asctime
#define _tcsicmp lstrcmpi
#define _tprintf printf
#define _stprintf sprintf
#define	_tfopen	fopen
#define _fgettc fgetc
#define _fgetts fgets
#define _fputtc fputc
#define _fputts fputs
#define _gettc getc
#define _gettchar getchar
#define _getts gets
#define _puttc putc
#define _puttchar putchar
#define _putts puts
#define _ungettc    ungetc
#define _tcstod     strtod
#define _tcstol     strtol
#define _tcstoul    strtoul
#ifdef is64bit
	#define _tcstoui64	strtoull	// rmm64bitux
#endif
#define _ttoi       atoi
#define _ttol       atol
#define _tcscat     strcat
#define _tcscpy     strcpy
#define _tcslen     strlen
#define _tcschr     strchr
#define _tcscspn    strcspn
#define _tcsncat    strncat
#define _tcsncpy    strncpy
#define _tcspbrk    strpbrk
#define _tcsrchr    strrchr
#define _tcsspn     strspn
#define _tcsstr     strstr
#define _tcstok     strtok
#define _tcscmp     strcmp
#define _tcsnccmp   strncmp
#define _tcsncmp    strncmp
// MHUNILX ends
#endif
