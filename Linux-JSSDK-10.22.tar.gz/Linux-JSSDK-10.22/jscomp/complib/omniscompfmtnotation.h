// $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/CALLBACK/omnisCompFmtNotation.h 24009 2019-10-10 10:53:51Z bmitchell $
#pragma once

#include "extcomp.he"

struct OMNISControlDefinition;

class omnisComponent_formatNotation
{
public:
	omnisComponent_formatNotation() {}
	virtual ~omnisComponent_formatNotation() {}

	void setListLineCount(EXTqlist& pList, qshort pLineCount);
	virtual void defineList(EXTqlist& pList) = 0;
	virtual void initListLine(EXTqlist& pList, qshort pLineNumber) = 0;
	virtual qlong itemListPropid() = 0;			// Property id for list of items in control e.g. list of segments
	virtual qlong itemCountPropid() = 0;		// Property id for number of items e.g. segment count
	virtual qlong currentItemPropid() = 0;	// Property id for current item e.g. current segment
	virtual qlong moveItemPropid() = 0;			// Property id to move the current item
	virtual qlong maxItemCount() = 0;				// Maximum number of items in item list
	virtual EXTmultiValueProperty* getItemPropertiesList(qshort& pItemPropertyCount) = 0; // rmm_oxie

	qbool isItemPropid(qlong pPropId, qshort& pPropColumn, ffttype& pPropFft, qlong& pMinIntValue, qlong& pMaxIntValue);	// Returns qtrue (and reference parameters) if the property is stored in the item list

	virtual qbool fmtUdAttrib(qlong& pRtn, LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci);
	void setFormatItemProperties(EXTqlist& pList);	// Copy properties from the row for the current item to their format properties

	static void clearBooleanProperty(qlong pPropId);	// rmm8068
};
typedef omnisComponent_formatNotation* (*FMTclassMakeFunc)(OMNISControlDefinition*);
