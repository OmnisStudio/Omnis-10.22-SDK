/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/TILE/tile.cpp 26187 2020-04-27 07:06:19Z bmitchell $ */

/*************** changes *******************
Date			Edit				Bug					Description
07-Apr-20	rmm_svg									Added support for SVG images.
05-Apr-16	rmm8832									Tile did not paint correctly on Cocoa.
22-Apr-08	rmm_mobile							Mobile device support.
20-Jan-06	rmm5595			ST/WT/1026	Prevented infinite loop caused by bad icon id.
27-Jul-01 MHn0166									Tile will now paint onscreen if offscreen painting fails.
26-Feb-01 MHCARBON								OSX Changes.
08-Jan-01	rmm4000			ST/WT/436		Floating background objects had problems.
04-Oct-99	rmm3478									Added function to return version via version resource.
30-Jul-99 MHUX001                 Unix Changes.
14-Apr-99 MHn0075									Tile web conponent version 1.0.
*/

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>
#include <gdi.he>
#include "tile.he"

#include <time.h>
#include <math.h>
#include <string.h>          
#include <stdlib.h>

#define COMPONENT_COUNT 	1				/* Number of controls within library */

#ifdef isWEB
#define LIB_RES_NAME  		1001		/* Resource id of library name */
#define TILE_ID						2001		/* Resource id of control within library */
#else
#define LIB_RES_NAME  		1000		/* Resource id of library name */
#define TILE_ID						2000		/* Resource id of control within library */
#endif

#define TILE_ICON 				1				/* Resource bitmap id */

const qshort
				cIconID			 			= 1,
				cBackColor				= 2;


ECOproperty TILEproperties[2] =
{ 
	cIconID,			4000, 	fftCharacter, EXTD_FLAG_PWINDICON, EXTD_EFLAG_SVG, 0, 0, // rmm_svg
	cBackColor,		4001, 	fftInteger,		EXTD_FLAG_PWINDCOL, 0, 0, 0
};

          
// ---------------------------------------------------------------------------------------------------------
tqfTile::tqfTile( HWND pFieldHWnd )
{
	mHWnd = pFieldHWnd;
	mIconID.setEmpty(fftInteger, 0); // rmm_svg
	mBackColor = GDI_COLOR_3DFACE;
}

tqfTile::~tqfTile()
{
}

qlong tqfTile::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( pMessage )
	{ 
		case ECM_PROPERTYCANASSIGN: 
		{
			return 1L;
		}
		case ECM_SETPROPERTY: 
		{       
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( param )
			{
				EXTfldval fval( (qfldval)param->mData );
				switch( ECOgetId(eci) )
				{
					case cIconID: 			mIconID = fval; break;  // rmm_svg
					case cBackColor:		mBackColor = (qcol)fval.getLong(); break; 
				}      
				if ( mIsRealHWND ) WNDinvalidateRect( mHWnd, NULL );
				return 1L;
			}
			break;
		}
		case ECM_GETPROPERTY: 
		{
			EXTfldval fval;
			switch( ECOgetId(eci) )
			{
				case cIconID: 			fval = mIconID; break; // rmm_svg
				case cBackColor:		fval.setLong( (qlong)mBackColor ); break; 
			}         
			ECOaddParam(eci,&fval);
			return 1L;
		}
	}
	return 0;
}

qbool tqfTile::paint( HDC pHdc, qrect* pArea )
{
	EXTBMPref* bmp = new EXTBMPref(mIconID, mApp); // MHn0075 // rmm_svg
	qbool ok = (bmp != 0);	// rmm5595
	if (ok)									// rmm5595
	{
		qrect bounds; qdim icnWid, icnHt, realWid, realHt;
		ePicSize psize = EXTBMPref::getBmpSize( mIconID );
		bmp->getRect( &bounds, psize ); 
		icnWid = bounds.width()-1; icnHt = bounds.height()-1;
		// Start rmm5595
		if (icnWid <= 0 || icnHt <= 0)
			ok = qfalse;
		if (ok)
		{
			// End rmm5595
			realWid = pArea->width(); realHt = pArea->height();

			// rmm4000: paint offscreen to prevent flicker when repainting
			void *offscreenPaintInfo = NULL;	// rmm4000
			HDC tmpDc = pHdc;									// rmm4000
			
			GDIsaveClipping sc(pHdc);	// rmm_mobile
			GDIsetClipRect( pHdc, pArea );
			for ( qdim y = 0; y<realHt; y+=icnHt )
			{
				qrect r1; r1.left = pArea->left; r1.top = pArea->top+y; r1.right = r1.left + icnWid; r1.bottom = r1.top + icnHt;
				// Start rmm4000
				qrect rowRect = r1; rowRect.right = pArea->right;
				qrect area = *pArea;
				void* paintInfo = GDIoffscreenPaintBegin( offscreenPaintInfo, tmpDc, rowRect, area );
				if ( paintInfo!=NULL ) offscreenPaintInfo = paintInfo; // MHn0166

				GDIsetTextColor( tmpDc, mBackColor );
				HBRUSH brush = GDIgetStockBrush( BLACK_BRUSH );
				GDIfillRect( tmpDc, &rowRect, brush );
				// Make the rectangle zero-based, so that they are bitmap coordinates for the off-screen bitmap
				#ifndef ismacosx // MHCARBON // rmm8832
					if (paintInfo!=NULL) GDIoffsetRect(&r1,-r1.left, -r1.top); // MHn0166
				#endif // MHCARBON
				// End rmm4000
				for ( qdim x = 0; x<realWid; x+=icnWid )
				{
					//GDIfillRect( pHdc, &r1, brush ); MHUX001
					bmp->draw( tmpDc, &r1 , psize , picNormal, qfalse, colNone, qfalse, jstLeft, jstLeft );
					GDIoffsetRect( &r1, icnWid, 0 );
				}
			}
			if ( offscreenPaintInfo!=NULL ) GDIoffscreenPaintEnd( offscreenPaintInfo ); // rmm4000 // MHn0166
		}
		delete bmp;
	}
	if (!ok)	// rmm5595
	{
		GDIsetTextColor( pHdc, mBackColor );
		HBRUSH brush = GDIgetStockBrush( BLACK_BRUSH );
		GDIfillRect( pHdc, pArea, brush );
	}
	return qtrue;
}






extern "C" LRESULT OMNISWNDPROC GenericWndProc( HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
   ECOsetupCallbacks( hwnd, eci );
	 switch (Msg)
	 {
			case ECM_BOBJ_EXERASE:	return 1L;
			case WM_ERASEBKGND:			return 1L;	// rmm4000
			case ECM_PRINT:
			{
				tqfTile* object = (tqfTile*)ECOfindObject( eci, hwnd, wParam );
				WNDpaintStruct* paintStruct = (WNDpaintStruct*)lParam;
				if ( object ) 
				{
					qrect rcPaint = paintStruct->rcPaint;					// rmm4000
					object->paint( paintStruct->hdc, &rcPaint );	// rmm4000
				}
				return qtrue;
				break;
			}
			case ECM_OBJCONSTRUCT:				
			{
				qlong objectId = eci->mCompId; 
				tqfTile* object = new tqfTile( hwnd );
				object->mIsRealHWND = !(wParam & ECM_WFLAG_NOHWND);
				ECOinsertObject( eci, hwnd, (void*)object, wParam  );
				object->mApp = ECOgetApp( eci->mInstLocp );	 // MHn0075
				return qtrue;
			}
			case ECM_OBJDESTRUCT:					
			{
				tqfTile* object = (tqfTile*)ECOremoveObject( eci, hwnd, wParam  );
				if ( NULL!=object ) delete object;
				return qtrue;
			}
			case ECM_PROPERTYCANASSIGN:  	
			case ECM_SETPROPERTY: 				
			case ECM_GETPROPERTY:					
			{
				tqfTile* object = (tqfTile*)ECOfindObject( eci, hwnd, wParam  );
				if ( object ) return object->attributeSupport( Msg, wParam, lParam, eci );
				return 0L;
			}
      case ECM_GETCOMPLIBINFO:
      {
      	return ECOreturnCompInfo( gInstLib, eci, LIB_RES_NAME, COMPONENT_COUNT );
      }
			case ECM_GETCOMPICON:
			{ 	
				if ( eci->mCompId==TILE_ID ) return ECOreturnIcon( gInstLib, eci, TILE_ICON );
				return qfalse;
			}
			case ECM_GETCOMPID:
			{
				if ( wParam==1 ) return ECOreturnCompID( gInstLib, eci, TILE_ID, cObjType_Basic );
				return 0L;
			}
			case ECM_GETPROPNAME:
			{
				return ECOreturnProperties( gInstLib, eci, &TILEproperties[0], 2 );
			}                                                                                 
			case ECM_CONNECT:
			{
				#ifdef isRCCDESIGN
					return EXT_FLAG_LOADED|EXT_FLAG_ALWAYS_USABLE|EXT_FLAG_REMAINLOADED|EXT_FLAG_BCOMPONENTS; // Return external flags	// rmm_thindl
				#else
					return EXT_FLAG_LOADED | EXT_FLAG_BCOMPONENTS;
				#endif
			}
			case ECM_ISUNICODE:	// rmmuni
			{
				return qtrue;
			}
			case ECM_GETVERSION:	// rmm3478
			{
				return ECOreturnVersion(gInstLib);
			}                                                                 
			// MHn0074 begins.
#ifdef isWEB
			case ECM_GETCOMPSTOREGROUP:
			{
				ECOreturnCStoreGrpName( gInstLib, eci, 2010 );
				return 1L;
			}		
#endif
			// MHn0074 ends.			
	 }
	 return WNDdefWindowProc(hwnd,Msg,wParam,lParam,eci);
}

// End of file
