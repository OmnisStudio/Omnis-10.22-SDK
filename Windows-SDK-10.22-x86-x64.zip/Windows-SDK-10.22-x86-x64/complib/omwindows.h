// $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/O7EXE/WIN/omwindows.h 24839 2019-12-11 15:05:03Z bmitchell $

//Q4 omwindows.h
//Windows header file - for headless and normal builds
//Copyright (C) OLS Holdings Ltd 2017

/* Changes
Date			Edit				Bug					Description
11-Dec-19	rmm10340		ST/RC/1318	Crash printing HTML control with no data or path on a report on Linux.
15-Nov-18	rmm9834									Conversion from signed integer to string did not handle the minimum value of the integer type correctly.
28-Jun-18	rmm_rd									Studio 9.0 remote debugger
14-Feb-17	rmmheadless							Support for headless Omnis server.
*/
#if defined(__cplusplus) && !defined(_omnoguiexception_defined_) && defined(isheadless)
	// Class thrown as an exception if an attempt is made to use the GUI by the headless server
	// Such exceptions should never be thrown - they indicate a logic error in the headless server
	class NOGUIexception
	{
	public:
		NOGUIexception();	// rmm10340: Added constructor, so we can set a breakpoint when this exception is constructed via throw
	};
	#define _omnoguiexception_defined_
#endif

#ifndef _omwindows_
#define _omwindows_

#ifndef isunix
	#define NOMINMAX	// rmm9834
	#include <winsock2.h> // rmm_rd
#endif
#include <windows.h>

int OMMessageBox(BOOL pMainHwnd, LPCTSTR lpText, LPCTSTR lpCaption, UINT uType); // Used in place of MessageBox (If pMainHwnd is TRUE in the normal server, uses gmain.MainHwnd(), otherwise use NULL for the HWND)

#endif
