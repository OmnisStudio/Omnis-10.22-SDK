// $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/CALLBACK/ComponentDelegate.h 24009 2019-10-10 10:53:51Z bmitchell $
#pragma once

#include "OmnisComponent.h"


class OmnisComponent;

class ComponentDelegate
{
public:
	ComponentDelegate(OmnisComponent* component) {
		mComponent = component;
	}

	virtual ~ComponentDelegate() = 0; // Virtual destructor to make this class abstract.

	/**
	 Called to allow the control to repaint itself
	
	 @param	{HDC}	pHdc			 		The drawing context.
	 @param	{qbool}	pIsDesign		Whether it is in design mode (qtrue) or runtime (qfalse)
	 */
	virtual void paint(HDC pHdc, qbool pIsDesign) { GDIignore(pHdc); GDIignore(&pIsDesign); }


	virtual void autoPropertyChanged(ECOproperty* propertyDef) { GDIignore(propertyDef); }

	/**
	 Called after the component instance has been constructed.
	*/
	virtual void init() {}

	/**
	 Implement to handle a property message for the linked component.
	
	 @param 					{LPARAM}	pMessage 	One of ECM_PROPERTYCANASSIGN, ECM_GETPROPERTY, ECM_SETPROPERTY, 
																				ECM_INBUILT_OVERRIDE
	 @param [out]	{qlong&}	pResult	 			Should be populated with a return value. 
																				Generally this should be qtrue or qfalse. This will be used as the return value from the WndProc.
	 @param	{EXTCompInfo*}	eci						The EXTCompInfo relating to this component.
	
	 @returns	{qbool}	qtrue if you've handled the message, qfalse to allow default handling to occur.
	 */
	virtual qbool handleAttribute(LPARAM pMessage, qlong& pResult, EXTCompInfo* eci) {
		GDIignore(&pMessage); GDIignore(&pResult); GDIignore(eci); return qfalse;
	}


protected:
	OmnisComponent* mComponent;
	
};

