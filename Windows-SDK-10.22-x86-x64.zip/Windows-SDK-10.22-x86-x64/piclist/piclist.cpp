/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/PICLIST/PICLIST.CPP 2785 2012-12-13 12:04:13Z bmitchell $ */

/*********************************** Changes ***********************************
Date			Edit				Bug					Description
23 NOV 01	mpm5031									New platform independent hiliting
*********************************************************************************/

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>
#include <gdi.he>
#include "piclist.he"

const qshort	cPicListNum 				= 1;

ECOproperty PICLISTproperties[1] =
{ 
	cPicListNum,			4000, 	fftInteger, EXTD_FLAG_PROPDATA, 0, 0, 0
};

/* Component library entry point (name as declared in resource) */
extern "C" LRESULT OMNISWNDPROC ListWndProc(HWND hwnd, UINT Msg,WPARAM wParam,LPARAM lParam,EXTCompInfo* eci)
{
   ECOsetupCallbacks(hwnd,eci);		/* Initialize callback tables */
	 switch (Msg)
	 {
			case ECM_GETVERSION:
			{
				return ECOreturnVersion( 1, 1 ); // mpm5031
			}
			case ECM_LISTDRAWLINE:   /* Draw list line */
			{
				tqfListObject* object = (tqfListObject*)ECOfindObject( eci, hwnd );
				if ( NULL!=object )
					return object->drawSingleLine( (EXTListLineInfo*)lParam, eci );
				break;
			}
			case ECM_OBJCONSTRUCT:				/* Construct an object */
			{
				tqfListObject* object = new tqfListObject( hwnd );
				ECOinsertObject( eci, hwnd, (void*)object );
				return qtrue;
			}
			case ECM_OBJDESTRUCT:					/* Destruct the object */
			{
				tqfListObject* object = (tqfListObject*)ECOremoveObject( eci, hwnd );
				if ( NULL!=object )
					delete object;
				return qtrue;
			}
      case ECM_GETCOMPLIBINFO: /* Return component library name & component count */
      {
      	return ECOreturnCompInfo( gInstLib, eci, LIB_RES_NAME, OBJECT_COUNT );
      }
			case ECM_GETCOMPICON: 	/* Return component icon (as a hbitmap) */
			{
				if ( eci->mCompId==OBJECT_ID1 ) return ECOreturnIcon( gInstLib, eci, LIST_ICON );
				return qfalse;
			}
			case ECM_GETCOMPID:			/* Get the external object name & id (from a sequential wParam) */
			{	
				if ( wParam==1 )
					return ECOreturnCompID( gInstLib, eci, OBJECT_ID1, cObjType_List );
				return 0L;
			}
			case ECM_GETPROPNAME:
			{
				return ECOreturnProperties( gInstLib, eci, &PICLISTproperties[0], 1 );
			}                                                                                 
			case ECM_PROPERTYCANASSIGN:  	/* Object: Is the property assignable (ie readonly?) */
			case ECM_SETPROPERTY: 				/* Object: Assignment to a property */
			case ECM_GETPROPERTY:					/* Object: Retrieve value from property */
			{
				tqfListObject* object = (tqfListObject*)ECOfindObject( eci, hwnd );
				if ( object )
					return object->attributeSupport( Msg, wParam, lParam, eci );
				return 0L;
			}
	 }
	 return WNDdefWindowProc(hwnd,Msg,wParam,lParam,eci);
}

tqfListObject::tqfListObject( HWND pFieldHWnd )
{
	mHWnd = pFieldHWnd;
	mIconColumn = 1;
	ECOlistSetLineHeight( mHWnd, 32); // Set lineheight
}

tqfListObject::~tqfListObject()
{
}

qlong tqfListObject::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( pMessage )
	{ 
		case ECM_PROPERTYCANASSIGN: 
		{
			return 1L;
		}
		case ECM_SETPROPERTY: 
		{       
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( param )
			{
				EXTfldval fval( (qfldval)param->mData );
				switch( ECOgetId(eci) )
				{
					case cPicListNum: 			mIconColumn = (qshort)fval.getLong(); break; 			
				}       
				return 1L;
			}
			break;
		}
		case ECM_GETPROPERTY: 
		{
			EXTfldval fval;
			switch( ECOgetId(eci) )
			{
				case cPicListNum: 			fval.setLong( (qlong)mIconColumn ); break; 			
			}         
			ECOaddParam(eci,&fval);
			return 1L;
		}
	}
	return 0;
}

qbool tqfListObject::drawSingleLine(EXTListLineInfo* pLineInfo,EXTCompInfo* pEci)
{
	EXTParamInfo* cparam = ECOfindParamNum( pEci, 1 );
	if (cparam && pLineInfo)	// Ensure parameter & line information are present
	{
		// Get icon number (assumed to be in list line data,always passed as param one)
		EXTfldval extfldval( (qfldval)cparam->mData );
		str255 s; extfldval.getChar(s);
		// Get data from list column 2 (if more data than in parameter 1 is required)
		EXTqlist* extqlist=(EXTqlist*)pLineInfo->mListPtr;	qlong iconid = 0;
		if ( mIconColumn>0 && mIconColumn<=extqlist->colCnt() )
		{	
      EXTfldval lineval; extqlist->getColValRef(pLineInfo->mLine,mIconColumn,lineval,qfalse);
			iconid=lineval.getLong();
		}
		EXTBMPref* bmp = new EXTBMPref( iconid );
		// Erase line rectangle
		HBRUSH brush = GDIcreateBrush( patFill );
		GDIfillRect(pLineInfo->mHdc,&pLineInfo->mLineRect,brush);
		GDIdeleteObject(brush);
		// start hiliting
		qcol textColor = GDI_COLOR_WINDOWTEXT; // mpm5031 begins
		if ( pLineInfo->mSelected )
		{
			GDIhiliteTextStart( pLineInfo->mHdc, &pLineInfo->mLineRect, GDI_COLOR_WINDOWTEXT );
			textColor = GDIgetTextColor( pLineInfo->mHdc );
		} // mpm5031 ends

		// Draw bitmap & line data
		qrect r1; GDIcopyRect(&r1,&pLineInfo->mLineRect);
		if ( bmp ) 
		{
			ePicSize psize = EXTBMPref::getBmpSize( iconid );
			r1.right = r1.left + r1.height();
			// Bitmap
			bmp->draw(pLineInfo->mHdc,&r1,
								psize , picNormal, qfalse, colNone, qtrue , jstCenter, jstCenter);
			delete bmp;
			r1.left = r1.right + 5;	r1.right = pLineInfo->mLineRect.right;
		}		
		// Draw line text
		GDIsetTextColor( pLineInfo->mHdc, textColor ); // mpm5031
	  GDIdrawText( pLineInfo->mHdc, r1.left, r1.top, &s[1], s.length(), jstLeft );
		// end hiliting
		if ( pLineInfo->mSelected ) // mpm5031
			GDIhiliteTextEnd( pLineInfo->mHdc, &pLineInfo->mLineRect, GDI_COLOR_WINDOWTEXT ); // mpm5031
		// Draw focus rectangle
		if ( pLineInfo->mDrawFocusRect )
		{
			pLineInfo->mLineRect.right++;
			GDIdrawFocusRect( pLineInfo->mHdc, &pLineInfo->mLineRect );
		}
		return qtrue;
	}
	return qfalse;
}

/* EOF */

	
