/* $Header:   K:\vcs\v4new\extcomp\docview\wpxcomp.cpv   1.2   22 May 2000 15:18:46   mmonscha  $ */

// base WP xcomp object class implementation

/**************** Changes ******************
Date			Edit				Bug					Description
22 MAY 00	mpm4700									Implements printing of document
08 NOV 99 mlr0006									Added Rtf support
********************************************/

#ifndef _extcomp_
#include "extcomp.he" // jmg_includecasing
#endif

#ifndef	_WPXCOMP_HE_
#include "wpxcomp.he" // jmg_includecasing
#endif

#ifndef	_WPDOC_HE_
#include "wpdoc.he" // jmg_includecasing
#endif



// ###############################################################################
// ################# WPXCompClass Public #########################################
// ###############################################################################


WPXCompClass::WPXCompClass( WPObjectClass* pParent, WPDocClass* pDocumentObj )
						 :WPImageClass( pParent, pDocumentObj )
{
}


WPXCompClass::~WPXCompClass()
{
}


WPXCompClass*	WPXCompClass::make( WPObjectClass* pParent, WPDocClass* pDocumentObj, WPXCompInfoStruct* pXCompInfo,
																	str80& pComponentLib, str80& mComponentCtrl, EXTqlist* pProperties )
{
	WPXCompClass* obj = new WPXCompClass( pParent, pDocumentObj );
	obj->mImageInfo = *pXCompInfo;
	
	qldim width = obj->mImageInfo.mWidth & 0x7FFFFFFF;
	obj->mXCompHwnd = pDocumentObj->getXCompPlugin( pComponentLib, mComponentCtrl, pProperties, 
																									width, obj->mImageInfo.mHeight );
	if ( !obj->mImageInfo.mWidth ) obj->mImageInfo.mWidth = width;
	return obj;
}


void WPXCompClass::initData( WPObjInfoStruct* pObjInfo ,printInfo* pInfo)
{
	qldim width = mImageInfo.mWidth;
	if ( mImageInfo.mWidth < 0 )
	{
		mImageInfo.mWidth = pObjInfo->mRowRect.width() * (-mImageInfo.mWidth) / 100;
	}
	WPImageClass::initData( pObjInfo,pInfo );
	mImageInfo.mWidth = width;
}


void WPXCompClass::paint( WPObjInfoStruct* pObjInfo, WNDpaintStruct* pPaintStruct, qldim pHorzOff, qldim pVertOff )
{
	if ( !pObjInfo ) return;
	if ( mXCompHwnd )
	{
		qlrect lr = pObjInfo->mOwnerRect; lr.offset( pHorzOff, pVertOff );
		lr.inset( mImageInfo.mHorzSpace, mImageInfo.mVertSpace );
		qrect r; lr.conv( &r );
		WNDmoveWindow( mXCompHwnd, r.left, r.top, r.width(), r.height(), qfalse );
		WNDshowWindow( mXCompHwnd, SW_SHOW );
	}
	else
	{
		WPImageClass::paint( pObjInfo, pPaintStruct, pHorzOff, pVertOff );
	}
}

qprierr WPXCompClass::addToPrintJob(  printInfo* pInfo ,EXTCompInfo* eci,WPObjInfoStruct* pObjInfo, // mpm4700
																			qldim& pHorzOff, qldim& pVertOff)
{
	return PRI_ERR_NONE;
}


qlong WPXCompClass::message( WPObjInfoStruct* pObjInfo, eWPMessage pMessage, qldim pHorzOff, qldim pVertOff, LPARAM lParam1, LPARAM lParam2 )
{
	if ( pMessage == eWPMessFindHwnd && HWND(lParam1) == mXCompHwnd )
	{
		pObjInfo->mOwnerRect.offset( pHorzOff, pVertOff );
		pObjInfo->mOwnerBaseLine += pVertOff;
		return 1L;
	}
	return 0L;
}



/* eof */




