/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/PROGRESS/progress.cpp 25856 2020-03-25 15:11:17Z crichardson $ */

/*
Date      Change		Fault				Description
13-Mar-20	CRMAC1014								macOS changes for 10.14 SDK and later.
08-Jun-16	CR0361		ST/EC/1412	Use a layered view container to get a vertical OSX prog bar to redraw correctly on El Capitan.
16-Oct-13	CRCOCOA								Cocoa target.
19-Aug-13	rmm64bitux						Linux 64 bit port.
14-Jan-11	rmm7067		ST/WT/1714	Progress bar was drawing on incorrect tab on OSX.
31-Jul-09	rmm6693		ST/EC/1194	Vista issue when color was not set to default.
25-Apr-08	rmm_mobile						Mobile device support
17-May-07	rmm6068		ST/PF/521		Memory leak in Vista progress bar.
05-Apr-07	PKvista9							Windows Vista changes.
20-Mar-07	rmm6000								Windows Vista changes.
06-Dec-05	pkmach_o							pkmacho compiler changes
25-May-05	AE9999		st/wo/1775	The XP version of ijt265
19-Apr-05	PK6704    ST/HE/759		progress bars & tool tips.
18-Jan-04	ijt265		ST/WO/1775	$disableostheme now works regardless of the $blocks value.
30-Jun-04	rmm5006									Multiple select knobs were missing from quite a few components.
22-Jun-04	rmm4999								Finished rmm4993: remote form fields now show $xxx correctly.
07-Nov-03 ijt221		ST/WO/1586	Ensured background them is drawn correctly.
05-Nov-03 ijt220		ST/WO/1585	Added $disableostheme property to override theme on OSX and XP
10-Sep-03 AE6338		ST/EC/775: 	Missed change from AE6246
14-Aug-03 AE6316		ST/EC/744: 	Progress bar drawing funnies
20-Jun-03 MHn0246		ST/WP/010		Fixed progress bar drawing on OSX.
10-Jun-03 rmm4544								XP progress bar.
22-May-03 AE6246		ST/WO/1415	XCOMP Slider & progress bar didn't support themes correctly.
17-Apr-02 rmm4222								evCarryOn needs to be executed immediately on the Web client.
22/03/01  AE5188								NVDESIGNER: Added $sendcarryon and evCarryOn
19/03/01	MHCARBON							OSX Changes
02/02/00  MHWEB									Web client changes.
22/07/99  MHUX001  							Stopped bad rectangle from being drawn in updateProgress. Applies to all platforms. 
*/

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>
#include <gdi.he>
#include "progress.he"

#include <time.h>
#include <math.h>
#include <string.h>

#define COMPONENT_COUNT 	1				/* Number of controls within library */
#define PROGRESS_ICON 		1				/* Resource bitmap id */

// MHWEB begins.
#ifdef isWEB
#define LIB_RES_NAME 			1001		/* Resource id of library name */
#define PROGRESS_ID 			2001		/* Resource id of control within library */
#else
#define LIB_RES_NAME 			1000		/* Resource id of library name */
#define PROGRESS_ID 			2000	  /* Resource id of control within library */
#endif
// MHWEB ends.

#ifdef iscarbon
	#include <Appearance.h>
#endif

const qshort
				cProgressColor 				= 1,
				cProgressBackColor    = 2,
				cProgressVertical			= 3,
				cProgressBlocks				= 4,
				cProgressMin					= 5,
				cProgressMax					= 6,
				cProgressVal					= 7,
				cProgressSendCarryOn  = 8,
				cProgressDisableOSTheme   = 9,
				// -----------------------
				cHBlockSize						= 8,
				cVBlockSize						= 8,
				cBlockGap							= 3,
				
				cProgressEvCarryOn    = 100;

ECOproperty PROGRESSproperties[10] =
{ 
	cProgressColor, 			4000,		fftInteger, EXTD_FLAG_PWINDCOL,0,0,0,				// progress color
	cProgressBackColor,		4001,		fftInteger, EXTD_FLAG_PWINDCOL,0,0,0,				// back color
	cProgressVertical,		4002,		fftBoolean, 0,0,0,0,												// vertical
	cProgressBlocks,			4003,		fftBoolean, 0,0,0,0,												// blocks
	cProgressMin,					4004,		fftInteger, 0,0,0,0,												// minval
	cProgressMax,					4005,		fftInteger, 0,0,0,0,												// maxval
	cProgressVal,					4006,		fftInteger, 0,0,0,0,													// val
	cProgressSendCarryOn, 4007,   fftBoolean, EXTD_FLAG_RUNTIMEONLY,0,0,0,
	cProgressDisableOSTheme,	4008,		fftBoolean, 0,0,0,0,												// OS Override	//<ijt220>
	anumBackgroundTheme,   0,	0,			0, 0, 0, 0,		// AE6246																									// day fontsize
};


ECOmethodEvent PROGRESSevents[1] = 
{
	cProgressEvCarryOn,  	5000, 0, 0, 0, 0, 0
};
               
const qlong cVistaTimerInterval = 35;	// rmm6000a

// ---------------------------------------------------------------------------------------------------------
tqfProgressBar::tqfProgressBar( HWND pFieldHWnd )
{
	mHWnd = pFieldHWnd;
	
	qlong style = WNDgetWindowLong( mHWnd, GWL_EXSTYLE );
	style |= WND_REDRAWONSIZE;
	WNDsetWindowLong( mHWnd, GWL_EXSTYLE, style );
	
	mProgressColor = GDI_COLOR_3DDKSHADOW;
	mBackColor = GDI_COLOR_QDEFAULT; // pkvista11 GDI_COLOR_3DFACE;
	mIsVertical = qfalse;	// pkvista9
	mBlocks = qtrue;
	mMin = 1; mMax = 100; mVal = 50;
	mDisableOSTheme = qfalse;	//<ijt220>
	mDrawingPulse = mIsVista = qfalse;	// rmm6000
	mTimerID = WND_TIMER_FIRST;
	mSetTimer = qfalse;	// rmm6000a
#if defined(isCOCOA)	//CRCOCOA
	// Start CR0361
	mProgbarContainer = [[NSView alloc] init];
	mProgbarContainer.wantsLayer = YES;
	NSProgressIndicator* progbar = [[NSProgressIndicator alloc] init];
	[mProgbarContainer addSubview:progbar];
	[progbar setStyle:NSProgressIndicatorBarStyle];
	[progbar setIndeterminate:NO];
	[progbar setWantsLayer:NO];
	[WNDgetContentView(pFieldHWnd) addSubview: mProgbarContainer];
	// End CR0361
#elif defined(iscarbon)
	mPhaseVar = 0;
	mPhase = mPhaseVar;
	mSetTimer = qtrue;
	if (!ECOisDesign(mHWnd)) WNDsetTimer( mHWnd, mTimerID, 50 );
#elif defined(ismobile)
	mIsVista = qfalse;	// rmm_mobile
#elif defined(iswin32)
	// rmm6000:
	// rmm6693: Only show pulsing Vista progress when in themed mode: DWORD verinfo = GetVersion();
	mIsVista = ECOisVista(); // rmm6693: ((verinfo & 0xff) >= 6);
	if (mIsVista)
	{
		if (!ECOisDesign(mHWnd)) WNDsetTimer(mHWnd, mTimerID, cVistaTimerInterval);	// was 1000 - pkvista9
		mSetTimer = qtrue;
	}
	mLastDrawPulse = 0;
	mPulseStartDelay = 0; // pkvista9
	mPulseSteps = 0;	// pkvista9
#endif
}

tqfProgressBar::~tqfProgressBar()
{
	// rmm6000a: always kill timer if set (not just for carbon)
	if (mSetTimer) WNDkillTimer(mHWnd,mTimerID);
	mSetTimer = qfalse;
#ifdef isCOCOA	//CRCOCOA
// Start CR0361
	if(mProgbarContainer)
	{
		[mProgbarContainer removeFromSuperview];
		mProgbarContainer = nil;
// End CR0361
	}
#endif
}

qlong tqfProgressBar::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( pMessage )
	{ 
		case ECM_PROPERTYCANASSIGN: 
		{
			if ( ECOgetId(eci)==cProgressSendCarryOn && ECOisDesign( mHWnd ) ) return 0L; 
			return 1L;
		}
		case ECM_SETPROPERTY: 
		{       
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( param )
			{
				EXTfldval fval( (qfldval)param->mData );
				switch( ECOgetId(eci) )
				{
					case cProgressColor: 			mProgressColor = (qcol)fval.getLong(); break; 			
					case cProgressBackColor: 	mBackColor = (qcol)fval.getLong(); break; 			
					case cProgressVertical:
					{
						mIsVertical = (qbool)fval.getLong();
// Start CR0361
#ifdef isCOCOA
						if(!mDisableOSTheme && mProgbarContainer)
						{
							NSProgressIndicator* progbar = mProgbarContainer.subviews[0];
					
							if(mIsVertical)
								[progbar setBoundsRotation:-90];
							else
								[progbar setBoundsRotation:0];
						}
#endif
// End CR0361
						break;
					}
					case cProgressBlocks: 		mBlocks = (qbool)fval.getLong(); break; 	
					case cProgressDisableOSTheme:	//<ijt220>
					{
						mDisableOSTheme = (qbool)fval.getLong();
#ifdef isCOCOA
						// Start CR0361
						if(mDisableOSTheme && mProgbarContainer)
						{
							[mProgbarContainer removeFromSuperview];
							mProgbarContainer = nil;
						}
						else if(!mDisableOSTheme && !mProgbarContainer)
						{
							mProgbarContainer = [[NSView alloc] init];
							mProgbarContainer.wantsLayer = YES;
							
							NSProgressIndicator* progbar = [[NSProgressIndicator alloc] init];
							
							[mProgbarContainer addSubview:progbar];
							[progbar setStyle:NSProgressIndicatorBarStyle];
							[progbar setIndeterminate:NO];
							progbar.wantsLayer = NO;
							[WNDgetContentView(mHWnd) addSubview: mProgbarContainer];
							
							if(mIsVertical)
								[progbar setBoundsRotation:-90];
							// End CR0361
						}
#endif
						break;
					}
					case cProgressMin: 				mMin = fval.getLong(); break;
					case cProgressMax: 				mMax = fval.getLong(); break; 
					case cProgressVal:				mVal = fval.getLong(); break;
					case cProgressSendCarryOn:
					{
						if ( fval.getLong()==1 )
							// rmm4222:
							#ifdef isWEB
								ECOsendEvent( mHWnd, cProgressEvCarryOn, 0, 0,qtrue );
							#else
								ECOsendEvent( mHWnd, cProgressEvCarryOn, 0, 0,qfalse );
							#endif
						return 1L;
					}
					default: return 0L;	// AE6338
				}
				
				if ( ECOisSetup( mHWnd ) )
				{
					// Start rmm6000a
					if (mIsVista && !mSetTimer && mVal != mMax && !ECOisDesign(mHWnd))
					{
						WNDsetTimer(mHWnd, mTimerID, cVistaTimerInterval);
						mSetTimer = qtrue;
					}
					// End rmm6000a
					WNDinvalidateRect( mHWnd, NULL );
					WNDupdateWindow( mHWnd );
				}
				return 1L;
			}
			break;
		}
		case ECM_GETPROPERTY: 
		{
			EXTfldval fval;
			switch( ECOgetId(eci) )
			{
				case cProgressColor: 			fval.setLong( (qlong)mProgressColor ); break; 			
				case cProgressBackColor: 	fval.setLong( (qlong)mBackColor ); break; 			
				case cProgressVertical: 	fval.setLong( (qlong)mIsVertical ); break; 
				case cProgressBlocks: 		fval.setLong( (qlong)mBlocks ); break; 	
				case cProgressDisableOSTheme: fval.setLong( (qlong)mDisableOSTheme ); break;		
				case cProgressMin: 				fval.setLong( (qlong)mMin ); break; 
				case cProgressMax: 				fval.setLong( (qlong)mMax ); break;
				case cProgressVal:				fval.setLong( (qlong)mVal ); break; 
				case cProgressSendCarryOn: fval.setLong( 0 ); break;
				default: return 0L;	// AE6338
			}         
			ECOaddParam(eci,&fval);
			return 1L;
		}
	}
	return 0;
}

#ifndef THEME_CONTROL_ANIMATING
	#define THEME_CONTROL_ANIMATING		0x00000200L	// rmm6000: Vista only
#endif

// CRMAC1014
void tqfProgressBar::updateProgress( HDC pHdc )
{
	if ( pHdc==NULL )
	{
		pHdc = WNDstartDraw( mHWnd );
		_updateProgress( pHdc, qtrue );
		WNDendDraw( mHWnd, pHdc );
	}
	else
		_updateProgress( pHdc, qfalse );
}

void tqfProgressBar::_updateProgress( HDC pHdc,qbool pNeedsRelease )
{
	qrect client; WNDgetClientRect( mHWnd, &client ); 

	//pkvista9
	HDC realScreen = NULL; HBITMAP oldBmp = NULL; HBITMAP hbmp = NULL;
	if ( pNeedsRelease && mIsVista )
	{
		realScreen = pHdc;
		hbmp = GDIcreateBitmap( client.width(), client.height(), 0 ); pHdc = GDIgetTempDC();
		oldBmp = GDIselectBitmap( pHdc, hbmp );
	}
	
	if ( !mIsVista ) GDIinsetRect( &client, 1, 1 );	// pkvista9
	qreal dist = (qreal)mMax - (qreal)mMin;	 if ( !dist ) dist = 1;
	qreal ht = (qreal)( mIsVertical ? client.height() : client.width() );
	qreal pixelPerPoint = ht / dist;
	qshort bottompart = (qshort)( (qreal)(mVal-mMin) * pixelPerPoint );
	qshort toppart = (qshort)( ht - bottompart );
	HBRUSH fillbrush = GDIgetStockBrush( BLACK_BRUSH);
	
	qrect r = client; 
	if ( mIsVertical ) 
		r.bottom = toppart; 
	else 
		r.right = toppart;
		
	GDIsetBkColor( pHdc, backColor() ); // pkvista11
	GDIsetTextColor( pHdc, backColor() );	// pkvista11
	
	// pkvista9
	if ( mIsVista && !mDisableOSTheme ) // rmm6693: removed test for mBackColor==GDI_COLOR_QDEFAULT
	{
		WNDdrawThemeBackground(mHWnd, pHdc, &client, WND_BK_DEFAULT);	// rmm6000a: need to erase the corners on Vista
		WNDdrawThemeControl(mHWnd, pHdc, THEME_PROGRESS, mIsVertical ? THEME_CONTROL_DISABLED|THEME_CONTROL_VERTICAL : THEME_CONTROL_DISABLED, &client);
	}
	else
	{
		if ( !WNDdrawThemeBackground( mHWnd, pHdc, &r, WND_BK_DEFAULT )  ) // AE6246
			GDIfillRect( pHdc,  &r, fillbrush );
	}
	
	GDIsetTextColor( pHdc, mProgressColor );
	GDIsetBkColor( pHdc, mProgressColor );
	
	r = client; 
	if ( mIsVertical )
	{
		r.top = toppart;
		if ( r.top < client.top ) r.top = client.top;	 // AE6316
	}
	else
	{
	  r.right = bottompart;
		if ( r.right > client.right ) r.right = client.right; // AE6316 
	}
	#if defined(iswin32) && !defined(isunix)
		qbool isXP = (qbool) (WNDgetThemeState(NULL) != 0);
	#else
		qbool isXP = qfalse;
	#endif
	// Start rmm6000
  // pkvista9	
  //#ifdef iswin32
	//	qbool drawingPulse = mDrawingPulse;
	//	if (mIsVista && !mDrawingPulse && !ECOisDesign(mHWnd) && abs((long) GetTickCount() - (long) mLastDrawPulse) < 150)
	//	{
	//		// Keep pulse there for at least 0.15 second
	//		drawingPulse = qtrue;
	//	}
	//#endif
	// End rmm6000

	if ( !mBlocks || ( mIsVista && !mDisableOSTheme ) )	// pkvista9
	{
		if (!isXP || mDisableOSTheme || !WNDdrawThemeControl(mHWnd, pHdc, THEME_PROGRESS, mIsVertical ? THEME_CONTROL_VERTICAL : 0, &r)) // AE9999
			GDIfillRect( pHdc, &r, fillbrush );
		// Start rmm6000
		#ifdef iswin32
		  // pkvista9
			else if ( mIsVista && mPulseSteps )
			{
				qrect pulserect;
				if ( mIsVertical )
				{
					qint barHt = r.height(); qint pulseHt = barHt; qint steps = (barHt+pulseHt)/20;
					pulserect = r; 
					pulserect.bottom+=pulseHt; 
					pulserect.top = r.bottom; 
					GDIoffsetRect(&pulserect,0,-(steps*mPulseSteps));
				}
				else
				{
					qint barWid = r.width(); qint pulseWid = barWid; qint steps = (barWid+pulseWid)/20;
					pulserect = r; 
					pulserect.left-=pulseWid; 
					pulserect.right = r.left; 
					GDIoffsetRect(&pulserect,steps*mPulseSteps,0);
				}
				GDIsetClipRect( pHdc, &r );
				WNDdrawThemeControl(mHWnd, pHdc, THEME_PROGRESS, (mIsVertical ? THEME_CONTROL_VERTICAL : 0) | THEME_CONTROL_ANIMATING, &pulserect);
				GDIclearClip( pHdc );
			}
			if ( pNeedsRelease ) // CRMAC1014
			{
				if ( mPulseStartDelay<50 ) mPulseStartDelay++;
				else
				{
					mPulseSteps++; if ( mPulseSteps>=20 ) { mPulseSteps = 0; mPulseStartDelay = 0; WNDinvalidateRect(mHWnd,NULL); }
				}
			}
			//else if (drawingPulse)
			//{
			//	if (mVal < mMax)
			//		WNDdrawThemeControl(mHWnd, pHdc, THEME_PROGRESS, (mIsVertical ? THEME_CONTROL_VERTICAL : 0) | THEME_CONTROL_ANIMATING, &r);
			//	if (mDrawingPulse)
			//		mLastDrawPulse = GetTickCount();
			//}
		#endif
		// End rmm6000
	}
	else
	{ 
		// Start rmm4544: blocks on XP means use the theme
		if (!isXP || mDisableOSTheme || !WNDdrawThemeControl(mHWnd, pHdc, THEME_PROGRESS, mIsVertical ? THEME_CONTROL_VERTICAL : 0, &r))
		{
			// End rmm4544
			qrect block = r; 
			if ( mIsVertical )
				block.top = block.bottom - cVBlockSize;
			else 
				block.right = block.left + cHBlockSize;
			
			qbool drawing = qtrue; qbool notDone = qtrue;
			
			while( notDone )
			{
				if ( mIsVertical && block.top<r.top ) 
				{
					block.top = r.top; notDone = qfalse;
				}
				else if ( !mIsVertical && block.right>r.right ) 
				{
					block.right = r.right; notDone = qfalse;
				}
					
				if (drawing) GDIfillRect( pHdc, &block, fillbrush ); // MHUX001
				
				if ( mIsVertical )
					GDIoffsetRect( &block, 0, -( cVBlockSize + cBlockGap ) );
				else
					GDIoffsetRect( &block, cHBlockSize + cBlockGap, 0 );
			}
		}
		// pkvista9 
		// Start rmm6000
		//#ifdef iswin32
		//	else if (drawingPulse)
		//	{
		//		if (mVal < mMax)
		//			WNDdrawThemeControl(mHWnd, pHdc, THEME_PROGRESS, (mIsVertical ? THEME_CONTROL_VERTICAL : 0) | THEME_CONTROL_ANIMATING, &r);
		//		if (mDrawingPulse)
		//			mLastDrawPulse = GetTickCount();
		//	}
		//#endif
		// End rmm6000
	}
	
	//pkvista9
	if ( realScreen )
	{
		GDIcopyBits( pHdc, realScreen, &client, &client, qfalse );
		GDIselectBitmap( pHdc, oldBmp );
		GDIdeleteBitmap( hbmp );
		pHdc = realScreen;	// rmm6068
	}
		
	// rmm6000a: kill timer once the range has been reached
#ifdef iswin32
	if (mIsVista && mVal == mMax)
	{
		if (mSetTimer) 
		{
			WNDkillTimer(mHWnd, mTimerID);
			WNDinvalidateRect(mHWnd, NULL);
			mPulseSteps = 0;
		}
		mSetTimer = qfalse;
	}		
#endif
}       

// MHn0246 begins
#if defined(iscarbon) && !defined(ismach_o)   // pkmach_o
enum {
	kThemeTrackHasFocus = (1 << 5)
};
#endif
// MHn0246 ends

qbool tqfProgressBar::paint()
{
//<ijt220>
#if defined(iscarbon) || defined(isCOCOA)	//CRCOCOA
	if(!mDisableOSTheme)	// <ijt265> removed && mBlocks) 
	{
		drawThemeTrack();
		return qtrue;
	}
#endif
	WNDpaintStruct paintStruct;
	WNDbeginPaint( mHWnd, &paintStruct );

	qrect r; WNDgetClientRect( mHWnd, &r ); 
	HBITMAP hbmp = GDIcreateBitmap( r.width(), r.height(), 0 );
	HDC hdc = GDIgetTempDC();
	HBITMAP oldBmp = GDIselectBitmap( hdc, hbmp );

	GDIsetBkColor( hdc, backColor() );
	GDIsetTextColor( hdc, backColor() );

	// pkvista9
	if ( mIsVista && !mDisableOSTheme );	// rmm6693: removed test for mBackColor==GDI_COLOR_QDEFAULT
	else if ( !WNDdrawThemeBackground( mHWnd, hdc, &r, WND_BK_DEFAULT )  ) // AE6246	
		GDIfillRect( hdc,  &r, GDIgetStockBrush( BLACK_BRUSH) );

	updateProgress( hdc );
	
	GDIcopyBits( hdc, paintStruct.hdc, &r, &r, qfalse );
	GDIselectBitmap( hdc, oldBmp );
	GDIdeleteBitmap( hbmp );

	// Start rmm4999
	if (ECOisShowNumber(mHWnd))
		ECOdrawNumberEx(mHWnd, paintStruct.hdc, qtrue);
	// End rmm4999
	ECOdrawMultiKnobs(mHWnd, paintStruct.hdc);	// rmm5006
	WNDendPaint( mHWnd, &paintStruct );	
	return qtrue;
}

#ifdef iscarbon
void tqfProgressBar::incphase()
{
	mPhase+=1;
	if (mPhase > 2000) mPhase = 0;
}
#endif

// AE6246
void tqfProgressBar::getBackgroundTheme()
{
	qlong lTheme;
	EXTfldval fval;
	lTheme = WNDgetWindowLong(mHWnd,GWL_BKTHEME);
	ECOgetProperty( mHWnd, anumBackgroundTheme, fval );	
	if (lTheme != fval.getLong()) WNDsetWindowLong( mHWnd, GWL_BKTHEME, fval.getLong() );	
}

extern "C" LRESULT OMNISWNDPROC GenericWndProc( HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
   ECOsetupCallbacks(hwnd, eci);
	 switch (Msg)
	 {
			case WM_PAINT:							
			{
				tqfProgressBar* object = (tqfProgressBar*)ECOfindObject( eci, hwnd );
				if ( object && object->paint() )
					return qtrue;
				break;
			}
			case WM_TIMER:
			{
				// Start rmm6068
				if (!WNDisWindowVisible(hwnd))
					break;
				// End rmm6068
				// rmm6000:
				tqfProgressBar* object = (tqfProgressBar*)ECOfindObject( eci, hwnd );
				if (object && wParam==WND_TIMER_FIRST)	// PK6704
				{
					if (object->mVal > 0)
					{
						#if defined(iscarbon)
							// Start rmm7067: do nothing if plugin is currently hidden
							#if defined(isRCC) && defined(ismacosx)
								HWND hwnd = WNDgetParent(object->mHWnd);
								while (hwnd)
								{
									HWND ph = WNDgetParent(hwnd);
									if (ph)
									{
										hwnd = ph;
									}
									else
									{
										qlong isHidden;
										WNDgetOS(hwnd, GOS_PLUGINHIDDEN, (qlongptr) &isHidden);	// rmm64bitux
										if (isHidden)
											return qtrue;
										// Plugin is visible, so update it
										break;
									}
								}
							#endif
							// End rmm7067
							object->incphase();
							//object->paint();
							WNDinvalidateRect( object->mHWnd, NULL );
							WNDupdateWindow( object->mHWnd );
						#elif defined(iswin32)
							if (!object->mDisableOSTheme)
							{
								// pkvista9
								if ( object->mIsVista )
								{
									object->updateProgress(NULL);
								}
								//object->mDrawingPulse = object->mIsVista;
								//WNDinvalidateRect( object->mHWnd, NULL );
								//WNDupdateWindow( object->mHWnd );
								//object->mDrawingPulse = qfalse;
							}
						#endif
					}
					return qtrue;
				}
				break;			
			}
			case ECM_OBJCONSTRUCT:				/* Construct an object */
			{
				tqfProgressBar* object = new tqfProgressBar( hwnd );
				ECOinsertObject( eci, hwnd, (void*)object );
				return qtrue;
			}
			case ECM_OBJDESTRUCT:					/* Destruct the object */
			{
				tqfProgressBar* object = (tqfProgressBar*)ECOremoveObject( eci, hwnd );
				if ( object ) delete object;              
				return qtrue;
			}
			case WM_ERASEBKGND:
			{
				return 1L;
			}
			case ECM_PROPERTYCANASSIGN:  	/* Object: Is the property assignable (ie readonly?) */
			case ECM_SETPROPERTY: 				/* Object: Assignment to a property */
			case ECM_GETPROPERTY:					/* Object: Retrieve value from property */
			{
				tqfProgressBar* object = (tqfProgressBar*)ECOfindObject( eci, hwnd );
				if ( object )
					return object->attributeSupport( Msg, wParam, lParam, eci );
				return 0L;
			}
      case ECM_GETCOMPLIBINFO:
      {
      	return ECOreturnCompInfo( gInstLib, eci, LIB_RES_NAME, COMPONENT_COUNT );
      }
			case ECM_GETCOMPICON:
			{ 	
				if ( eci->mCompId==PROGRESS_ID ) return ECOreturnIcon( gInstLib, eci, PROGRESS_ICON );
				return qfalse;
			}
			case ECM_GETCOMPID:
			{
				if ( wParam==1 )
					return ECOreturnCompID( gInstLib, eci, PROGRESS_ID, cObjType_Basic );
				return 0L;
			}
			case ECM_GETPROPNAME:
			{
				return ECOreturnProperties( gInstLib, eci, &PROGRESSproperties[0], 10 );
			}
			case ECM_GETEVENTNAME:
			{
				return ECOreturnEvents(gInstLib,eci,&PROGRESSevents[0],1);
			}
// MHWEB begins.
			case ECM_GETVERSION:	
			{
				return ECOreturnVersion(gInstLib);
			}                                                                 
	    // AE6246
	    case ECM_OBJINITIALIZE:
	    case WM_FLD_FILLCHANGED:	// anumForecolor,anumBackcolor,anumBackpattern
	    case WM_FLD_FONTCHANGED:	// anumFont,anumFontsize,anumFontstyle,anumAlign,anumTextColor
	    {
				tqfProgressBar* object = (tqfProgressBar*)ECOfindObject( eci, hwnd );
				if ( object )
				{
 					object->getBackgroundTheme();
				}
 				break;
		  }
#ifdef isWEB
			case ECM_GETCOMPSTOREGROUP:
			{
				ECOreturnCStoreGrpName( gInstLib, eci, 2010 );
				return 1L;
			}	
#endif
#ifdef isRCCDESIGN
	 		case ECM_CONNECT:
      {
		    return EXT_FLAG_LOADED|EXT_FLAG_ALWAYS_USABLE|EXT_FLAG_REMAINLOADED; // Return external flags
      } 			
#endif
// MHWEB ends.
			case ECM_ISUNICODE:	// rmmuni
			{
				return qtrue;
			}
	 }
	 return WNDdefWindowProc(hwnd,Msg,wParam,lParam,eci);
}

//<ijt220>
#ifdef ismacosx
qbool tqfProgressBar::drawThemeTrack()
{
	qrect r;
	WNDpaintStruct paintStruct;
	WNDbeginPaint( mHWnd, &paintStruct );	//HWNDstruct //HWND
	
	WNDgetClientRect( mHWnd, &r );
	GDIsetBkColor( paintStruct.hdc ,backColor() );
	GDIsetTextColor( paintStruct.hdc, backColor() );
	HBRUSH brush = GDIgetStockBrush( BLACK_BRUSH );
	if ( !WNDdrawThemeBackground( mHWnd, paintStruct.hdc, &r, WND_BK_DEFAULT )  ) // <ijt221>
		GDIfillRect( paintStruct.hdc, &r, brush );	

#ifdef iscarbon
	ThemeTrackDrawInfo proginfo;
	//proginfo.kind = kThemeProgressBar;
	proginfo.kind = kThemeLargeProgressBar; // MHCARBON
	proginfo.bounds.left = r.left;
	proginfo.bounds.right = r.right;
	proginfo.bounds.top = r.top;
	proginfo.bounds.bottom = r.bottom;
	proginfo.min = mMin;
	proginfo.max = mMax;
	proginfo.value = mVal;
	proginfo.attributes &= ~kThemeTrackHasFocus; // MHn0246
	proginfo.attributes &= ~kThemeTrackRightToLeft;
	if (mIsVertical)
		proginfo.attributes &= ~kThemeTrackHorizontal;
	else
		proginfo.attributes |= kThemeTrackHorizontal;
	proginfo.enableState = kThemeTrackActive;
	proginfo.trackInfo.progress.phase = mPhase;	
	//incphase();
	DrawThemeTrack(&proginfo,NULL,NULL,NULL);
#else
	// Start CR0361
  if(mProgbarContainer)
  {
		NSProgressIndicator* progbar = mProgbarContainer.subviews[0];
		
		if(mIsVertical)
		{
			[mProgbarContainer setFrame:NSMakeRect(r.left,r.top,NSProgressIndicatorPreferredLargeThickness,r.height())];
			[progbar setFrame:NSMakeRect(0, 0, NSProgressIndicatorPreferredLargeThickness, r.height())];
		}
		else
		{
			[mProgbarContainer setFrame:NSMakeRect(r.left,r.top,r.width(),NSProgressIndicatorPreferredLargeThickness)];
			[progbar setFrame:NSMakeRect(0, 0, r.width(),NSProgressIndicatorPreferredLargeThickness)];
		}

		if(ECOisDesign(mHWnd))
			[progbar setDoubleValue: (double)mMin];	// this prevents a visible animation if mVal changes
				
		[progbar setMinValue: (double)mMin];
		[progbar setMaxValue: (double)mMax];
		[progbar setDoubleValue: (double)mVal];
		// End CR0361
  }
#endif
	// Start rmm4999
	if (ECOisShowNumber(mHWnd))
		ECOdrawNumberEx(mHWnd, paintStruct.hdc, qtrue);
	// End rmm4999
	ECOdrawMultiKnobs(mHWnd, paintStruct.hdc);	// rmm5006
	WNDendPaint( mHWnd, &paintStruct );	
	return qtrue;	
}
#endif
// End of file
