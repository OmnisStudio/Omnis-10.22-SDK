/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/CALENDAR/calendar.cpp 18481 2017-11-24 08:19:42Z bmitchell $ */

/*************** changes *******************
Date			Edit				Bug					Description
25-Apr-17	rmm9347			ST/RC/1261	Added zoom capability to report class editor.
14-Feb-13	rmm64bit5								Changes required for compiling with 64 bit target.
18-Feb-08	rmm_mobile							Mobile device support.
10-May-05 PK6715			ST/EC/904		Problem with last week in march/first week in april, for the first hour of the day
29-Jun-04	rmm5006									Multiple select knobs were missing from quite a few components.
22-Jun-04	rmm4999									Finished rmm4993: remote form fields now show $xxx correctly.
09-Jul-03	AE6287			ST/EC/448: 	Localised WEB calendar control
22-Jan-02 PK6258      ST/WT/389   Problems assigning dates invalid.
27-Apr-00 MHn0143									Added anumFldStyle
21-Apr-00	rmm3735			ST/FU/252		Allow day-specific tooltips for the calendar (non-Web) component.
																	Use localised day names for the calendar (non-Web) component.
16-Mar-00	rmm3685			ST/EC/467		Fixed GPF.
06-Dec-99	rmm3550									Added current date parameter to all calendar events
04-Oct-99	rmm3478									Added function to return version via version resource.
14-Apr-99 MHn0068									FormCal web conponent version 1.0.
*/

#include <extcomp.he>
#include <extfval.he>
#include <hwnd.he>
#include <gdi.he>
#include <dmconst.he>
#include "calendar.he"
#ifndef isWEB
	#include "localise.he"	// rmm3735
#endif

#include <string.h>
#include <math.h>                       

#define COMPONENT_COUNT 	1				/* Number of controls within library */
#ifdef isWEB
#define LIB_RES_NAME 			1001		/* Resource id of library name */
#define CALENDAR_ID 			2001		/* Resource id of control within library */
#else
#define LIB_RES_NAME 			1000		/* Resource id of library name */
#define CALENDAR_ID 			2000	/* Resource id of control within library */
#endif

#define CALENDAR_ICON 		1				/* Resource bitmap id */


#define DEFINED_KOMNISFIRSTDAY		12		// kSunday has a constant of 12 in the core

const 	qshort	// rmmuni_osx7: added qshort, to avoid Mac warning
				cCalendar_ShowDays 	= 1,
				cCalendar_ShortName   			= 2,
				cCalendar_HeadingMode   		= 3,
				cCalendar_DaysMode   				= 4,
				cCalendar_CurrDayMode   		= 5,
				cCalendar_FirstDay				  = 6,
				cCalendar_AllowChange				= 7,
				cCalendar_HeadingColor			= 8,
				cCalendar_NormalColor				= 9,
				cCalendar_TodaysColor				= 10,
				cCalendar_OtherColor				= 11,
				cCalendar_TodaysBold				= 12,
				cCalendar_CurrentDate				= 13,
				cCalendar_CurrentDayColor		= 14,
				cCalendar_HeadingBold				= 15,
				cCalendar_CurDayFace	 			= 16,
				cCalendar_DayFace						= 17,
				cCalendar_OtherDayFace			= 18,
				cCalendar_HeadingFace				= 19,
				cCalendar_TodayFace					= 20,	
				cCalendar_OtherDaysMode   	= 21,
				cCalendar_HeadingFont				= 22,
				cCalendar_HeadingFontSize		= 23,
				cCalendar_DayFont						= 24,
				cCalendar_DayFontSize				= 25,
				cCalendar_CurrentDayIcon		= 26, // MHn0068
				cCalendar_DayTooltips				= 27,	// rmm3735
				cCalendar_TooltipDate				= 28,	// rmm3735
				// -----------------------      
				cCalendarEvDateChange				= 1,
				cCalendarEvResetMonth				= 2,
				cCalendarEvDateDblClick			= 3,
				// -----------------------      
				cCalendarFuncSetDayIcon     = 1,
				cCalendarFuncGetDayIcon     = 2,
				cCalendarFuncClearDayIcons  = 3;
				

ECOparam CALENDARparams[2] =
{
	7000, fftInteger, 0, 0,			// day
	7001, fftInteger, 0, 0			// iconid
};

ECOmethodEvent CALENDARfunctions[3] = 
{
	cCalendarFuncSetDayIcon,  	6000, 0, 2, &CALENDARparams[0], 0, 0,
	cCalendarFuncGetDayIcon,  	6001, fftInteger, 1, &CALENDARparams[0], 0, 0,
	cCalendarFuncClearDayIcons, 6002, 0, 0, 0, 0, 0
};

ECOparam CALENDAReventParams[1] =	// rmm3550
{
	10000, 										fftDate, 	0,	0
};

ECOmethodEvent CALENDARevents[] = 
{
	cCalendarEvDateChange,  	5000, 0, 1, CALENDAReventParams, 0, 0,		// rmm3550
#ifndef isWEB	// rmm3550: month reset not supported for remote forms
	cCalendarEvResetMonth,  	5001, 0, 1, CALENDAReventParams, 0, 0,		// rmm3550
#endif
	cCalendarEvDateDblClick,  5002, 0, 1, CALENDAReventParams, 0, 0,		// rmm3550
};

ECOproperty CALENDARproperties[] =
{ 
	cCalendar_ShowDays, 				4000, fftBoolean, 0, 0, 0, 0,																											// showdays
	cCalendar_ShortName, 				4001, fftBoolean, 0, 0, 0, 0,																											// heading
	cCalendar_HeadingMode, 			4002, fftInteger, EXTD_FLAG_INTCONSTANT, 0, pre3DStyleF,pre3DStyleL,							// heading draw mode
	cCalendar_DaysMode, 				4003, fftBoolean, EXTD_FLAG_INTCONSTANT, 0, pre3DStyleF,pre3DStyleL,							// days embossed
	cCalendar_CurrDayMode, 			4004, fftBoolean, EXTD_FLAG_INTCONSTANT, 0, pre3DStyleF,pre3DStyleL,							// cur day embossed
	cCalendar_OtherDaysMode,    4020, fftInteger, EXTD_FLAG_INTCONSTANT, 0, pre3DStyleF,pre3DStyleL,							// other day mode
	cCalendar_FirstDay, 				4005, fftInteger, EXTD_FLAG_INTCONSTANT, 0, preDateFuncDayF,preDateFuncDayL,			// first day
	cCalendar_AllowChange, 			4006, fftBoolean, 0, 0, 0, 0,																											// allow change
	cCalendar_HeadingColor, 		4007, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// heading color
	cCalendar_NormalColor, 			4008, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// normal color
	cCalendar_TodaysColor, 			4009, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// today color
	cCalendar_OtherColor, 			4010, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// other color
	cCalendar_TodaysBold, 			4011, fftBoolean, 0, 0, 0, 0,	
	cCalendar_CurrentDate, 			4012, fftDate, 		0, 0, 0, 0,	
	cCalendar_CurrentDayColor,	4013, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// current day color
	cCalendar_HeadingBold,      4014, fftBoolean, 0, 0, 0, 0,
	cCalendar_CurDayFace, 			4015, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// cur day face
	cCalendar_DayFace, 					4016, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// day face
	cCalendar_OtherDayFace, 		4017, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// other day face
	cCalendar_HeadingFace, 			4018, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// heading face
	cCalendar_TodayFace, 				4019, fftInteger, EXTD_FLAG_PWINDCOL, 0, 0, 0,																		// todays face
	cCalendar_HeadingFont, 			4021, fftInteger, EXTD_FLAG_FONTPROP, 0, 0, 0,																		// heading font
	cCalendar_HeadingFontSize, 	4022, fftInteger, 0, 0, 0, 0,																											// heading fontsize
	cCalendar_DayFont, 					4023, fftInteger, EXTD_FLAG_FONTPROP, 0, 0, 0,																		// day font
	cCalendar_DayFontSize, 			4024, fftInteger, 0, 0, 0, 0,																											// day fontsize
	cCalendar_CurrentDayIcon,		4025, fftInteger, EXTD_FLAG_RUNTIMEONLY, 0, 0, 0,																	// current day icon MHn0068
#ifndef isWEB
	cCalendar_DayTooltips,			4026, fftBoolean, 0, 0, 0, 0,																											// rmm3735
	cCalendar_TooltipDate,			4027,	fftDate,		EXTD_FLAG_RUNTIMEONLY, 0, 0, 0																	// rmm3735
#endif
//	anumFldStyle, 					0,		0,							0,0,0,0  // MHn0143
};   

#ifdef ismobile
	// rmm_mobile:
	static const unsigned short sDaysUpToMonth[2][13] = 
	{
		{ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 },	// Normal year
		{ 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 }	// Leap year
	};
	
	static int sGetDayOfYear(int pYear, int pMonth, int pDay)	// Note that pMonth is 0-11
	{
		return sDaysUpToMonth[((!(pYear % 4) && (pYear % 100)) || !(pYear % 400))][pMonth] + pDay - 1;	
	}
	
	// Generates day of week and day of year in struct tm
	static void sGenerateYdayAndWday(struct tm &pTm)
	{
		pTm.tm_yday = sGetDayOfYear(pTm.tm_year + 1900, pTm.tm_mon, pTm.tm_mday);	
		int d = pTm.tm_mday;
		int m = pTm.tm_mon + 1;
		int y = pTm.tm_year + 1900;
		if (m < 3)
		{
			m = m + 12;
			y = y - 1;
		}
		pTm.tm_wday = (d + (2 * m) + ((6 * (m + 1)) / 10) + y + (y / 4) - (y / 100) + (y / 400) + 1) % 7;
	}	
#endif
               
// ---------------------------------------------------------------------------------------------------------

tqfCalendar::tqfCalendar( HWND pFieldHWnd, qbool pReportObj )
{
	mHWnd = pFieldHWnd;
	mReportObj = pReportObj;
	if ( !mReportObj )
	{
		qlong style = WNDgetWindowLong( mHWnd, GWL_EXSTYLE );
		style |= WND_REDRAWONSIZE;
		WNDsetWindowLong( mHWnd, GWL_EXSTYLE, style ); 
	}
	mHeadingMode = WND_BORD_EMBOSSED;
	mDaysMode = WND_BORD_EMBOSSED;
	mOtherDaysMode = WND_BORD_EMBOSSED;
	mCurrentDayMode = WND_BORD_NONE;
	mShowHeading = mAllowDayChange = qtrue;
	mShortName = qtrue;
	mFirstDay = DEFINED_KOMNISFIRSTDAY;    
	mHeadingColor = GDI_COLOR_BTNTEXT;  
	mNormalColor = GDI_COLOR_BTNTEXT;
	mTodaysColor = GDI_COLOR_QBLACK;  
	mOtherMonthColor = GDI_COLOR_GRAYTEXT;
	mCurrentDayColor = GDI_COLOR_BTNTEXT;
	mCurrentDayColorFace = GDI_COLOR_3DFACE;
	mDayColorFace = GDI_COLOR_3DFACE;
	mOtherDayColorFace = GDI_COLOR_3DFACE;
	mHeadingColorFace = GDI_COLOR_3DFACE;
	mTodayFaceColor = GDI_COLOR_3DFACE;
	mTodayBold = qtrue; 
	mHeadingBold = qtrue;  
	mDayFont = mHeadingFont = 1;
	mDayFontSize = mHeadingFontSize = 6;
	mCurrentDayIcon = 0; // MHn0068
	initTodaysDate();
	mDayList = new EXTqlist( listVlen );
	mTooltipIndex = -1;			// rmm3735
	mDayTooltips = qfalse;	// rmm3735
#ifdef ismobile
	mHasFocus = qfalse;	// rmm_mobile
#endif
}

tqfCalendar::~tqfCalendar()
{         
	*mDayList = qnil;
	delete mDayList;
}

void tqfCalendar::setDayMark( qlong pDay, qlong pIconId )
{
	EXTfldval fval;
	qlong lc = mDayList->rowCnt();
	for ( qlong line = 1; line<=lc; line++ )
	{
    mDayList->getColValRef(line, 1, fval, qfalse );
		if ( fval.getLong()==pDay )
		{
			// found day, so update iconid
      mDayList->getColValRef(line, 2, fval, qtrue );
			fval.setLong( pIconId );
			return;			
		}
	}  
	qlong newline = mDayList->insertRow();
  mDayList->getColValRef(newline, 1, fval, qtrue );
	fval.setLong( pDay );
  mDayList->getColValRef(newline, 2, fval, qtrue );
	fval.setLong( pIconId );
}

qlong tqfCalendar::getDayMark( qlong pDay )
{
	EXTfldval fval;
	qlong lc = mDayList->rowCnt(); if ( !lc ) return 0;
	for ( qlong line = 1; line<=lc; line++ )
	{
    mDayList->getColValRef(line, 1, fval, qfalse );
		if ( fval.getLong()==pDay )
		{
			// found day, so update iconid
      mDayList->getColValRef(line, 2, fval, qfalse );
			return fval.getLong();
		}
	}                           
	return 0;
}

void tqfCalendar::functionSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( ECOgetId(eci) )
	{
		case cCalendarFuncSetDayIcon:
		{
			EXTParamInfo* param = ECOfindParamNum( eci, 1 ); 
			if ( !param ) break; // Method called with too few parameters
			EXTfldval fval( (qfldval)param->mData );
			qlong day = fval.getLong();

			param = ECOfindParamNum( eci, 2); 
			if ( !param ) break; // Method called with too few parameters
			EXTfldval fval2( (qfldval)param->mData );
      qlong iconid = fval2.getLong();
      
			setDayMark( day, iconid );
			if ( !mReportObj )
				WNDinvalidateRect( mHWnd, NULL );
			break;
		}
		case cCalendarFuncGetDayIcon:
		{
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( !param ) break; // Method called with too few parameters
			EXTfldval fval( (qfldval)param->mData );
      qlong day = fval.getLong();
      qlong iconid = getDayMark( day );
			EXTfldval result;
			result.setLong(iconid);
      ECOaddParam(eci,&result);
			break;
		}
		case cCalendarFuncClearDayIcons:
		{
			mDayList->clear( listVlen );
			if ( !mReportObj )
				WNDinvalidateRect( mHWnd, NULL );
			break;
		}
	}
}

qlong tqfCalendar::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	switch( pMessage )
	{ 
		case ECM_PROPERTYCANASSIGN: 
		{
			return ECOgetId(eci) != cCalendar_TooltipDate;	// rmm3735
		}
		case ECM_SETPROPERTY: 
		{       
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if ( param )
			{
				EXTfldval fval( (qfldval)param->mData );
				qbool doInval = qtrue;	// rmm3735
				switch( ECOgetId(eci) )
				{
					case cCalendar_ShowDays:					mShowHeading = fval.getLong()==1; setGridSizes(); break;
					case cCalendar_ShortName:   			mShortName = fval.getLong()==1; setGridSizes(); break;
					case cCalendar_HeadingMode:   		mHeadingMode = fval.getLong(); setGridSizes(); break;
					case cCalendar_DaysMode:   				mDaysMode = fval.getLong(); setGridSizes(); break;
					case cCalendar_CurrDayMode:   		mCurrentDayMode = fval.getLong(); setGridSizes(); break;
					case cCalendar_FirstDay:					
					{       
						mFirstDay = (qshort)fval.getLong(); 
						setDateArray();
						setGridSizes(); 
						break;
					}
					case cCalendar_AllowChange:				mAllowDayChange = fval.getLong()==1; setGridSizes(); break;
					case cCalendar_HeadingColor:			mHeadingColor = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_NormalColor:				mNormalColor = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_TodaysColor:				mTodaysColor = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_OtherColor:				mOtherMonthColor = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_TodaysBold:				mTodayBold = fval.getLong()==1; setGridSizes(); break;
					case cCalendar_CurrentDate:				
					{
						datestamptype date;
						if ( !fval.conv(fftDate,dpFdate1900) ) return 0L;	// PK6258
						fval.getDate( date, dpFdate1900 );
						setDateFromOmnis( date );
						break;
					}
					case cCalendar_CurrentDayColor:   mCurrentDayColor = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_HeadingBold:				mHeadingBold = (qbool)fval.getLong()==1; setGridSizes(); break;
					case cCalendar_CurDayFace:				mCurrentDayColorFace = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_DayFace:						mDayColorFace = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_OtherDayFace:			mOtherDayColorFace = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_HeadingFace:				mHeadingColorFace = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_TodayFace:					mTodayFaceColor = (qcol)fval.getLong(); setGridSizes(); break;
					case cCalendar_OtherDaysMode:			mOtherDaysMode = fval.getLong(); setGridSizes(); break;
					case cCalendar_HeadingFont:				mHeadingFont = ECOgetFontIndex(mHWnd,fval); setGridSizes(); break;
					case cCalendar_HeadingFontSize:		mHeadingFontSize = fval.getLong(); setGridSizes(); break;
					case cCalendar_DayFont:						mDayFont = ECOgetFontIndex(mHWnd,fval);  setGridSizes(); break;
					case cCalendar_DayFontSize:				mDayFontSize = fval.getLong(); setGridSizes(); break;
					// MHn0068 begins.
					case cCalendar_CurrentDayIcon: 
					{
						qshort day = mCurrentDate.tm_mday;
						mCurrentDayIcon = fval.getLong(); 
						setDayMark(day,mCurrentDayIcon);
						setGridSizes();  
						break;
					}
					// MHn0068 ends.
					// rmm3735:
					#ifndef isWEB
					case cCalendar_DayTooltips:				mDayTooltips = (qbool) (fval.getLong() != 0); doInval = qfalse; break;
					#endif
				}         
				if ( doInval && !mReportObj && ECOisSetup( mHWnd ) )	// rmm3735
				{
					WNDinvalidateRect( mHWnd, NULL );
					WNDupdateWindow( mHWnd );
				}
				return 1L;
			}
			break;
		}
		case ECM_GETPROPERTY: 
		{
			EXTfldval fval;
			switch( ECOgetId(eci) )
			{
				case cCalendar_ShowDays:					fval.setLong( (qlong)mShowHeading ); break;
				case cCalendar_ShortName:   			fval.setLong( (qlong)mShortName ); break;
				case cCalendar_HeadingMode:   		fval.setLong( mHeadingMode ); break;
				case cCalendar_DaysMode:   				fval.setLong( mDaysMode ); break;
				case cCalendar_CurrDayMode:   		fval.setLong( mCurrentDayMode ); break;
				case cCalendar_FirstDay:					fval.setLong( (qlong)mFirstDay ); break;
				case cCalendar_AllowChange:				fval.setLong( (qlong)mAllowDayChange ); break;
				case cCalendar_HeadingColor:			fval.setLong( (qlong)mHeadingColor ); break;
				case cCalendar_TodaysColor:				fval.setLong( (qlong)mTodaysColor ); break;
				case cCalendar_OtherColor:				fval.setLong( (qlong)mOtherMonthColor ); break;
				case cCalendar_NormalColor:				fval.setLong( (qlong)mNormalColor ); break;
				case cCalendar_TodaysBold:   			fval.setLong( (qlong)mTodayBold ); break;
				case cCalendar_CurrentDate:				
				{
					datestamptype date;
					getDateForOmnis( date );
					fval.setDate( date, dpFdate1900 );
					break;
				}
				case cCalendar_CurrentDayColor:   fval.setLong( (qlong)mCurrentDayColor ); break;
				case cCalendar_HeadingBold:				fval.setLong( (qlong)mHeadingBold ); break;
				case cCalendar_CurDayFace:				fval.setLong( (qlong)mCurrentDayColorFace ); break;
				case cCalendar_DayFace:						fval.setLong( (qlong)mDayColorFace ); break;
				case cCalendar_OtherDayFace:			fval.setLong( (qlong)mOtherDayColorFace ); break;
				case cCalendar_HeadingFace:				fval.setLong( (qlong)mHeadingColorFace ); break;
				case cCalendar_TodayFace:					fval.setLong( (qlong)mTodayFaceColor ); break;
				case cCalendar_OtherDaysMode:			fval.setLong( (qlong)mOtherDaysMode ); break;
				case cCalendar_HeadingFont:				fval.setLong( mHeadingFont ); break;
				case cCalendar_HeadingFontSize:		fval.setLong( mHeadingFontSize ); break;
				case cCalendar_DayFont:						fval.setLong( mDayFont ); break;
				case cCalendar_DayFontSize:				fval.setLong( mDayFontSize ); break;
				// MHn0068 begins.
				case cCalendar_CurrentDayIcon: 
				{
					qshort day = mCurrentDate.tm_mday;
					qlong lico = getDayMark(day);
					fval.setLong( lico );
					break;
				}
				// MHn0068 ends.
				// rmm3735:
				#ifndef isWEB
				case cCalendar_DayTooltips:				fval.setLong(mDayTooltips); break;
				case cCalendar_TooltipDate:
				{
					struct tm tooltipDate = mCurrentDate;
					if (mTooltipIndex >= 0)
					{
						tooltipDate.tm_mday = mDayDates[mTooltipIndex].mDay;
						if (mDayDates[mTooltipIndex].mThisMonth) /* Empty */ ;
						else if (mDayDates[mTooltipIndex].mPrevMonth)
						{
							tooltipDate.tm_mon--;
							if (tooltipDate.tm_mon < 0)
							{
								tooltipDate.tm_mon = 11;
								tooltipDate.tm_year--;
							}
						}
						else
						{
							// Next month
							tooltipDate.tm_mon++;
							if (tooltipDate.tm_mon > 11)
							{
								tooltipDate.tm_mon = 0;
								tooltipDate.tm_year++;
							}
						}
					}
					datestamptype date;
					getDateForOmnis( date, &tooltipDate );
					fval.setDate( date, dpFdate1900 );
					break;
				}
				#endif
			}         
			ECOaddParam(eci,&fval);
			return 1L;
		}
	}
	return 0;
}

void tqfCalendar::getDateForOmnis( datestamptype& pDate, struct tm *pDateToConvert )	// rmm3735
{
	// convert mCurrentDate(tm) into datestamp
	fillc(&pDate, sizeof(pDate), 0);	// rmm3550
	// rmm3735: use pDateToConvert below, instead of mCurrentDate
	if (!pDateToConvert) pDateToConvert = &mCurrentDate;
	// MHn0068 begins.
#ifdef isRCC
	pDate.year = pDateToConvert->tm_year + 1900;
	pDate.month = pDateToConvert->tm_mon+1;
	pDate.day = pDateToConvert->tm_mday;
	pDate.dateok = qtrue;
#else
	pDate.mYear = pDateToConvert->tm_year + 1900;
	pDate.mMonth = pDateToConvert->tm_mon+1;
	pDate.mDay = pDateToConvert->tm_mday;
	pDate.mDateOk = qtrue;
	// MHn0068 ends.
#endif
}

void tqfCalendar::setDateFromOmnis( datestamptype& pDate )
{
	// convert datestamp into mCurrentDate(tm)
	// MHn0068 begins
#ifdef isRCC
	mCurrentDate.tm_year = pDate.year;
	if ( mCurrentDate.tm_year>1900 ) mCurrentDate.tm_year-=1900;
	mCurrentDate.tm_mon = pDate.month-1;
	mCurrentDate.tm_mday = pDate.day;
#else
	mCurrentDate.tm_year = pDate.mYear;
	if ( mCurrentDate.tm_year>1900 ) mCurrentDate.tm_year-=1900;
	mCurrentDate.tm_mon = pDate.mMonth-1;
	mCurrentDate.tm_mday = pDate.mDay;
#endif
	// MHn0068 ends.
#ifdef ismobile
	// rmm_mobile: Need to generate the other fields we use in the tm structure
	sGenerateYdayAndWday(mCurrentDate);
#else	
	time_t tmp;
	tmp = mktime( &mCurrentDate );
	if ( tmp!=-1 ) mCurrentDate = *localtime( &tmp );   
#endif

	setDateArray();
	if ( !mReportObj )
		WNDinvalidateRect( mHWnd, NULL );
}

void tqfCalendar::paintDayName( HDC pHdc, qshort pCell, qrect* pArea, EXTCompInfo* eci ) // rmm3735
{
	qrect cellrect = *pArea;
	GDIinsetRect( &cellrect, 2, 2 );

	GDIsetClipRect( pHdc, pArea );
  
	qchar name[64];
	qlong dayid = pCell+( mFirstDay - DEFINED_KOMNISFIRSTDAY );
	if ( dayid>6 ) dayid-=7;
	// Start rmm3735
	qlong slen;
	qbool ok = qfalse;
	qchar *namePtr;
	str255 locItemData;
	//  AE6287 Starts
#ifdef isWEB
	str80 s( (mShortName ? QTEXT("V") : QTEXT("w") ) );
	ECOsetDTformat(s,dpFdate1900);
	EXTfldval fval; 
	datestamptype date;
	fillc(&date, sizeof(date), 0);
	#ifdef isRCC
		date.year = 2003;
		date.month = 1;
		date.day = (char) (5 + dayid);
		date.dateok = qtrue;
	#else
		date.mYear = 2003;
		date.mMonth = 1;
		date.mDay = (char) (5 + dayid);
		date.mDateOk = qtrue;
	#endif
	fval.setDate( date, dpFdate1900 );
	fval.getChar(locItemData);
	namePtr = &locItemData[1];
	slen = locItemData[0];
	ok = qtrue;
	ECOsetDTformat(s,dpFdate1900);
	//  AE6287 Ends
#else
	qshort locItemXn = mShortName ? cLOCxnAbbMonText : cLOCxnFullMondayText;
	locItemXn += (!dayid ? 6 : (dayid - 1));
	if (ECOreadLocalisationItem(eci, locItemXn, locItemData))
	{
		namePtr = &locItemData[1];
		slen = locItemData[0];
		ok = qtrue;
	}
#endif
	if (!ok)
	{
		qlong id = mShortName ? 3010 : 3000;
		slen = (qshort)RESloadString( gInstLib, id + dayid, &name[0], 64 );
		namePtr = name;
	}
	GDIsetTextColor( pHdc, mHeadingColor );
	GDIdrawText( pHdc, cellrect.left + cellrect.width()/2, cellrect.top, namePtr, (qshort) slen, jstCenter );
	// End rmm3735

	GDIclearClip( pHdc );
}

void tqfCalendar::getBorderSpec( WNDborderStruct* pBorderSpec, qlong pMode )
{
 	switch ( pMode )
 	{
  	case WND_BORD_NONE: case WND_BORD_INSET: case WND_BORD_EMBOSSED: case WND_BORD_CHISEL: case WND_BORD_EMBOSSEDCHISEL:
			*pBorderSpec = WNDborderStruct( (qshort)pMode );
			break;
  	case WND_BORD_PLAIN:
  	{
  		*pBorderSpec = WNDborderStruct( (qshort)pMode, qpen(1) );
  		pBorderSpec->mSize1 = pBorderSpec->mSize2 = pBorderSpec->mSize3 = 1;
  		pBorderSpec->mLineStyle.mWidth = 1;
  		pBorderSpec->mLineStyle.mColor = colBlack;
  		break;
  	}
  	case WND_BORD_BEVEL: case WND_BORD_INSETBEVEL:
  		*pBorderSpec = WNDborderStruct( (qshort)pMode, 2, 2, 2 );
  		break;
  	case WND_BORD_SHADOW:
  		*pBorderSpec = WNDborderStruct( (qshort)pMode, qpen(), 2, 2, colBlack );
  		break;
  	default:
  		*pBorderSpec = WNDborderStruct( WND_BORD_NONE );
  		break;
  }
}

void tqfCalendar::paintDayTitles( HDC pHdc, EXTCompInfo* eci ) // rmm3735
{
	qrect clientRect = mClientRect;
	clientRect.bottom = clientRect.top + mTitleHeight;
	
	qfnt fnt = fntSmallFnt;
	ECOgetFont( mHWnd, &fnt, (qshort)mHeadingFont, (qshort)mHeadingFontSize );

	// Start rmm9347
	GDIfontCreator fc(pHdc, ECOgetFontDpi(mHWnd));
	HFONT font = fc.createFont(&fnt, mHeadingBold ? styBold : styPlain);
	// End rmm9347

	HFONT oldfnt = GDIselectObject( pHdc, font );
	qrect titleRect = clientRect; titleRect.right = titleRect.left + mColumnWidth - 1;
	
	WNDborderStruct borderSpec; getBorderSpec( &borderSpec, mHeadingMode );
		
	HBRUSH brush = GDIgetStockBrush( BLACK_BRUSH );
	for ( qshort i = 0; i<=6; i++ )
	{
		if ( i==6 ) titleRect.right = clientRect.right;
		GDIsetTextColor( pHdc, mHeadingColorFace );
		GDIfillRect( pHdc,&titleRect,brush);
		WNDpaintBorder(	mHWnd, pHdc, &titleRect, &borderSpec );
		qrect titleRect1 = titleRect;
		GDIinsetRect( &titleRect1, 2, 2 );
		paintDayName( pHdc, i, &titleRect, eci );  // rmm3735
		GDIoffsetRect( &titleRect, mColumnWidth, 0 );
	} 
	GDIselectObject( pHdc, oldfnt );
	GDIdeleteObject( font );
}

qbool tqfCalendar::isToday( qshort pIndex )
{
	return pIndex==mLastTodayIndex;
}

qbool tqfCalendar::isCurrentDay( qshort pIndex )
{
	return pIndex==mLastCurDayIndex;
}

qrect tqfCalendar::getIndexRect( qshort pIndex )
{
	qrect client=mClientRect,client1; 
	client1 = client;
	client.top = client.top + mTitleHeight+1;
	client.bottom = client.top + mColumnHeight-1;
	client.right = client.left + mColumnWidth-1;
	qshort row = pIndex / 7;
	qshort col = pIndex - ( row * 7 ); 
	GDIoffsetRect( &client, col * mColumnWidth, row * mColumnHeight );
	if ( col==6 ) client.right = client1.right;
	if ( row==5 ) client.bottom = client1.bottom;
	return client;
}

void tqfCalendar::findCell( qpoint* pPoint, qbool pIsDoubleClick )
{
	if ( !mAllowDayChange ) return;
	qrect client = mClientRect;
	client.top = client.top + mTitleHeight+1;
	client.bottom = client.top + (qshort)mColumnHeight; 
	client.right = client.left + (qshort)mColumnWidth;   
		
	for ( qshort cellindex = 0; cellindex<42; cellindex++ )
	{
		qrect r = getIndexRect( cellindex );
		if (GDIptInRect(&r, pPoint))
		{
			changeDayAndSendEvent(cellindex, pIsDoubleClick);	// rmm_mobile
		}
	}
}

// rmm_mobile: Made this into a method
void tqfCalendar::changeDayAndSendEvent(qshort pCellIndex, qbool pIsDoubleClick)
{
	qbool canSendEvent = ECOisOMNISinTrueRuntime( mHWnd );
	qrect r = getIndexRect( pCellIndex );
	if ( mDayDates[pCellIndex].mThisMonth )
	{
		mCurrentDate.tm_mday = mDayDates[pCellIndex].mDay;
		qrect r1 = getIndexRect( mLastCurDayIndex );
		mLastCurDayIndex = pCellIndex;
		if ( !mReportObj )
		{
			WNDinvalidateRect( mHWnd, &r );
			WNDinvalidateRect( mHWnd, &r1 );
			if ( canSendEvent ) 
			{
				EXTfldval currentDate; datestamptype ds; getDateForOmnis(ds); currentDate.setDate(ds);															// rmm3550
				ECOsendEvent( mHWnd, pIsDoubleClick ? cCalendarEvDateDblClick : cCalendarEvDateChange, &currentDate, 1, qfalse );		// rmm3550 // rmm3685: push the event
			}
			WNDupdateWindow( mHWnd );
		}
	}  
	else
	{
		if ( mDayDates[pCellIndex].mPrevMonth )
		{
			mCurrentDate.tm_mday = mDayDates[pCellIndex].mDay;
			mCurrentDate.tm_mon--;
		}
		else
		{
			mCurrentDate.tm_mday = mDayDates[pCellIndex].mDay;
			mCurrentDate.tm_mon++;
		}
		#ifdef ismobile
			if (mCurrentDate.tm_mon < 0) 
			{
				mCurrentDate.tm_mon = 11;
				mCurrentDate.tm_year--;
			}
			else if (mCurrentDate.tm_mon > 11)
			{
				mCurrentDate.tm_mon = 0;
				mCurrentDate.tm_year++;
			}
			sGenerateYdayAndWday(mCurrentDate);	// rmm_mobile
		#else
			time_t tmp;
			tmp = mktime( &mCurrentDate );
			if ( tmp!=-1 ) mCurrentDate = *localtime( &tmp );   
		#endif
		setDateArray();
		if ( !mReportObj )
		{
			WNDinvalidateRect( mHWnd, NULL );
			if ( canSendEvent ) 
			{
				// Start rmm3550
				EXTfldval currentDate; datestamptype ds; getDateForOmnis(ds); currentDate.setDate(ds);
				#ifndef isWEB
					ECOsendEvent( mHWnd, cCalendarEvResetMonth, &currentDate, 1, qfalse ); // rmm3685: push the event
				#endif
				ECOsendEvent( mHWnd, pIsDoubleClick ? cCalendarEvDateDblClick : cCalendarEvDateChange, &currentDate, 1, qfalse ); // rmm3685: push the event
				// End rmm3550
			}
			WNDupdateWindow( mHWnd );
		}
	}
}

#ifdef ismobile
	// rmm_mobile: Added keyboard support - left and right navigate all dates, up and down
	// will navigate dates and do a tab or shift tab at the bottom and top of the control, 
	// and return does a double click.
	qbool tqfCalendar::key(HWND pHwnd, UINT pMessage, qkey *pKey)
	{
		if (!mAllowDayChange || !mHasFocus || WM_KEYDOWN != pMessage) return qfalse;
		qbool processedKey = qfalse;
		vchar vc = pKey->getVChar();
		if (vcLeft == vc)
		{
			if (mLastCurDayIndex > 0) 
			{
				changeDayAndSendEvent(mLastCurDayIndex - 1, qfalse);
				processedKey = qtrue;
			}
		}
		else if (vcRight == vc)
		{
			if (mLastCurDayIndex < 41) 
			{
				changeDayAndSendEvent(mLastCurDayIndex + 1, qfalse);
				processedKey = qtrue;
			}
		}
		else if (vcUp == vc)
		{
			// Up generates a tab if it would go into the previous month
			if ((mLastCurDayIndex - 7) >= 0 && mDayDates[mLastCurDayIndex - 7].mThisMonth)
			{
				changeDayAndSendEvent(mLastCurDayIndex - 7, qfalse);
				processedKey = qtrue;
			}
		}
		else if (vcDown == vc)
		{
			// Down generates a tab if it would go into the previous month
			if ((mLastCurDayIndex + 7) <= 41 && mDayDates[mLastCurDayIndex + 7].mThisMonth)
			{
				changeDayAndSendEvent(mLastCurDayIndex + 7, qfalse);
				processedKey = qtrue;
			}
		}
		else if (vcReturn == vc)
		{
			changeDayAndSendEvent(mLastCurDayIndex, qtrue);
			processedKey = qtrue;
		}
		return processedKey;
	}
#endif


void tqfCalendar::paintSingleDay( HDC pHdc, qshort pCellIndex, HFONT pNormal, HFONT pBold )
{
	qrect cell = getIndexRect( pCellIndex );
	qbool istoday = isToday( pCellIndex ); 
	qbool isCurrent = isCurrentDay( pCellIndex );
	
	HFONT oldfnt = ( istoday && mTodayBold ) ? GDIselectObject( pHdc, pBold ) : GDIselectObject( pHdc, pNormal );  
	
	WNDborderStruct borderSpec; 
	qlong md = mDaysMode;
	if ( isCurrent ) 
		md = mCurrentDayMode;
	else if ( !mDayDates[ pCellIndex ].mThisMonth )  
		md = mOtherDaysMode;

	getBorderSpec( &borderSpec, md );

	if ( isCurrent ) 
		GDIsetTextColor( pHdc, mCurrentDayColorFace );
	else if ( istoday ) 
		GDIsetTextColor( pHdc, mTodayFaceColor );
	else if ( mDayDates[ pCellIndex ].mThisMonth )
		GDIsetTextColor( pHdc, mDayColorFace );
	else 
		GDIsetTextColor( pHdc, mOtherDayColorFace );
	GDIfillRect( pHdc, &cell, GDIgetStockBrush( BLACK_BRUSH ) );

	WNDpaintBorder(	mHWnd, pHdc, &cell, &borderSpec );
	qrect cell1 = cell;
	GDIinsetRect( &cell1, 2, 2 );
		
	// draw day id
	qshort day = mDayDates[ pCellIndex ].mDay;
	str255 s;
	qlongToString(day,s);
	if ( istoday ) 
		GDIsetTextColor( pHdc, mTodaysColor );
	else
	{ 
		if ( isCurrent ) GDIsetTextColor( pHdc, mCurrentDayColor );
		else GDIsetTextColor( pHdc, mDayDates[ pCellIndex ].mThisMonth ? mNormalColor : mOtherMonthColor );
	}
	
  if ( mDayDates[ pCellIndex ].mThisMonth )
  {
	  qlong iconid = getDayMark( day );
		//if (((!(iconid)) && (isCurrent))) iconid = mCurrentDayIcon; // MHn0068
	  if ( iconid )
	  {
			EXTBMPref* bmp = new EXTBMPref( iconid,0,mApp ); // MHn0068
			if ( bmp ) 
			{
				ePicSize psize = EXTBMPref::getBmpSize( iconid );
				qrect drawrect,bmprect; bmp->getRect( &bmprect, psize );
				drawrect = cell1; drawrect.left = drawrect.right - bmprect.width();
				bmp->draw( pHdc, &drawrect , EXTBMPref::getBmpSize( iconid ) , picNormal, qfalse, colNone, qfalse , jstCenter, jstCenter);
				delete bmp;
			}
	  }
  }
  
	GDIdrawText( pHdc, cell1.left, cell1.top, &s[1], s.length(), jstLeft );
	
	GDIselectObject( pHdc, oldfnt );  
}

void tqfCalendar::paintDays( HDC pHdc )
{
	qfnt fnt = fntSmallFnt;
	ECOgetFont( mHWnd, &fnt, (qshort)mDayFont, (qshort)mDayFontSize );

	// Start rmm9347
	GDIfontCreator fc(pHdc, ECOgetFontDpi(mHWnd));
	HFONT font = fc.createFont(&fnt, styPlain);
	HFONT font2 = fc.createFont(&fnt, styBold);
	// End rmm9347
	for ( qshort cellindex = 0; cellindex<42; cellindex++ )
	{
		paintSingleDay( pHdc, cellindex, font, font2 );
	}
	GDIdeleteObject( font2 );					
	GDIdeleteObject( font );
}

void tqfCalendar::setGridSizes()
{
	if ( !mReportObj )
		WNDgetClientRect( mHWnd, &mClientRect );
	mColumnWidth = mClientRect.width() / 7;
	qshort ht = mClientRect.height();     

	if ( mShowHeading ) 
	{
		qfnt fnt;
		ECOgetFont(mHWnd, &fnt, (qshort)mHeadingFont, (qshort)mHeadingFontSize);
		// Start rmm9347
		qdim dpi = ECOgetFontDpi(mHWnd);
		if (dpi)
		{
			HDC hdc = 0; HRESERVED res = 0;
			GDIcreateScreenDC(&hdc, &res);

			GDIfontCreator fc(hdc, dpi);
			HFONT hfont = fc.createFont(&fnt, styPlain);
			HFONT oldFont = GDIselectObject(hdc, hfont);
			mTitleHeight = 4 + GDIfontPart(hdc, eFontLineHeight);
			GDIselectObject(hdc, oldFont);
			GDIdeleteObject(hfont);

			GDIdeleteScreenDC(hdc, res);
		}
		else
			// End rmm9347
 			mTitleHeight = 4 + GDIfontPart( &fnt, styPlain, eFontLineHeight ); // rmm3735: since rectangle is inset by 4 before drawing text
 	}
 	else mTitleHeight = 0;

	if ( mShowHeading ) ht -= mTitleHeight;
	mColumnHeight = ht / 6;
}

void tqfCalendar::initTodaysDate()
{
#ifdef ismobile
	// rmm_mobile: Unix-style time functions are not present on Windows Mobile
	SYSTEMTIME st;
	GetLocalTime(&st);
	mCurrentDate.tm_year = st.wYear - 1900;
	mCurrentDate.tm_mon = st.wMonth - 1;
	mCurrentDate.tm_mday = st.wDay;
	mCurrentDate.tm_wday = st.wDayOfWeek;
	mCurrentDate.tm_yday = sGetDayOfYear(st.wYear, mCurrentDate.tm_mon, mCurrentDate.tm_mday);
	mCurrentDate.tm_hour = st.wHour;
	mCurrentDate.tm_min = st.wMinute;
	mCurrentDate.tm_sec = st.wSecond;
	mCurrentDate.tm_isdst = 0;	// Not used in this file
#else
  time_t now;
	time( &now );
  mCurrentDate = *localtime( &now );
#endif
  mTodaysDate = mCurrentDate;
  setDateArray();
}

#define SEARCH_PREV_MONTH 1
#define SEARCH_THIS_MONTH 2 
#define SEARCH_NEXT_MONTH 3

qshort tqfCalendar::getMonthLen( qshort pMonth )
{
	qshort len = 0; pMonth++;
	switch( pMonth )
	{
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
			len = 31; break;
		case 4: case 6: case 9: case 11:  
			len = 30; break;
		case 2:
			len = 28;
	}
	return len;
}

void tqfCalendar::setDateArray()
{
  struct tm searchmonth;
  struct tm monthstart;
  struct tm nextmonth;
  struct tm previousmonth;
    
	// get month start   
	monthstart = mCurrentDate;
	monthstart.tm_mday = 1;
	monthstart.tm_hour = 12; // PK6715
	monthstart.tm_min = 0; // PK6715
	#ifdef ismobile
		sGenerateYdayAndWday(monthstart);	// rmm_mobile
	#else
		time_t tmp = mktime( &monthstart );
		if ( tmp==-1 ) return;
		monthstart = *localtime( &tmp ); 
	#endif	
	// get previous month start   
	previousmonth = mCurrentDate;
	previousmonth.tm_mday = 1;
	previousmonth.tm_hour = 12; // PK6715
	previousmonth.tm_min = 0; // PK6715
	previousmonth.tm_mon--;
	if ( previousmonth.tm_mon<0 ) 
	{
		previousmonth.tm_mon = 11;
		previousmonth.tm_year--;
	}
	#ifdef ismobile
		sGenerateYdayAndWday(previousmonth);	// rmm_mobile
	#else
		tmp = mktime( &previousmonth );
		if ( tmp==-1 ) return;
		previousmonth = *localtime( &tmp );   
	#endif
	// get next month
	nextmonth = mCurrentDate;
	nextmonth.tm_mday = 1;
	nextmonth.tm_hour = 12; // PK6715
	nextmonth.tm_min = 0; // PK6715
	nextmonth.tm_mon++;
	if ( nextmonth.tm_mon>11 )
	{
		nextmonth.tm_mon = 0;
		nextmonth.tm_year++;
	}
	#ifdef ismobile
		sGenerateYdayAndWday(nextmonth);	// rmm_mobile
	#else
		tmp = mktime( &nextmonth ); 
		if ( tmp==-1 ) return;
		nextmonth = *localtime( &tmp ); 
	#endif	
	// now setup days to disply from previous month
	qshort monthStart = monthstart.tm_wday;
	qshort calDayStart = mFirstDay - DEFINED_KOMNISFIRSTDAY;
	qshort daydiff = 0;
	if ( calDayStart==monthStart )
	{
		// both month and day start fall on same day, so go back a week
		daydiff = -7;		
	}
	else if ( calDayStart>monthStart )
	{
		daydiff = (calDayStart-monthStart) - 7;
	}
	else
	{
		daydiff = (calDayStart-monthStart);
	}
	daydiff++;
	  
	qshort prevmonthlen = getMonthLen( previousmonth.tm_mon );
	qshort monthlen = getMonthLen( monthstart.tm_mon );
	if ( monthstart.tm_mon==1 )
		monthlen = nextmonth.tm_yday - monthstart.tm_yday;	
	if ( previousmonth.tm_mon==1 )
		prevmonthlen = monthstart.tm_yday - previousmonth.tm_yday;	
 	
	// setup caendar day array
	
	qshort startdate = prevmonthlen + daydiff; 
	qshort monthon = SEARCH_PREV_MONTH;
	
	searchmonth = previousmonth;
	searchmonth.tm_mday = startdate;
	
	mLastCurDayIndex = mLastTodayIndex = 99;

	for ( qshort day = 0; day<42; day++ )
	{              
		qshort searchyear = searchmonth.tm_year+1900;
		
		mDayDates[day].mDay = startdate;
		mDayDates[day].mThisMonth = monthon==SEARCH_THIS_MONTH;
		mDayDates[day].mPrevMonth = monthon==SEARCH_PREV_MONTH;
		mDayDates[day].mToday = (qbool)( searchmonth.tm_mon==mTodaysDate.tm_mon && searchmonth.tm_mday==mTodaysDate.tm_mday && mTodaysDate.tm_year+1900==searchyear );
		mDayDates[day].mIsCurrent = (qbool)(monthon==SEARCH_THIS_MONTH && mCurrentDate.tm_year+1900==searchyear && mCurrentDate.tm_mday==startdate );
	
		if ( mDayDates[day].mIsCurrent ) 
			mLastCurDayIndex = day;

		if ( mDayDates[day].mToday ) 
			mLastTodayIndex = day;
	
		startdate++;
		searchmonth.tm_mday++;
		switch( monthon )
		{
			case SEARCH_PREV_MONTH:
			{
				if ( startdate>prevmonthlen )
				{
					monthon = SEARCH_THIS_MONTH;
					searchmonth.tm_mon++; 
					if ( searchmonth.tm_mon>11 )
					{
						searchmonth.tm_mon = 0;
						searchmonth.tm_year++;
					}
					searchmonth.tm_mday = 1;
					startdate = 1;
				} 
				break;
			}
			case SEARCH_THIS_MONTH:
			{
				if ( startdate>monthlen )
				{
					monthon = SEARCH_NEXT_MONTH;
					startdate = 1;
				} 
				break;
			}
		}
	} 
}


void tqfCalendar::paintCalendar( HDC pHdc, EXTCompInfo* eci ) // rmm3635
{
	setGridSizes();
	if ( mShowHeading ) paintDayTitles( pHdc, eci ); // rmm3735
	paintDays( pHdc );
}

qbool tqfCalendar::paint(EXTCompInfo* eci) // rmm3735
{
	WNDpaintStruct paintStruct;
	WNDbeginPaint( mHWnd, &paintStruct );
	paintCalendar( paintStruct.hdc, eci );	// rmm3735
	// Start rmm4999
	if (ECOisShowNumber(mHWnd))
		ECOdrawNumberEx(mHWnd, paintStruct.hdc, qtrue);
	// End rmm4999
	ECOdrawMultiKnobs(mHWnd, paintStruct.hdc); // rmm5006
	WNDendPaint( mHWnd, &paintStruct );	
	return qtrue;
}

// rmm3735
#ifndef isWEB
void tqfCalendar::setTooltipIndex(qpoint &pPt)
{
	mTooltipIndex = -1;
	for (qshort cellindex = 0; cellindex < 42; cellindex++)
	{
		qrect r = getIndexRect(cellindex);
		if (GDIptInRect(&r, &pPt))
		{
			mTooltipIndex = cellindex;
			return;
		}
	}
}
#endif

extern "C" LRESULT OMNISWNDPROC GenericWndProc( HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
   ECOsetupCallbacks(hwnd,eci);
	 switch (Msg)
	 {
			case WM_LBUTTONDBLCLK:
			case WM_LBUTTONDOWN:
			{
				qpoint pt;
				if ( !ECOisDesign( hwnd ) )
				{           
					ECOhideTooltip( hwnd );
					WNDmakePoint( lParam, &pt );
					tqfCalendar* object = (tqfCalendar*)ECOfindObject( eci, hwnd );
					if ( object ) 
					{
						object->findCell(&pt,Msg==WM_LBUTTONDBLCLK);
						return qtrue;
					}
				}
				break; 	
			}
		#ifdef ismobile
			// rmm_mobile:
			case WM_KEYDOWN:
			{
				tqfCalendar *object = (tqfCalendar *) ECOfindObject(eci, hwnd);
				if (object) 
				{
					return !object->key(hwnd, Msg, (qkey *) lParam);
				}
				break;
			}
			case WM_FOCUSCHANGED:
			{
				tqfCalendar *object = (tqfCalendar *) ECOfindObject(eci, hwnd);
				if (object) 
				{
					object->mHasFocus = (qbool) (wParam != 0);
				}
				break;
			}
		#endif
			case ECM_PRINTMAPPING: return 1L; // Yes, we want printer mapping
			case ECM_PRINT:
			{
				tqfCalendar* object = (tqfCalendar*)ECOfindObject( eci, hwnd );
				if ( object )
				{
					WNDpaintStruct* paintStruct = (WNDpaintStruct*)lParam;
					object->setPrintRect( &paintStruct->rcPaint );
					object->paintCalendar( paintStruct->hdc, eci ); // rmm3735
				}
				break;
			}
			case WM_PAINT:							
			{
				tqfCalendar* object = (tqfCalendar*)ECOfindObject( eci, hwnd );
				if ( object && object->paint(eci) ) // rmm3735
					return qtrue;
				break;
			}
			case ECM_OBJCONSTRUCT:				/* Construct an object */
			{
				tqfCalendar* object = new tqfCalendar( hwnd, (qbool)wParam );
				ECOinsertObject( eci, hwnd, (void*)object );
				object->mApp = ECOgetApp( eci->mInstLocp );	 // MHn0068
				return qtrue;
			}
			case ECM_OBJDESTRUCT:					/* Destruct the object */
			{
				tqfCalendar* object = (tqfCalendar*)ECOremoveObject( eci, hwnd );
				if ( object ) delete object;              
				return qtrue;
			}
			case ECM_PROPERTYCANASSIGN:  	
			case ECM_SETPROPERTY: 				
			case ECM_GETPROPERTY:					
			{
				tqfCalendar* object = (tqfCalendar*)ECOfindObject( eci, hwnd );
				if ( object )
					return object->attributeSupport( Msg, wParam, lParam, eci );
				return 0L;
			}
      case ECM_GETCOMPLIBINFO:
      {
      	return ECOreturnCompInfo( gInstLib, eci, LIB_RES_NAME, COMPONENT_COUNT );
      }
			case ECM_GETCOMPICON:
			{ 	
				if ( eci->mCompId==CALENDAR_ID ) return ECOreturnIcon( gInstLib, eci, CALENDAR_ICON );
				return qfalse;
			}   
			case ECM_CUSTOMTABNAME:
			{
				ECOsetCustomTabName( gInstLib, eci, 8000 );
				return 1L;
			}
#ifndef isWEB // MHn0068
			case ECM_METHODCALL:
			{
				tqfCalendar* object = (tqfCalendar*)ECOfindObject( eci, hwnd );
				if ( object )
					object->functionSupport( Msg, wParam, lParam, eci );
				return 1L;
			}
			case WM_TOOLTIP:	// rmm3735
			{
				if (!ECOisDesign(hwnd) && TIP_GETTIP == wParam)
				{
					tqfCalendar *object = (tqfCalendar *)ECOfindObject(eci, hwnd);
					if (object && object->dayTooltips())
					{
						TIPinfo *info = (TIPinfo *) lParam;
						object->setTooltipIndex(info->mShowPoint);
						LRESULT retVal = 1L;	// rmm64bit5
						if (object->tooltipIndex() >= 0)
						{
							retVal = WNDdefWindowProc(hwnd, Msg, wParam, lParam, eci);
							if (info->mHasTip)
							{
								// Set the active show area for the tooltip to be the day's rectangle
								info->mActiveShowArea = object->getIndexRect(object->tooltipIndex());
							}
						}
						return retVal;
					}
				}
				break;
			}
#endif // MHn0068
			case ECM_GETCOMPID:
			{
				if ( wParam==1 )
				#ifdef isRCCDESIGN
					return ECOreturnCompID( gInstLib, eci, CALENDAR_ID, cObjType_Basic );
				#else
					return ECOreturnCompID( gInstLib, eci, CALENDAR_ID, cObjType_Basic|cRepObjType_Basic );
				#endif
				return 0L;
			}
			case ECM_GETEVENTNAME:
			{
				return ECOreturnEvents( gInstLib, eci, &CALENDARevents[0], sizeof(CALENDARevents)/sizeof(CALENDARevents[0]) ); // rmm3550
			}
#ifndef isWEB // MHn0068
			case ECM_GETMETHODNAME:
			{
				return ECOreturnMethods( gInstLib, eci, &CALENDARfunctions[0], 3 );
			}
#endif // MHn0068
			case ECM_GETPROPNAME:
			{
				return ECOreturnProperties( gInstLib, eci, &CALENDARproperties[0], sizeof(CALENDARproperties)/sizeof(CALENDARproperties[0]) ); // MHn0068 // rmm3735
			}              
			case ECM_GETVERSION:	// rmm3478
			{
				return ECOreturnVersion(gInstLib);
			}                                                                 
			// MHn0068 begins.
#ifdef isWEB
			case ECM_GETCOMPSTOREGROUP:
			{
				ECOreturnCStoreGrpName( gInstLib, eci, 2010 );
				return 1L;
			}	
#endif
			// MHn0068 ends.			
#ifdef isRCCDESIGN
	 		case ECM_CONNECT:
      {
		    return EXT_FLAG_LOADED|EXT_FLAG_ALWAYS_USABLE|EXT_FLAG_REMAINLOADED; // Return external flags	// rmm_thindl
      } 			
#endif
			case ECM_ISUNICODE:	// rmmuni
			{
				return qtrue;
			}
	 }
	 return WNDdefWindowProc(hwnd,Msg,wParam,lParam,eci);
}

// End of file
