// $Header: svn://172.16.3.39/data/repos/trunk/Studio/JSCLIENT/jscomp/jsgeneric/ctl_generic.js 9129 2014-04-22 11:17:43Z crichardson $
// Copyright (C) Tiger Logic Corp 2014
// JavaScript generic control class example

// Changes
// Date				Edit				Bug					Description
// 09-Jul-19	dmw0234									Updated object creation.
// 15-Aug-17													New structure for JS controls.
// 09-Jan-14	cr_jsc									JavaScript client generic component example.

ctrl_generic2.prototype = (function() {

	/****** CONSTANTS ******/
	var PROPERTIES = {
		// TODO: Populate this with custom properties.
	};

	var EVENTS = {
		// TODO: Populate this with custom events.
	};

	/** The control prototype - inherited from base class prototype */
	var ctrl = Object.create(ctrl_base.prototype);


	/**
	 * class initialization, must be called by constructor
	 * this function should initialize class variables
	 * IMPORTANT:
	 * initialization is separated out from the constructor
	 * as the base class constructor is not called when a
	 * class is subclassed.
	 * all subclass constructors must call their own
	 * init_class_inst function which in turn must call the
	 * superclass.init_class_inst function
	 */
	ctrl.init_class_inst = function() {

		// install superclass prototype se we can than call superclass methods
		// using this.superclass.method_name.call(this[,...])
		this.superclass = ctrl_base.prototype;

		// call our superclass class initializer:
		this.superclass.init_class_inst.call(this);

		//TODO: initialize class specific stuff
	};


	ctrl.delete_class_inst = function()
	{
		//TODO: Any custom cleanup when control is deleted. Remove function if no custom behaviour required.
		this.superclass.delete_class_inst.call(this); // Call superclass version to perform standard deletion procedure.
	};


	/**
	 * Initializes the control instance from element attributes.
	 * Must be called after control is constructed by the constructor.
	 * @param form 			Reference to the parent form.
	 * @param elem 			The html element the control belongs to.
	 * @param rowCtrl 	Pointer to a complex grid control if this control belongs to a cgrid.
	 * @param rowNumber The row number this control belongs to if it belongs to a cgrid.
	 * @returns {boolean}		True if the control is a container.
	 */
	ctrl.init_ctrl_inst = function( form, elem, rowCtrl, rowNumber )
	{
		// call our superclass init_ctrl_inst
		this.superclass.init_ctrl_inst.call(this, form, elem, rowCtrl, rowNumber);

		// Control-specific initialization
		var client_elem = this.getClientElem();
		client_elem.style.overflow = "hidden"; // Don't draw outside the bounds of the control.
		// Read initial value of $text. In this instance it is just the content of the client element.
		this.mText = client_elem.innerHTML;

		this.update();

		// return true if our control is a container and the
		// children require installing via this.form.InstallChildren
		return false;
	};


	/**
	 * The control's data has changed. The contents may need to be updated.
	 *
	 *  @param {String} what      Specifies which part of the data has changed:
	 *            ""          - The entire data has changed
	 *            "#COL"        - A single column in the $dataname list (specified by 'row' and 'col') or a row's column (specified by 'col')
	 *            "#LSEL"        - The selected line of the $dataname list has changed (specified by 'row')
	 *            "#L"        - The current line of the $dataname list has changed  (specified by 'row')
	 *            "#LSEL_ALL"        - All lines in the $dataname list have been selected.
	 *            "#NCELL"      - An individual cell in a (nested) list. In this case, 'row' is an array of row & column numbers.
	 *                                  of the form "row1,col1,row2,col2,..."
	 *  @param {Number} row          If specified, the row number in a list (range = 1..n) to which the change pertains.
	 *                If 'what' is "#NCELL", this must be an array of row and col numbers. Optionally, a modifier may be
	 *                added as the final array element, to change which part of the nested data is to be changed. (Currently only "#L" is supported)
	 *  @param {Number|String} col  If specified, the column in a list row (range = 1..n or name) to which the change pertains.
	 * @param {Boolean} mustUpdate	DEPRECATED. Indicates that the entire control must update. This can be inferred by the 'what' parameter being "".
	 */
	ctrl.updateCtrl = function(what, row, col, mustUpdate)
	{
		var elem = this.getClientElem();

		// Center the text vertically:
		elem.style.lineHeight = elem.style.height;
	};


	/**
	 * Called when the size of the control has changed.
	 */
	ctrl.sizeChanged = function()
	{
		this.update(); // Cause updateCtrl() to be called, to re-center the text.
		this.superclass.sizeChanged.call(this);
	};


	/**
	 * This is called when an event registered using this.makeEventFunction() is triggered.
	 *
	 * @param event The event object
	 */
	ctrl.handleEvent = function( event ) {
		//TODO: Implement if necessary (e.g. check event.type). If not, remove this function.
		return this.superclass.handleEvent.call(this, event); //Let the superclass handle the event, if not handled here.
	};


	/**
	 * Called to get the value of an Omnis property
	 *
	 * @param propNumber    The Omnis property number
	 * @returns {*}       	The property's value
	 */
	ctrl.getProperty = function(propNumber)
	{
		switch (propNumber) {
			case eBaseProperties.text:
				return this.mText;
		}
		return this.superclass.getProperty.call(this, propNumber); //Let the superclass handle it, if not handled here.
	};


	/**
	 * Function to get $canassign for a property of an object. Custom properties can only be assigned to at runtime if this returns true for that property.
	 * @param propNumber    The Omnis property number
	 * @returns {boolean}   Whether the passed property can be assigned to.
	 */
	ctrl.getCanAssign = function(propNumber)
	{
		switch (propNumber) {
			case eBaseProperties.text:
				return true; // Allow $text to be assigned to.
		}
		return this.superclass.getCanAssign.call(this, propNumber); //Let the superclass handle it, if not handled here.
	};


	/**
	 * Assigns the specified property's value to the control.
	 * @param propNumber    The Omnis property number
	 * @param propValue     The new value for the property
	 * @returns {boolean}   success
	 */
	ctrl.setProperty = function( propNumber, propValue )
	{
		if (!this.getCanAssign(propNumber)) // Check whether the value can be assigned to
			return false;

		switch (propNumber) {
			case eBaseProperties.text: // Set the text as appropriate for this control.
				this.mText = propValue;
				var client_elem = this.getClientElem();
				client_elem.innerHTML = propValue;
				return true;
		}

		return this.superclass.setProperty.call(this, propNumber, propValue); //Let the superclass handle it, if not handled here.
	};

	return ctrl; // Return the prototype object.
})();


// ###################################################################
// ##### class constructor ###########################################
// ###################################################################


/**
 * constructor for our generic control
 * @constructor
 */
function ctrl_generic2()
{
	this.init_class_inst(); // initialize our class
}