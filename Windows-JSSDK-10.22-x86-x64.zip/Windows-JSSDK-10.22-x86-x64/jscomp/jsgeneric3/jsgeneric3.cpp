/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/JSCLIENT/jscomp/jsgeneric3/jsgeneric3.cpp 27768 2020-09-22 08:21:23Z jgissing $ */

// jsgeneric3.cpp
// Generic 3 example

/*************** changes *******************
Date			Edit				Bug					Description
09-Jan-14	cr_jsc									JavaScript client generic component example.
*/

#include "jsgeneric3.h"

ECOparam jsGenericEventParams[] = 
{
	cEvParamXPos,	fftInteger, 0, 0,
	cEvParamYPos,	fftInteger, 0, 0
};

ECOmethodEvent jsGenericEvents[] =
{
	ECE_CLICK, 0, 0, 2, &jsGenericEventParams[0], 0, 0
};

#define jsGenericEvent_Count (sizeof(jsGenericEvents) / sizeof(ECOmethodEvent))

ECOproperty jsGenericProperties[] =
{
	anumText,				0,				fftCharacter,		EXTD_FLAG_PROPTEXT|EXTD_FLAG_FAR_SRCH, 0, 0, 0,
	anumTextColor,	0,				fftInteger,			EXTD_FLAG_PROPTEXT|EXTD_FLAG_PWINDCOL, 0, 0, 0,
	anumEffect,			0,				fftInteger,			0,0,0,0,
	cToggleColor,	cToggleColor,	fftBoolean,		EXTD_FLAG_PROPAPP, 0, 0, 0,
	0,							0,				0,							EXTD_FLAG_PRIMEDATA, 0, 0, 0, // $dataname
};

#define jsGenericProperty_Count (sizeof(jsGenericProperties) / sizeof(ECOproperty))

jsGenericComponent::jsGenericComponent(HWND pFieldHWnd, WCCcontrol *pControl) : javaScriptComponent(pFieldHWnd, pControl)
{
	mNoDesignName = qtrue;
	mText = QTEXT("Generic Three");
	mToggleColor = qfalse;
}

jsGenericComponent::~jsGenericComponent()
{
}

qlong jsGenericComponent::attributeSupport( LPARAM pMessage, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci )
{
	GDIignore(&wParam); GDIignore(&lParam);
	switch( pMessage )
	{
		case ECM_PROPERTYCANASSIGN:
		{
			return 1L;
		}
		case ECM_SETPROPERTY:
		{
			EXTParamInfo* param = ECOfindParamNum( eci, 1 );
			if (param)
			{
				EXTfldval fval( (qfldval)param->mData );
				qbool ret = qfalse;
				int propid =  ECOgetId(eci);
				switch( propid)
				{
					case anumText:				ret = setText(fval); break;
					case cToggleColor:		ret = setToggleColor(fval); break;
				}
				return ret;
			}
			break;
		}
		case ECM_GETPROPERTY:
		{
			EXTfldval fval; qbool ret = qfalse; int propid =  ECOgetId(eci);
			switch( propid)
			{
				case anumText:					ret = getText(fval); break;
				case cToggleColor:			ret = getToggleColor(fval); break;
				default: return 0L;
			}
			ECOaddParam(eci,&fval);
			return ret;
		}
	}
	return 0;
}

void jsGenericComponent::paintDesign(HDC pHdc)
{
	EXTfldval fval;
	qrect clientRect;
	WNDgetClientRect(mHWnd, &clientRect);
	
	HFONT font = 0, oldFont =0;
	qshort textLen = mText.length();
	
	// Draw text centered
	if(textLen > 0)
	{
		font = GDIcreateFont(&textSpec().mFnt, textSpec().mSty);
		oldFont = GDIselectObject(pHdc, font);
		GDIsetTextColor(pHdc, textSpec().mTextColor);
		
		clientRect.top += (clientRect.height() - GDIfontHeight(pHdc))/2;
		GDItextBox(pHdc, &clientRect, &mText[1], &textLen, mText.maxLength(), jstCenter);
	}
	
	// Clean-up
	if (font)
	{
		GDIselectObject(pHdc, oldFont);
		GDIdeleteObject(font);
	}

}

/***********************************
		GETTER / SETTER METHODS
***********************************/

qbool jsGenericComponent::getText(EXTfldval& fval)
{
	fval.setChar(mText);
	return qtrue;
}

qbool jsGenericComponent::setText(EXTfldval& fval)
{
	fval.getChar(mText);
	inval();
	return qtrue;
}

qbool jsGenericComponent::getToggleColor(EXTfldval& fval)
{
	fval.setLong(mToggleColor);
	return qtrue;
}

qbool jsGenericComponent::setToggleColor(EXTfldval& fval)
{
	mToggleColor = fval.getLong();
	return qtrue;
}

qbool jsGenericComponent::jsGetInnerHTML(HWND pHwnd, WCCcontrol *pControl, webClientComponent *pObject, EXTfldval &pInner, qdim pWidth, qdim pHeight)
{
	qbool deleteObject = qfalse;
	jsGenericComponent *object = (jsGenericComponent *) pObject;
	EXTfldval fval;
	
	if (!object)
	{
		// Temporary object to hold property values - we need to use the property values in the supplied object when
		// generating HTML for an open design window - the temporary object caters for the case when there is no open design window, e.g. the property is changed notationally
		
		deleteObject = qtrue;
		object = new jsGenericComponent(0, pControl);
		
		ECOgetProperty(0, anumText, fval);
		fval.getChar(object->mText);

		ECOgetProperty(0, cToggleColor, fval);
		object->mToggleColor = fval.getLong();
	}
	
	str255 innerTemplate = str255(QTEXT("<div $$$$>$</div>"));
	pInner.setChar(innerTemplate);
	
	//insert the id of the client
	jsInsertId(pHwnd, pInner, qfalse);
	// insert the control's style, etc.

	fval.setLong(jstCenter);
	ECOsetProperty(pHwnd, anumAlign, fval);

	jsInsertStyle(pHwnd, pControl, pInner, pWidth, pHeight, object);
	jsInsertBorder(pHwnd, pInner);

	jsInsertNum("data-togglecolor", object->mToggleColor, pInner);	// Custom property

	jsInsert(object->mText, pInner); //text
	
	if (deleteObject)
		delete object;
	
	return qtrue;
}

static JSChtmlOptionsGeneric sHTMLoptions;

static WCCcontrol sJSControl =
{
	0,																// Resource base - unused for JavaScript components
	LIB_RES_NAME,											// Resource id of library name
	OBJECT_ID1,												// Resource id of control within library
	OBJECT_ICON,											// Resource bitmap id
	jsGenericEvent_Count,							// Count of events
	jsGenericEvents,										// Events
	jsGenericProperty_Count,						// Count of properties
	jsGenericProperties,								// Properties
	0, 0,															// First and last constant
	EXTIPJS_FLAG_BACKCOLOR_AND_BACKALPHA|EXTIPJS_FLAG_EFFECT,							// iPhone/JavaScript mCompFlags
	WCC_FLAG_CANFOCUS,								// mWccFlags
	COMP_STORE_GROUP,									// Resource id of component store group
	0,																// Count of methods
	0,																// Methods
	0,																// Function to make class notation object
	0,																// Resource id of of custom tab name
	0,																// Fixed landscape width for control (zero if any width allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	0,																// Fixed landscape height for control (zero if any height allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	0,																// Fixed portrait width for control (zero if any width allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	0,																// Fixed portrait height for control (zero if any height allowed) (if landscape is non-zero, portrait must also be non-zero, and vice-versa)
	&sHTMLoptions,										// options for HTML generation
	jsGenericComponent::jsGetInnerHTML,// static to generate inner HTML
	0,																// No control-specific styles function
	"ctrl_generic3"									// Control name
};

extern "C" LRESULT OMNISWNDPROC jsGenericComponentWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci)
{
	ECOsetupCallbacks(hwnd, eci);
	switch (message)
	{
		case ECM_OBJCONSTRUCT:				
		{		
			jsGenericComponent *object = new jsGenericComponent(hwnd, &sJSControl);
			lParam = (LPARAM) object;
			break;
		}
	}
	return JSCdefWindowProc(hwnd, message, wParam, lParam, eci, &sJSControl);
}
// End of file
