// $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/EXTCOMP/CALLBACK/DataBoundFatClientComponent.h 25644 2020-02-29 21:32:49Z jgissing $

/**************** Changes ******************
Date			Edit				Bug					Description
14-Oct-19	rmm10287								Fixed crashes in jsnavmenu.
*************************************/

#pragma once

#include "OmnisComponent.h"

class DataBoundFatClientComponent: public OmnisComponent
{
public:
	// rmm10287: Added constructor
	DataBoundFatClientComponent(ffttype pAllowedFftForData, HWND pHWnd, OMNISControlDefinition* pControl, ComponentDelegate* pCompDelegate = 0): OmnisComponent(pHWnd, pControl, pCompDelegate)
	{
		mAllowedFftForData = pAllowedFftForData;
		mData = 0;
	}
protected:
	virtual void	newData(EXTCompInfo* eci) { GDIignore(eci); }									// Overridden by subclasses - called when data changes
	virtual qbool hasPrimaryDataChanged() { return qfalse; }		// Overridden by subclasses if they can change the data
	virtual void initComplete() {}

	qbool					setData(EXTCompInfo* eci, qfldval pData = 0);
	qbool					getData(EXTCompInfo* eci);
	qlong					cmpData(EXTCompInfo* eci);
	qbool					getDataLen(EXTCompInfo* eci, qlong* pDataLen);
	qlong					tLen() { if (mData) { qHandlePtr dataPtr(mData, 0); return dataPtr.dataLen(); } else return 0; }
	
	ffttype			mAllowedFftForData;
	qHandle			mData;

	friend LRESULT DataBoundDefWindowProc(HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci, OMNISControlDefinition* pControl);
};

LRESULT DataBoundDefWindowProc(HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci, OMNISControlDefinition* pControl);
