/**************** Changes ******************
Date			Edit				Bug					Description
13-Jan-21	dmw0398									$horzpadding moved to jssuper.
19-Oct-20	dmw0362									Rewrote handling for default and conversion values of $inputborderstyle, $borderradius, $horzpadding.
02-Oct-20	dmw0352									Added default $horzpadding for text inputs on conversion to 10.2
16-Sep-20	jmg_material						Moved ECM_OBJINITIALIZE logic into a new JSTextInputComponentBasetWndProc in the base class.
*******************************************/

#ifndef _JSTEXTINPUTBASE_H_
#define _JSTEXTINPUTBASE_H_

#include "jssuper.h"

const attnumber cBorderStyle = 4203; // dmw_material

// Start dmw_material
const qdim	cDefaultBorderRadius = 4;
const qshort cBorderStyleNotSet = 0;
const qshort cBorderStyleOutlined = 1;
// End dmw_material
const qshort	cDefaultHorzPadding = 4; // dmw0352

#define JS_TEXTINPUT_PROPERTIES(_dataType) \
	cBorderStyle, cBorderStyle,		fftInteger,			EXTD_FLAG_PROPAPP | EXTD_FLAG_EXTCONSTANT, EXTD_EFLAG_AUTOPROP, 6025, 6026 


class jsTextInputComponentBase : public javaScriptComponent
{
public:
	qbool convertHorzPadding = qfalse; // dmw0352: flag to set default horz padding when converting to 10.2
	qlong mHorzPadding;		// bjw0002 // dmw0362: moved to here from individual classes for shared behaviour

	jsTextInputComponentBase(HWND pFieldHWnd, WCCcontrol *pControl);
	~jsTextInputComponentBase();

	void setInputBorder(); // dmw0362 // dmw0398: renamed

	qlong getAutoPropLongValue(attnumber attNum) {
		return mAutoPropValues.getLongProperty(attNum);
	}

	void setAutoPropLongValue(attnumber attNum, qlong value) {
		mAutoPropValues.setLongProperty(attNum, value);
	}

	qlong getDefaultHorzPaddingValue() { return cDefaultHorzPadding; } // dmw0398: overrides super implementation
	qbool propertyRequiresConversion(attnumber propID); // dmw0398
	void propertyHasBeenConverted(attnumber propID); // dmw0398
};

// [deprecated] Legacy WndProc for JavaScript controls - new components should avoid this.
LRESULT JSTextInputComponentBasetWndProc(HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam, EXTCompInfo* eci, WCCcontrol* pControl); // jmg_material

#endif
