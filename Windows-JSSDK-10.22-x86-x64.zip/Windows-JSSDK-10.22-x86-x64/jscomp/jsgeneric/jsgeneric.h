/* $Header: svn://svn.omnis.net/branches/Studio10.2/Studio/JSCLIENT/jscomp/jsgeneric/jsgeneric.h 9129 2014-04-22 11:17:43Z crichardson $ */

// jsgeneric.h
// Generic framework declarations

/*************** changes *******************
Date			Edit				Bug					Description
09-Jan-14	cr_jsc									JavaScript client generic component example.
*/

#ifndef _JSGENERIC_H_
#define _JSGENERIC_H_

#include "jssuper.h"

#define LIB_RES_NAME			1000			// Resource id of library name
#define OBJECT_ID1				2000			// Resource id of control within library
#define COMP_STORE_GROUP	3000			// Resource id of component store group
#define OBJECT_ICON 			1					// Resource bitmap id

class jsGenericComponent : public javaScriptComponent
{
public:
	jsGenericComponent(HWND pFieldHWnd, WCCcontrol *pControl);
	~jsGenericComponent();
	
	virtual void paintDesign(HDC pHdc);
	
	static qbool jsGetInnerHTML(HWND pHwnd, WCCcontrol *pControl, webClientComponent *pObject, EXTfldval &pInner, qdim pWidth, qdim pHeight);
};

struct JSChtmlOptionsGeneric : public JSChtmlOptions
{
public:
	JSChtmlOptionsGeneric() : JSChtmlOptions() { mControlHasDataName = qfalse; }
};

#endif		// #ifndef _JSGENERIC_H_
// End of file
